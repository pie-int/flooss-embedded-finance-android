package com.flooss.nanoloan.model

/**
 * Public re-declaration of the app's `SoouqBlacklistRes`
 * (`data/model/api/response/SoouqBlacklistRes.kt`) — same field names/shapes, so hosts
 * don't depend on the SDK's internal Gson/Retrofit DTO (design doc §10). Backed by the
 * real `GET api/v1/fo/client/check-eligibility` endpoint (`WebServiceConstants
 * .FETCH_SOOUQ_BLACKLIST_STATUS`, `LoanApi.fetchSoouqBlackListStatus`).
 */
data class EligibilityResult(
    val restricted: Boolean,
    val restrictedReason: String?,
    val remainingDays: Int,
    val remainingHours: Int,
    val remainingMinutes: Int,
    val restrictedUntil: String
)
