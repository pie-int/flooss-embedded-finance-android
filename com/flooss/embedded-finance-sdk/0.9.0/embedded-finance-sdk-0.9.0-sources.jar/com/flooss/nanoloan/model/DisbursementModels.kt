package com.flooss.nanoloan.model

/**
 * Resolved bank details for a disbursement IBAN
 * (`GET api/v1/fo/loans/disbursement/bank-detail/{iban}`) — public projection of the
 * app's `BankDetailResponse`.
 */
data class BankIbanDetail(
    val bankName: String?,
    val bic: String?,
    val iban: String
)

/** Employment details collected on the real screen 2/4 (`EmployeeDetailReq` shape). */
data class EmploymentDetails(
    val companyName: String,
    val jobTitle: String,
    val startDate: String
)
