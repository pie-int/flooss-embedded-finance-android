package com.flooss.nanoloan.result

/**
 * Target `NanoLoanError` shape (design doc §9.1, §11) — a near-direct wrap of the app's
 * existing `exceptions/Exceptions.kt` hierarchy (`BaseClass`/`ApiException`/
 * `NoInternetException`/`UserBlockedException`/`CaptchaException`/`WrongPinOtpException`),
 * re-declared here rather than depended on so this module never depends on `:app`.
 * Every case carries the same fields the as-is hierarchy carries: [errorCode], [txnId],
 * [enableFeedback] (show a feedback affordance), [enableTryAgain] (show a retry action).
 */
sealed class NanoLoanError(
    open val message: String,
    open val errorCode: Int = 0,
    open val txnId: String = "",
    open val enableFeedback: Boolean = false,
    open val enableTryAgain: Boolean = true
) {
    data class Api(
        override val message: String,
        override val errorCode: Int = 0,
        override val txnId: String = "",
        override val enableFeedback: Boolean = false,
        override val enableTryAgain: Boolean = true
    ) : NanoLoanError(message, errorCode, txnId, enableFeedback, enableTryAgain)

    data class NoInternet(
        override val message: String = "No internet connection",
        override val errorCode: Int = 0,
        override val txnId: String = ""
    ) : NanoLoanError(message, errorCode, txnId, enableFeedback = false, enableTryAgain = true)

    data class UserBlocked(
        override val message: String,
        override val errorCode: Int = 0,
        override val txnId: String = ""
    ) : NanoLoanError(message, errorCode, txnId, enableFeedback = true, enableTryAgain = false)

    data class Captcha(
        override val message: String,
        override val errorCode: Int = 0,
        override val txnId: String = ""
    ) : NanoLoanError(message, errorCode, txnId, enableFeedback = false, enableTryAgain = true)

    data class WrongPinOtp(
        override val message: String,
        override val errorCode: Int = 0,
        override val txnId: String = ""
    ) : NanoLoanError(message, errorCode, txnId, enableFeedback = false, enableTryAgain = true)

    /** Not authenticated yet — [com.flooss.nanoloan.NanoLoanSDK.authenticate] was never called or its token expired. */
    data class NotAuthenticated(
        override val message: String = "No active NanoLoan session — call authenticate() first"
    ) : NanoLoanError(message, enableFeedback = false, enableTryAgain = false)

    data class Unknown(
        override val message: String,
        override val errorCode: Int = 0,
        override val txnId: String = ""
    ) : NanoLoanError(message, errorCode, txnId, enableFeedback = true, enableTryAgain = true)
}
