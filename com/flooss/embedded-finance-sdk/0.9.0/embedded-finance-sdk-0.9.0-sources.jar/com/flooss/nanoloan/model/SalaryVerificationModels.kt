package com.flooss.nanoloan.model

import java.math.BigDecimal

/**
 * Public re-declaration of the app's `BankModel`
 * (`data/model/api/response/BanksListRes.kt`) — same field names. Backed by the real
 * `GET api/v1/fo/tarabut/providers` endpoint (`WebServiceConstants.GET_TARABUT_BANKS`,
 * `LoanApi.getAllBanksList`).
 */
data class BankProvider(
    val providerId: String,
    val name: String,
    val displayName: String,
    val logoUrl: String,
    val countryCode: String,
    val status: String
)

/**
 * Outcome of the Tarabut open-banking link — the SDK-side composite of
 * `POST api/v1/fo/tarabut/intent` (`TarabutTokenResponse.data.intentId`) followed by
 * `POST api/v1/fo/tarabut/accounts/sync` (`TarabutSyncResponse.message`/`status`).
 */
data class BankLinkResult(
    val intentId: String,
    val synced: Boolean,
    val message: String?
)

/**
 * Public subset of the app's `LoanProductRes.ProductDetails` (SHARIYAH product) —
 * same field names. Backed by `GET api/v2/fo/products`
 * (`WebServiceConstants.GET_PRODUCT`, `SalafApi.hitGetProductApi`).
 */
data class LoanProductInfo(
    val id: Long,
    val guid: String?,
    val displayName: String?,
    val minLoanAmount: BigDecimal?,
    val maxLoanAmount: BigDecimal?,
    val minLoanPeriod: Int?,
    val maxLoanPeriod: Int?,
    val periodType: String?
)

/**
 * Result of `GET api/v1/fo/loans/active` (`WebServiceConstants.GET_ACTIVE_LOAN`,
 * `LoanApi.getActiveLoan`) — whether the client already holds an active loan (which
 * blocks a new application in the real flow).
 */
data class ActiveLoanInfo(
    val hasActiveLoan: Boolean,
    val loanId: Long?,
    val status: LoanStatus?
)

/**
 * Session handles the acceptance-OTP chain returns — the `verificationUUID`s the real
 * endpoints mint (`POST api/v1/security/verifyEmail/sendEmailOtp` ->
 * `EmailVerificationResponse.verificationUUID`; `POST api/v1/security/verifyPhone/sendSms`
 * -> `VerificationActionData.verificationUUID`).
 */
data class AcceptanceOtpSession(
    val emailVerificationUUID: String?,
    val phoneVerificationUUID: String?,
    val maskedPhone: String?
)

/**
 * Trimmed preview of the app's `Installments` response
 * (`GET api/v2/fo/loans/installments`, `LoanApi.getActiveOfferInstallments`) — the
 * offer screen only needs the pending schedule's headline numbers.
 */
data class OfferInstallmentsPreview(
    val pendingCount: Int,
    val firstDueDate: String?,
    val installmentAmount: BigDecimal?
)
