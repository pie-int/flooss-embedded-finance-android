package com.flooss.nanoloan.telemetry

import android.os.Build
import com.flooss.nanoloan.config.NanoLoanConfiguration
import com.flooss.nanoloan.config.NanoStepOwner
import com.flooss.nanoloan.listener.NanoLoanEvent
import com.flooss.nanoloan.listener.NanoLoanState
import com.flooss.nanoloan.logging.NanoLogLevel
import com.flooss.nanoloan.logging.NanoLogSink
import com.flooss.nanoloan.logging.NanoLoanLogger
import com.flooss.nanoloan.model.LoanOffer
import com.flooss.nanoloan.result.NanoLoanError
import java.util.Locale
import java.util.TimeZone

/**
 * Tees the SDK's existing emission points into the telemetry sink. Installed by
 * [com.flooss.nanoloan.NanoLoanSDK.initialize]; a no-op object while the host has not
 * opted in, so a default-configured SDK allocates nothing and starts no thread.
 *
 * This is a **second sink alongside** the host's `NanoLoanListener` / `NanoLogSink` — the
 * host's callbacks fire exactly as before, are unaffected by telemetry failures, and are
 * never reordered around it.
 */
internal object NanoTelemetryBridge {

    const val SDK_VERSION = com.flooss.nanoloan.BuildConfig.SDK_VERSION
    const val PLATFORM = "android"

    @Volatile private var client: NanoTelemetryClient? = null
    @Volatile private var lastStateName: String = NanoTelemetryContract.State.IDLE
    @Volatile private var currentStep: String? = null
    /** Mirrors `telemetry.businessMetrics` for the life of the installed client. */
    @Volatile private var businessMetrics: Boolean = false
    /**
     * v2 §3.2 — the amount and tenor of the offer the customer was last SHOWN.
     * [com.flooss.nanoloan.NanoLoanSDK.acceptOffer] takes only an offer guid, so the
     * accepted amount is not in scope at that call site; carrying it forward from
     * `offer_shown` reports the offer the customer actually accepted rather than
     * inventing a figure. Cleared with the journey.
     */
    @Volatile private var lastOfferFils: Long? = null
    @Volatile private var lastOfferTenorMonths: Int? = null

    val isActive: Boolean get() = client != null

    /** @return an extra [NanoLogSink] to append to the host's list, or null when disabled. */
    fun install(config: NanoLoanConfiguration, logger: NanoLoanLogger): NanoLogSink? {
        shutdown()
        val telemetry = config.telemetry
        if (!telemetry.isOperational()) return null
        return try {
            // v2 §2 — refuse a PII-shaped reference here, at initialize() time. The
            // warning names the SHAPE only; logging the value would put the very PII this
            // gate exists to stop into the log sink (and, via the sink adapter, back into
            // telemetry).
            val sanitized = NanoTelemetryRedactor.sanitizeExternalUserRef(config.externalUserRef)
            sanitized.rejection?.let { rejection ->
                logger.w(
                    "NanoLoanTelemetry",
                    "externalUserRef dropped: the supplied value is ${rejection.reason}. " +
                        "It must be opaque outside your own systems — an internal customer id, " +
                        "a UUID or a hashed account number. The session was sent without it."
                )
            }
            businessMetrics = telemetry.businessMetrics
            lastOfferFils = null
            lastOfferTenorMonths = null
            client = NanoTelemetryClient(
                config = telemetry,
                environment = config.environment.name,
                platform = PLATFORM,
                sdkVersion = SDK_VERSION,
                externalUserRef = sanitized.value,
                device = NanoTelemetryDevice(
                    osVersion = Build.VERSION.RELEASE ?: "unknown",
                    model = Build.MODEL ?: "unknown",
                    locale = config.locale.name.lowercase(Locale.US).take(2),
                    timezone = TimeZone.getDefault().id
                ),
                sender = OkHttpTelemetrySender(),
                debugLog = { logger.d("NanoLoanTelemetry", it) }
            )
            lastStateName = NanoTelemetryContract.State.IDLE
            currentStep = null
            record(
                NanoTelemetryContract.Kind.LIFECYCLE,
                NanoTelemetryContract.Lifecycle.SDK_INITIALIZED,
                attrs = mapOf(
                    "environment" to config.environment.name,
                    "mocked" to config.isMockMode,
                    "contractVersion" to NanoTelemetryContract.CONTRACT_VERSION
                )
            )
            config.stepOwnership.forEach { (step, owner) ->
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE,
                    NanoTelemetryContract.Lifecycle.STEP_OWNERSHIP,
                    step = NanoTelemetryMapper.contractStep(step),
                    attrs = mapOf(
                        "step" to NanoTelemetryMapper.contractStep(step),
                        "owner" to if (owner == NanoStepOwner.HOST) "HOST" else "SDK"
                    )
                )
            }
            SinkAdapter
        } catch (t: Throwable) {
            client = null
            null
        }
    }

    fun shutdown() {
        businessMetrics = false
        lastOfferFils = null
        lastOfferTenorMonths = null
        client?.shutdown()
        client = null
    }

    /**
     * Test seam. [install] cannot run under a plain JVM unit test because it reads
     * `android.os.Build`, which would leave the whole tee — and therefore the contract
     * `name` every emission site chooses — untestable without Robolectric. This attaches
     * a caller-built client directly so the REAL [onEvent] / [onFailure] / [logSink]
     * paths can be driven and their wire output asserted.
     */
    internal fun attachClientForTest(
        testClient: NanoTelemetryClient,
        businessMetricsEnabled: Boolean = false
    ) {
        client = testClient
        lastStateName = NanoTelemetryContract.State.IDLE
        currentStep = null
        businessMetrics = businessMetricsEnabled
        lastOfferFils = null
        lastOfferTenorMonths = null
    }

    /** Test seam — the same [NanoLogSink] [install] hands back to the host logger. */
    internal val logSinkForTest: NanoLogSink get() = SinkAdapter

    /** Session correlator — the CPR is hashed immediately and the raw value discarded. */
    fun noteCpr(cpr: String?) {
        client?.setCpr(cpr)
    }

    // ── Tees from the existing emission points ───────────────────────────────────────

    fun onState(state: NanoLoanState) {
        val to = NanoTelemetryMapper.stateName(state) ?: return
        val from = lastStateName
        lastStateName = to
        if (from == to) return
        record(
            NanoTelemetryContract.Kind.STATE,
            to,
            attrs = mapOf("from" to from, "to" to to)
        )
    }

    fun onFailure(error: NanoLoanError) {
        record(
            NanoTelemetryContract.Kind.ERROR,
            NanoTelemetryContract.EventName.SDK_ERROR,
            attrs = mapOf(
                "type" to NanoTelemetryMapper.errorType(error),
                // errorCode 0 means "the backend named none", which is not the same as 0.
                "code" to error.errorCode.takeIf { it != 0 }?.toString(),
                "httpStatus" to NanoTelemetryMapper.httpStatus(error),
                "recoverable" to NanoTelemetryMapper.recoverable(error)
            )
        )
    }

    /**
     * Every internal [NanoLoanEvent] that has a contract name. The ones with none —
     * `MockModeActive` (carried on `sdk_initialized.mocked` instead) — are dropped here
     * rather than renamed.
     */
    fun onEvent(event: NanoLoanEvent) {
        val lifecycle = NanoTelemetryContract.Lifecycle
        when (event) {
            is NanoLoanEvent.SessionAuthenticated ->
                record(NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.SESSION_AUTHENTICATED)

            is NanoLoanEvent.SessionExpired ->
                record(NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.SESSION_EXPIRED)

            is NanoLoanEvent.StepSkipped -> {
                val step = NanoTelemetryMapper.contractStep(event.stepName)
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.STEP_SKIPPED,
                    step = step, attrs = mapOf("step" to step)
                )
            }

            is NanoLoanEvent.InputRequired -> {
                val step = NanoTelemetryMapper.contractStep(event.step)
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.INPUT_REQUIRED,
                    step = step,
                    // Field KEYS only — never the values, which are the host's raw input.
                    attrs = mapOf("step" to step, "fieldCount" to event.fields.size)
                )
            }

            is NanoLoanEvent.StepInputSubmitted -> {
                val step = NanoTelemetryMapper.contractStep(event.step)
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.INPUT_SUBMITTED,
                    step = step, attrs = mapOf("step" to step)
                )
            }

            is NanoLoanEvent.EligibilityChecked -> {
                // v2 §3.2 asks for `preApprovedAmount` here. This platform does NOT send
                // one: its EligibilityResult is the Soouq blacklist response (restricted,
                // restrictedReason, remaining*) and carries no amount at all. The
                // indicative ceiling lives on PreApprovalResult.indicativeMaxAmount, which
                // is produced by a separate host-driven pre-approval call that does not
                // reach this event. iOS DOES send it, from EligibilityResult.maxLoanAmount.
                // Reported as a real platform gap rather than papered over with a guess.
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.ELIGIBILITY_CHECKED,
                    attrs = mapOf("restricted" to event.restricted)
                )
                if (!event.restricted) {
                    record(NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.PREAPPROVAL_SHOWN)
                }
            }

            // CONTRACT GAP: there is no `application_submitted` lifecycle name. The apply
            // funnel stage is expressed as completing the `apply` step instead.
            is NanoLoanEvent.ApplicationSubmitted ->
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.STEP_COMPLETED,
                    step = NanoTelemetryContract.Step.APPLY,
                    attrs = mapOf("step" to NanoTelemetryContract.Step.APPLY)
                )

            // The business attrs need the offer itself, which this event does not carry.
            // `NanoLoanSDK.getActiveOffer` calls `offerShown(offer)` directly with it.
            is NanoLoanEvent.OfferReceived -> Unit

            is NanoLoanEvent.SalaryVerified ->
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.SALARY_VERIFIED,
                    step = NanoTelemetryContract.Step.SALARY,
                    attrs = mapOf("method" to event.method)
                )

            is NanoLoanEvent.EmploymentDetailsSaved ->
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.EMPLOYMENT_SAVED,
                    step = NanoTelemetryContract.Step.EMPLOYMENT
                )

            is NanoLoanEvent.EmailOtpSent ->
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.OTP_REQUESTED,
                    step = NanoTelemetryContract.Step.OTP,
                    attrs = mapOf("channel" to "email", "autoVerified" to event.autoVerified)
                )

            is NanoLoanEvent.SmsOtpSent ->
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.OTP_REQUESTED,
                    step = NanoTelemetryContract.Step.OTP,
                    attrs = mapOf("channel" to "sms")
                )

            is NanoLoanEvent.AcceptanceOtpVerified ->
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.OTP_VERIFIED,
                    step = NanoTelemetryContract.Step.OTP
                )

            is NanoLoanEvent.OfferAccepted ->
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.OFFER_ACCEPTED,
                    step = NanoTelemetryContract.Step.OFFER,
                    attrs = if (businessMetrics) {
                        buildMap {
                            lastOfferFils?.let { put("amount", it) }
                            lastOfferTenorMonths?.let { put("tenorMonths", it) }
                        }
                    } else emptyMap()
                )

            // v2 §3.2 asks for `reasonCode` here. This SDK does NOT send one, and the
            // omission is deliberate: `declineOffer(reason)` carries whatever the customer
            // typed into the free-text field on NanoLoanRejectReasonFragment (the iOS twin
            // is the same). That is prose, not a code — useless as a §3.2
            // "rejection-reason breakdown" dimension, and a customer is perfectly capable
            // of typing a phone number into it. A coded reason needs a fixed reason LIST
            // on the reject screen first; until that exists there is nothing truthful to
            // put here.
            is NanoLoanEvent.OfferDeclined ->
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.OFFER_REJECTED,
                    step = NanoTelemetryContract.Step.OFFER
                )

            is NanoLoanEvent.DisbursementMethodSet ->
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.DISBURSEMENT_SET,
                    step = NanoTelemetryContract.Step.DISBURSEMENT,
                    // `type` is the v1 attr and stays ungated so existing consumers do not
                    // break; `method` is the v2 §3.2 name and is normalised across
                    // platforms, so the method-mix chart does not split one channel in two.
                    attrs = buildMap {
                        put("type", event.type)
                        if (businessMetrics) {
                            put("method", NanoTelemetryBusiness.disbursementMethod(event.type))
                        }
                    }
                )

            is NanoLoanEvent.ApiCallSimulated ->
                apiCall(event.method, event.path, event.httpStatus, event.durationMs, mocked = true)

            is NanoLoanEvent.ApiCallExecuted ->
                apiCall(event.method, event.path, event.httpStatus, event.durationMs, mocked = false)

            // ── v3 screens (SDK_V3_PRODUCT_GAPS §2/§4) ───────────────────────────────
            //
            // The contract's `step` set is CLOSED and has no member for the comparison,
            // KYC, final-check or mandate screens. Rather than map them onto an adjacent
            // step (which would silently corrupt the §5 funnel — the same reasoning as
            // NanoTelemetryMapper's dropped states), they are emitted with step = null
            // except where an existing member is genuinely correct: the comparison IS an
            // offer step and the signature IS the agreements step.

            is NanoLoanEvent.OfferComparisonShown ->
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.OFFER_COMPARISON_SHOWN,
                    step = NanoTelemetryContract.Step.OFFER,
                    attrs = mapOf("hostOfferPresent" to event.hostOfferPresent)
                )

            is NanoLoanEvent.OfferSelected ->
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.OFFER_SELECTED,
                    step = NanoTelemetryContract.Step.OFFER,
                    attrs = mapOf("source" to event.source.name.lowercase(Locale.US))
                )

            // Field KEYS only — the values are the customer's KYC answers.
            is NanoLoanEvent.KycDetailsSubmitted ->
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.KYC_DETAILS_SUBMITTED,
                    attrs = mapOf("fieldCount" to event.fields.size)
                )

            is NanoLoanEvent.FinalCheckStarted ->
                record(NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.FINAL_CHECK_STARTED)

            is NanoLoanEvent.FinalDecisionMade ->
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.FINAL_DECISION,
                    attrs = mapOf(
                        "outcome" to if (event.approved) "approved" else "declined",
                        "reasonCode" to event.reasonCode
                    )
                )

            is NanoLoanEvent.DocumentSigned ->
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.DOCUMENT_SIGNED,
                    step = NanoTelemetryContract.Step.AGREEMENTS,
                    attrs = mapOf(
                        "documentType" to event.documentType,
                        "signedAt" to event.signedAt
                    )
                )

            is NanoLoanEvent.DirectDebitSetup ->
                record(NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.DIRECT_DEBIT_SETUP)

            // The account is already masked by the emitting screen; the redactor is the
            // second line, not the first.
            is NanoLoanEvent.MandateAuthorised ->
                record(
                    NanoTelemetryContract.Kind.LIFECYCLE, lifecycle.MANDATE_AUTHORISED,
                    attrs = mapOf("account" to event.maskedAccount)
                )

            // No contract name; `mocked` already rides on sdk_initialized.
            is NanoLoanEvent.MockModeActive -> Unit
        }
    }

    private fun apiCall(
        method: String,
        path: String,
        status: Int,
        durationMs: Int,
        mocked: Boolean
    ) {
        record(
            NanoTelemetryContract.Kind.API_CALL,
            NanoTelemetryContract.EventName.HTTP_CALL,
            step = currentStep,
            attrs = mapOf(
                "method" to method.uppercase(Locale.US),
                // Query string stripped and id/IBAN segments templated — contract §3.
                "path" to NanoTelemetryRedactor.redactPath(path),
                "status" to status,
                // Contract §3 — REAL measured wall-clock time. Live calls are timed
                // around chain.proceed() in the OkHttp interceptor; mock calls are timed
                // around the mock data source's own delay. Never synthesised.
                "durationMs" to durationMs.coerceAtLeast(0),
                "mocked" to mocked,
                // The SDK's ApiCall events carry no server correlation id or error body;
                // txnId is only known on the error path, where kind:error reports it.
                "txnId" to null,
                "errorCode" to null
            )
        )
    }

    // ── Journey lifecycle, driven from the journey sheet ─────────────────────────────

    fun journeyStarted() {
        client?.startJourney()
        currentStep = null
        lastOfferFils = null
        lastOfferTenorMonths = null
        record(NanoTelemetryContract.Kind.LIFECYCLE, NanoTelemetryContract.Lifecycle.JOURNEY_STARTED)
    }

    fun journeyDismissed(completed: Boolean) {
        record(
            NanoTelemetryContract.Kind.LIFECYCLE,
            if (completed) NanoTelemetryContract.Lifecycle.JOURNEY_COMPLETED
            else NanoTelemetryContract.Lifecycle.JOURNEY_DISMISSED,
            step = currentStep
        )
        client?.endJourney()
        currentStep = null
        // Contract §1.5 / brief: flush on journey end.
        client?.flush()
    }

    /** Called when a journey step fragment becomes visible. */
    fun stepEntered(internalStepName: String) {
        val step = NanoTelemetryMapper.contractStep(internalStepName) ?: return
        val previous = currentStep
        if (previous != null && previous != step) {
            record(
                NanoTelemetryContract.Kind.LIFECYCLE, NanoTelemetryContract.Lifecycle.STEP_COMPLETED,
                step = previous, attrs = mapOf("step" to previous)
            )
        }
        currentStep = step
        record(
            NanoTelemetryContract.Kind.LIFECYCLE, NanoTelemetryContract.Lifecycle.STEP_ENTERED,
            step = step, attrs = mapOf("step" to step)
        )
        if (step == NanoTelemetryContract.Step.AGREEMENTS) {
            // The confirmation screen is only reachable once the agreement has been
            // accepted as part of the acceptance chain.
            record(
                NanoTelemetryContract.Kind.LIFECYCLE, NanoTelemetryContract.Lifecycle.AGREEMENTS_SIGNED,
                step = step
            )
        }
    }

    /**
     * v2 §3.2 — called by the SDK facade with the offer the customer is being shown, so
     * the amount/tenor/APR/instalment can ride along on `offer_shown`.
     */
    fun offerShown(offer: LoanOffer?) {
        val attrs = buildMap<String, Any?> {
            if (businessMetrics && offer != null) {
                val amount = NanoTelemetryBusiness.fils(offer.loanAmount)
                val tenor = NanoTelemetryBusiness.tenorMonths(offer.period, offer.periodType)
                amount?.let { put("amount", it) }
                tenor?.let { put("tenorMonths", it) }
                NanoTelemetryBusiness.aprPct(offer.interestRate)?.let { put("aprPct", it) }
                NanoTelemetryBusiness.fils(offer.installmentAmount)?.let {
                    put("monthlyInstalment", it)
                }
                if (amount != null) lastOfferFils = amount
                if (tenor != null) lastOfferTenorMonths = tenor
            }
        }
        record(
            NanoTelemetryContract.Kind.LIFECYCLE, NanoTelemetryContract.Lifecycle.OFFER_SHOWN,
            step = NanoTelemetryContract.Step.OFFER,
            attrs = attrs
        )
    }

    /**
     * NOTE: no call site. This SDK has no `reviseOffer` facade method — the iOS twin does
     * (`NanoLoanSDK.reviseOffer`), and its `offer_revised` carries the v2 §3.2
     * amount/tenorMonths from the revise REQUEST. Kept so the two bridges stay
     * symmetrical and so wiring it up later is a one-line change, but as of today an
     * Android session never emits `offer_revised`. Reported as a platform gap.
     */
    fun offerRevised() {
        record(
            NanoTelemetryContract.Kind.LIFECYCLE, NanoTelemetryContract.Lifecycle.OFFER_REVISED,
            step = NanoTelemetryContract.Step.OFFER
        )
    }

    /** App backgrounding — get what is buffered off the device before the process may die. */
    fun flush() {
        client?.flush()
    }

    // ── Log sink ─────────────────────────────────────────────────────────────────────

    private object SinkAdapter : NanoLogSink {
        override fun onLog(level: NanoLogLevel, tag: String, message: String, throwable: Throwable?) {
            // The telemetry pipeline's own diagnostics must not be re-ingested.
            if (tag == "NanoLoanTelemetry") return
            val wireLevel = NanoTelemetryMapper.logLevel(level) ?: return
            val safeMessage = NanoTelemetryRedactor.redactMessage(message) ?: return
            record(
                NanoTelemetryContract.Kind.LOG,
                NanoTelemetryContract.EventName.SDK_LOG,
                step = currentStep,
                attrs = mapOf("level" to wireLevel, "tag" to tag, "message" to safeMessage)
            )
        }
    }

    private fun record(
        kind: String,
        name: String,
        step: String? = null,
        attrs: Map<String, Any?> = emptyMap()
    ) {
        client?.record(kind, name, step, attrs)
    }
}
