package com.flooss.nanoloan.ui

import android.app.Dialog
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Outline
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ContextThemeWrapper
import android.view.ViewOutlineProvider
import androidx.activity.ComponentDialog
import androidx.activity.addCallback
import androidx.fragment.app.Fragment
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.config.NanoLoanLocale
import com.flooss.nanoloan.config.NanoLoanStep
import com.flooss.nanoloan.config.NanoStepOwner
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import java.util.Locale

/**
 * Journey host presented by [NanoLoanSDK.presentLoanOfferJourney] as a modal bottom
 * sheet over the host app (standard embedded-finance SDK pattern — replaces the earlier
 * full-screen NanoLoanJourneyActivity). The sheet opens expanded at
 * [SHEET_HEIGHT_FRACTION] of the screen with rounded top corners and a drag handle;
 * the host app stays visible/dimmed behind the top edge. Step navigation (1/4 pager,
 * back chevron in the themed header) lives INSIDE the sheet via the child fragment
 * manager:
 *
 *  1. [NanoLoanAmountDurationFragment]     <- :app fragment_loan_amount_and_duration ("1/4")
 *  2. [NanoLoanSalaryVerificationFragment] <- :app fragment_connect_to_bank + fragment_select_bank ("2/4")
 *  3. [NanoLoanApplyDetailFragment]        <- :app fragment_apply_loan_detail ("3/4")
 *  4. [NanoLoanOfferFragment]              <- :app fragment_loan_detail ("1/3" offer)
 *  5. [NanoLoanOtpFragment]                <- :app fragment_otp / LoanAcceptanceOTPFragment ("2/3")
 *  6. [NanoLoanConfirmationFragment]       (adapted accept-confirmation, "3/3")
 *
 * Dismiss protection: the sheet is NOT dismissible by swipe or outside tap mid-journey
 * (isCancelable=false, which also pins BottomSheetBehavior.isHideable=false; dragging is
 * disabled outright so the handle is a visual affordance only). Leaving the journey is
 * deliberate: the in-screen Cancel/Reject/Done actions, or the system back button which
 * first pops steps and only dismisses from the first step.
 */
internal class NanoLoanJourneySheetFragment : BottomSheetDialogFragment(), NanoLoanJourneyHost {

    override val journeyData = JourneyData()

    override fun getTheme(): Int = R.style.Theme_NanoLoanSheet

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(localizedContext(requireContext()), theme)

    /**
     * NanoLoanLocale drives resource selection (values-ar strings) exactly like the real
     * app's manual locale switch. The real app ships supportsRtl=false and mirrors
     * Arabic manually via -ar resources, so layout direction stays pinned to LTR
     * (open RTL-architecture question the solution design tracks — not solved here).
     *
     * Implemented as a ContextThemeWrapper over the ACTIVITY context (not
     * createConfigurationContext, which returns a plain Context without the activity's
     * window token and makes Dialog.show throw BadTokenException).
     */
    private fun localizedContext(base: Context): Context {
        val locale = try {
            when (NanoLoanSDK.currentConfiguration().locale) {
                NanoLoanLocale.ARABIC -> Locale("ar")
                NanoLoanLocale.ENGLISH -> Locale("en")
            }
        } catch (e: IllegalStateException) {
            Locale("en")
        }
        val override = Configuration()
        override.setLocale(locale)
        override.setLayoutDirection(Locale.ENGLISH)
        val wrapper = ContextThemeWrapper(base, theme)
        wrapper.applyOverrideConfiguration(override)
        return wrapper
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_journey_sheet, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        isCancelable = false
        // Pin the journey's view hierarchy to LTR (production framing: Arabic strings
        // on an LTR skeleton) regardless of the host app's supportsRtl.
        view.layoutDirection = View.LAYOUT_DIRECTION_LTR

        val brandTheme = NanoLoanSDK.currentConfiguration().theme
        view.background.mutate().setTint(brandTheme.secondaryColor)
        val cornerPx = SHEET_CORNER_RADIUS_DP * resources.displayMetrics.density
        view.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, outline: Outline) {
                // Bottom corners pushed off-view so only the top edge reads as rounded.
                outline.setRoundRect(0, 0, v.width, v.height + cornerPx.toInt(), cornerPx)
            }
        }
        view.clipToOutline = true

        if (savedInstanceState == null) {
            show(NanoLoanAmountDurationFragment(), addToBackStack = false)
        }

        (requireDialog() as ComponentDialog).onBackPressedDispatcher
            .addCallback(viewLifecycleOwner) { navigateBack() }
    }

    override fun onStart() {
        super.onStart()
        val dialog = requireDialog() as BottomSheetDialog
        dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.let { sheet ->
            // The rounded corners come from this fragment's own clipped root; the
            // framework sheet frame behind it must not paint its own background.
            sheet.setBackgroundColor(Color.TRANSPARENT)
            sheet.layoutParams = sheet.layoutParams.apply {
                height = (resources.displayMetrics.heightPixels * SHEET_HEIGHT_FRACTION).toInt()
            }
        }
        dialog.behavior.apply {
            state = BottomSheetBehavior.STATE_EXPANDED
            skipCollapsed = true
            isDraggable = false
        }
    }

    override fun isMockMode(): Boolean = NanoLoanSDK.currentConfiguration().isMockMode

    /**
     * Step-ownership switch, employment details (§3.5 Options A/B): SDK-owned shows the
     * ported real screen 2/4; HOST-owned pauses the sheet, emits InputRequired and — once
     * the host calls submitStepInput — still runs the REAL save call itself (the SDK
     * stays authoritative over the flow, §9.5) before moving on.
     */
    override fun goToEmploymentDetails() {
        if (NanoLoanSDK.ownerOf(NanoLoanStep.EMPLOYMENT_DETAILS) == NanoStepOwner.HOST) {
            pauseForHostInput(
                NanoLoanStep.EMPLOYMENT_DETAILS,
                listOf("companyName", "jobTitle", "startDate")
            ) { values ->
                val details = com.flooss.nanoloan.model.EmploymentDetails(
                    companyName = values["companyName"].orEmpty(),
                    jobTitle = values["jobTitle"].orEmpty(),
                    startDate = values["startDate"].orEmpty()
                )
                journeyData.employmentDetails = details
                NanoLoanSDK.saveEmploymentDetails(details) { }
                goToSalaryVerification()
            }
        } else {
            show(NanoLoanEmploymentDetailFragment())
        }
    }

    /** Step-ownership switch, salary verification — HOST-owned skips the SDK screen. */
    override fun goToSalaryVerification() {
        if (NanoLoanSDK.ownerOf(NanoLoanStep.SALARY_VERIFICATION) == NanoStepOwner.HOST) {
            pauseForHostInput(NanoLoanStep.SALARY_VERIFICATION, listOf("method")) { values ->
                journeyData.salaryVerificationMethod = values["method"] ?: "HOST_PROVIDED"
                goToApplyDetail()
            }
        } else {
            show(NanoLoanSalaryVerificationFragment())
        }
    }

    /**
     * §2.2 — the comparison only exists when the host supplied its own offer. With none
     * the journey falls straight through to the step after it, exactly as it behaved
     * before v3 (the single-offer screen later in the journey is unchanged).
     */
    override fun goToOfferComparison() {
        if (NanoLoanSDK.currentHostOffer() == null) {
            NanoLoanSDK.notifyOfferComparisonShown(hostOfferPresent = false)
            goToOffer()
        } else {
            show(NanoLoanOfferComparisonFragment())
        }
    }

    /**
     * §2.3 — additional KYC details. Skipped entirely when the host configured an empty
     * field list (it has nothing to ask), and HOST-owned hands collection to the host.
     */
    override fun goToKycDetails() {
        val fields = NanoLoanSDK.currentConfiguration().resolvedKycFields(resources)
        if (fields.isEmpty()) {
            goToDisbursementChannel()
            return
        }
        if (NanoLoanSDK.ownerOf(NanoLoanStep.KYC_DETAILS) == NanoStepOwner.HOST) {
            pauseForHostInput(NanoLoanStep.KYC_DETAILS, fields.map { it.key }) { values ->
                journeyData.kycDetails = values
                NanoLoanSDK.notifyKycDetailsSubmitted(values.keys.toList())
                goToDisbursementChannel()
            }
        } else {
            show(NanoLoanKycDetailsFragment())
        }
    }

    /**
     * §2.4 — the second-phase decision. HOST-owned pauses for the host to run its own
     * bureau check and hand back the outcome, exactly like the v1 ownership-configurable
     * steps; the SDK then continues the flow.
     */
    override fun goToFinalCheck() {
        if (NanoLoanSDK.ownerOf(NanoLoanStep.FINAL_CHECK) == NanoStepOwner.HOST) {
            pauseForHostInput(NanoLoanStep.FINAL_CHECK, listOf("approved", "reasonCode")) { values ->
                val approved = values["approved"]?.toBooleanStrictOrNull() ?: false
                journeyData.finalDecisionApproved = approved
                journeyData.finalDecisionReason = values["reasonCode"]
                if (approved) goToSignature() else finishJourney()
            }
        } else {
            show(NanoLoanFinalCheckFragment())
        }
    }

    /**
     * §2.6 — digital signature. HOST-owned hands the ceremony to the host (its own
     * signature vendor, for instance) and resumes once it reports back.
     */
    override fun goToSignature() {
        if (NanoLoanSDK.ownerOf(NanoLoanStep.DIGITAL_SIGNATURE) == NanoStepOwner.HOST) {
            pauseForHostInput(NanoLoanStep.DIGITAL_SIGNATURE, listOf("signedAt")) { values ->
                val signedAt = values["signedAt"].orEmpty()
                journeyData.agreementSignedAt = signedAt
                NanoLoanSDK.notifyDocumentSigned("financing_agreement", signedAt)
                goToDirectDebitMandate()
            }
        } else {
            show(NanoLoanSignatureFragment())
        }
    }

    /** §2.5 — direct-debit mandate, the last step before the journey ends. */
    override fun goToDirectDebitMandate() {
        if (NanoLoanSDK.ownerOf(NanoLoanStep.DIRECT_DEBIT_MANDATE) == NanoStepOwner.HOST) {
            pauseForHostInput(NanoLoanStep.DIRECT_DEBIT_MANDATE, listOf("maskedAccount")) { values ->
                val masked = values["maskedAccount"].orEmpty()
                journeyData.mandateMaskedAccount = masked
                NanoLoanSDK.notifyMandateAuthorised(masked)
                goToConfirmation()
            }
        } else {
            show(NanoLoanDirectDebitFragment())
        }
    }

    override fun goToApplyDetail() = show(NanoLoanApplyDetailFragment())

    override fun goToOffer() = show(NanoLoanOfferFragment())

    override fun goToDisbursementChannel() = show(NanoLoanDisbursementChannelFragment())

    override fun goToDisbursementIban() = show(NanoLoanDisbursementIbanFragment())

    override fun goToRejectReason() = show(NanoLoanRejectReasonFragment())

    /**
     * Step-ownership switch, email verification: the email-OTP leg of the acceptance
     * chain fires right before the SMS-OTP screen — HOST-owned pauses for the host to
     * run its own email verification before the SDK's OTP entry appears.
     */
    override fun goToOtp() {
        if (NanoLoanSDK.ownerOf(NanoLoanStep.EMAIL_VERIFICATION) == NanoStepOwner.HOST) {
            pauseForHostInput(NanoLoanStep.EMAIL_VERIFICATION, listOf("emailOtp")) {
                show(NanoLoanOtpFragment())
            }
        } else {
            show(NanoLoanOtpFragment())
        }
    }

    override fun goToConfirmation() {
        reachedConfirmation = true
        show(NanoLoanConfirmationFragment())
    }

    /**
     * Distinguishes `journey_completed` from `journey_dismissed` for telemetry: the
     * confirmation screen is only reachable after the acceptance chain has passed.
     */
    private var reachedConfirmation = false

    override fun onDismiss(dialog: android.content.DialogInterface) {
        super.onDismiss(dialog)
        NanoLoanSDK.notifyJourneyFinished(completed = reachedConfirmation)
    }

    /**
     * Option B pause: hide the sheet (the host app becomes fully visible/interactive to
     * render its own input UI), register the resume continuation with the facade, and
     * re-show once [NanoLoanSDK.submitStepInput] delivers the values.
     */
    private fun pauseForHostInput(
        step: NanoLoanStep,
        fields: List<String>,
        onResume: (Map<String, String>) -> Unit
    ) {
        NanoLoanSDK.requestHostInput(step, fields) { values ->
            if (!isAdded) return@requestHostInput
            dialog?.show()
            onResume(values)
        }
        dialog?.hide()
    }

    override fun navigateBack() {
        if (childFragmentManager.backStackEntryCount > 0) {
            childFragmentManager.popBackStack()
        } else {
            dismiss()
        }
    }

    override fun finishJourney() = dismiss()

    private fun show(fragment: Fragment, addToBackStack: Boolean = true) {
        val transaction = childFragmentManager.beginTransaction()
            .replace(R.id.nanoloan_sheet_container, fragment)
        if (addToBackStack) transaction.addToBackStack(null)
        transaction.commit()
    }

    companion object {
        const val TAG = "nanoloan_journey_sheet"
        private const val SHEET_CORNER_RADIUS_DP = 24f
        private const val SHEET_HEIGHT_FRACTION = 0.93
    }
}
