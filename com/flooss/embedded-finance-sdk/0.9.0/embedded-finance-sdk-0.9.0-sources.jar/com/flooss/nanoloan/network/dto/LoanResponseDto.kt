package com.flooss.nanoloan.network.dto

import java.math.BigDecimal

/**
 * Wire shape shared by `POST api/v1/fo/loans` (`LoanApi.create`), `GET
 * api/v1/fo/offers/active` (`LoanApi.getActiveOffer`), `POST .../accept`
 * (`LoanApi.acceptOfferNormal`) and `POST .../decline` (`LoanApi.rejectOffer`) — all four
 * return the app's `Loan` response shape. Trimmed to the fields this POC reads; the real
 * `Loan` DTO (`data/model/api/response/Loan.kt`) has ~100 fields covering every loan
 * lifecycle stage (installments, BNPL, disbursement, deferment, etc.) out of scope here.
 */
data class LoanResponseDto(
    val id: Long?,
    val guid: String?,
    val status: String?,
    val loanAmount: BigDecimal?,
    val principalAmount: BigDecimal?,
    val installmentAmount: BigDecimal?,
    val totalAmount: BigDecimal?,
    val interestRate: String?,
    val period: Long?,
    val periodType: String?,
    val anyActiveOfferExists: Boolean = false,
    val offerExpiryDate: String? = null,
    val product: LoanProductDto? = null
)

data class LoanProductDto(
    val id: Long?,
    val name: String?
)
