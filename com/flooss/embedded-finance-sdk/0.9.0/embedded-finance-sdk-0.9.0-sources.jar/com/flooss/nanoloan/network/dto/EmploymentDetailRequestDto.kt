package com.flooss.nanoloan.network.dto

/**
 * Body of `POST api/v1/fo/client-profile/employment-details` — mirrors the app's
 * `EmployeeDetailReq` (companyName / jobTitle / empStartDate) field-for-field.
 */
internal data class EmploymentDetailRequestDto(
    val companyName: String?,
    val jobTitle: String?,
    val empStartDate: String?
)
