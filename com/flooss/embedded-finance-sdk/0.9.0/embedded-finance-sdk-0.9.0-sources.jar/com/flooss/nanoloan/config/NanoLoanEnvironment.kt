package com.flooss.nanoloan.config

/**
 * Target backend for the SDK's networking layer.
 *
 * DEV/QA/UAT/PROD hit the real Salaf backend at [NanoLoanConfiguration.loanBaseUrl]
 * (see design doc §6.4 — the app's `SERVER_URL_SALAF` per-flavor values). MOCK never
 * makes a network call: [com.flooss.nanoloan.repo.NanoLoanRepository] routes to
 * [com.flooss.nanoloan.repo.MockNanoLoanDataSource] instead, which returns canned
 * successful responses after a short delay. Used by the sample host app so the full
 * journey + callback sequence can be demonstrated without live network access.
 */
enum class NanoLoanEnvironment {
    DEV,
    QA,
    UAT,
    PROD,
    MOCK
}
