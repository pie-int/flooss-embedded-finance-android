package com.flooss.nanoloan.model

/**
 * Credential handoff (design doc §7.2 Model B) — the host hands the customer's CPR +
 * Flooss PIN to the SDK, which runs the real Salaf OAuth2 password grant itself
 * (`POST api/v1/oauth/token`, ported from the app's `SalafAuthTokenApi.hitSalafLoginApi`).
 *
 * Held IN MEMORY ONLY for the process lifetime (never persisted, never logged — see
 * [toString]); used once to log in and at most once more per journey call to re-auth
 * after a 401 before the SDK gives up with
 * [com.flooss.nanoloan.listener.NanoLoanEvent.SessionExpired].
 */
data class NanoLoanCredentials(
    val cpr: String,
    val pin: String
) {
    /** Never leak the CPR/PIN through logs or event descriptions. */
    override fun toString(): String = "NanoLoanCredentials(cpr=•••, pin=•••)"
}
