package com.flooss.nanoloan.session

import com.flooss.nanoloan.model.NanoLoanToken

/**
 * SDK-scoped, in-memory session state — the functional equivalent of the app's
 * `InMemoryHolder.salafAccessToken` field (design doc §2.1, §7.3), but scoped to this
 * SDK instance rather than a single app-wide `object` shared with wallet-domain state.
 *
 * Deferred from the design doc's target §7.3 shape: Keystore-backed
 * `EncryptedSharedPreferences` persistence across process death, proactive refresh, and
 * refresh serialization against concurrent 401s. This POC only holds the token
 * in-memory for the process lifetime — acceptable for a proof-of-concept slice, not for
 * production (see report backlog).
 */
internal class NanoLoanSession {
    @Volatile
    var token: NanoLoanToken? = null
        private set

    /**
     * Model B (credential handoff) only — the CPR/PIN pair held IN MEMORY ONLY (never
     * persisted, never logged; [com.flooss.nanoloan.model.NanoLoanCredentials.toString]
     * redacts) so the repository can attempt exactly ONE re-auth after a 401 mid-journey
     * before giving up with SessionExpired. Model A (token handoff) leaves this null.
     */
    @Volatile
    var credentials: com.flooss.nanoloan.model.NanoLoanCredentials? = null

    /**
     * `LoanOffer.id` (the loan application id) from the last `getActiveOffer()` call,
     * keyed by its `offerGuid` — resolves the id/offerGuid pair the real
     * `acceptOfferNormal`/`rejectOffer` endpoints need from the facade's
     * `acceptOffer(offerId)`/`declineOffer(offerId)`, which only take the guid.
     */
    private val offerApplicationIds = mutableMapOf<String, Long>()

    fun authenticate(token: NanoLoanToken) {
        this.token = token
    }

    fun clear() {
        token = null
        credentials = null
        offerApplicationIds.clear()
    }

    fun bearerToken(): String? = token?.accessToken?.let { "Bearer $it" }

    fun rememberOffer(offerGuid: String, applicationId: Long) {
        offerApplicationIds[offerGuid] = applicationId
    }

    fun applicationIdFor(offerGuid: String): Long? = offerApplicationIds[offerGuid]
}
