package com.flooss.nanoloan.ui

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.appcompat.widget.AppCompatTextView
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.model.EmploymentDetails
import com.flooss.nanoloan.result.NanoLoanResult
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputEditText
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Step 2 — REAL screen port of :app `EmploymentDetailFragment` +
 * `fragment_employment_details.xml` ("fill the missing details", real Apply Loan screen
 * 2/4): employer/company autocomplete, job title, DatePicker start date, per-field error
 * labels. This is also the SDK-owned (Option A) implementation of the
 * [com.flooss.nanoloan.config.NanoLoanStep.EMPLOYMENT_DETAILS] step — when the host
 * configures HOST ownership the sheet never shows this screen and pauses for
 * `submitStepInput` instead.
 *
 * Save = the real `POST api/v1/fo/client-profile/employment-details`
 * (`UserProfileApi.saveEmploymentDetailsApi`). The real screen also loads the private
 * companies list (`GET api/v1/fo/companies/private`) for the autocomplete; the SDK slice
 * ships a canned employer list instead of porting the profile-API surface (backlog).
 */
internal class NanoLoanEmploymentDetailFragment : NanoLoanJourneyFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_employment_details, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme

        setUpHeader(
            headerRoot = view.findViewById(R.id.header_layout),
            title = getString(R.string.employment_details),
            dotCount = 4,
            dotIndex = 2,
            screenNumber = "2/12",
            stepName = STEP_NAME
        ) {
            journeyHost.goToSalaryVerification()
        }
        NanoLoanThemeApplier.applyChromeBackground(view.findViewById(R.id.rootLayout), theme)

        val companyName = view.findViewById<MaterialAutoCompleteTextView>(R.id.company_name)
        val jobTitle = view.findViewById<TextInputEditText>(R.id.job_title)
        val startDate = view.findViewById<TextInputEditText>(R.id.start_date)
        val companyError = view.findViewById<View>(R.id.comapny_name_error)
        val jobError = view.findViewById<View>(R.id.job_title_error)
        val dateError = view.findViewById<View>(R.id.start_date_error)

        // The real screen's autocomplete is fed by GET fo/companies/private; canned here.
        companyName.setAdapter(
            ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, DEMO_EMPLOYERS)
        )
        journeyData.employmentDetails?.let {
            companyName.setText(it.companyName)
            jobTitle.setText(it.jobTitle)
            startDate.setText(it.startDate)
        }

        // Same picker rules as the real screen: min 1980-01-01, max today, yyyy-MM-dd.
        startDate.setOnClickListener { showStartDatePicker(startDate) }

        val nextBtn = view.findViewById<View>(R.id.next_btn)
        NanoLoanThemeApplier.applyPrimaryButton(nextBtn, theme)
        nextBtn.setOnClickListener {
            val company = companyName.text?.toString()?.trim().orEmpty()
            val job = jobTitle.text?.toString()?.trim().orEmpty()
            val date = startDate.text?.toString()?.trim().orEmpty()
            companyError.visibility = if (company.isEmpty()) View.VISIBLE else View.INVISIBLE
            jobError.visibility = if (job.isEmpty()) View.VISIBLE else View.INVISIBLE
            dateError.visibility = if (date.isEmpty()) View.VISIBLE else View.INVISIBLE
            if (company.isEmpty() || job.isEmpty() || date.isEmpty()) return@setOnClickListener

            val details = EmploymentDetails(companyName = company, jobTitle = job, startDate = date)
            journeyData.employmentDetails = details
            val progress = view.findViewById<View>(R.id.progress_bar)
            progress.visibility = View.VISIBLE
            NanoLoanSDK.saveEmploymentDetails(details) { result ->
                if (!isAdded) return@saveEmploymentDetails
                progress.visibility = View.GONE
                if (result is NanoLoanResult.Success) {
                    journeyHost.goToSalaryVerification()
                }
            }
        }
        view.findViewById<AppCompatTextView>(R.id.tv_cancel).setOnClickListener {
            journeyHost.finishJourney()
        }
    }

    private fun showStartDatePicker(target: TextInputEditText) {
        val now = Calendar.getInstance(Locale.ENGLISH)
        val dialog = DatePickerDialog(
            requireContext(),
            { _, year, month, day ->
                val selected = Calendar.getInstance(Locale.ENGLISH)
                selected.set(year, month, day)
                target.setText(
                    SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(selected.time)
                )
            },
            now.get(Calendar.YEAR),
            now.get(Calendar.MONTH),
            now.get(Calendar.DAY_OF_MONTH)
        )
        val min = Calendar.getInstance(Locale.ENGLISH)
        min.set(1980, 0, 1)
        dialog.datePicker.minDate = min.timeInMillis
        dialog.datePicker.maxDate = now.timeInMillis
        dialog.show()
    }

    companion object {
        const val STEP_NAME = "employment_details"

        // Canned stand-in for GET api/v1/fo/companies/private (real Bahrain employers).
        private val DEMO_EMPLOYERS = listOf(
            "Batelco",
            "Gulf Air",
            "Aluminium Bahrain (Alba)",
            "National Bank of Bahrain",
            "Bahrain Petroleum Company (Bapco)",
            "Zain Bahrain",
            "Ministry of Health"
        )
    }
}
