package com.flooss.nanoloan.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.repo.MockNanoLoanDataSource
import com.flooss.nanoloan.R
import com.google.android.material.slider.Slider
import com.google.android.material.textfield.TextInputEditText

/**
 * Step 1 — REAL screen port of :app `LoanAmountAndDurationFragment` +
 * `fragment_loan_amount_and_duration.xml` ("Apply for financing", dots 1/4).
 * Bindings that the real fragment fills from remote product config are filled from
 * canned defaults matching the SDK's MockNanoLoanDataSource (300 BHD / 3 months);
 * slider math (installment/total estimates) is the real AppUtil formula (NanoLoanMath).
 */
internal class NanoLoanAmountDurationFragment : NanoLoanJourneyFragment() {

    private lateinit var estimateAdapter: EstimateRowsAdapter

    private lateinit var amountInclude: View
    private lateinit var tenorInclude: View

    /** §2.1 — the selected instalment count, driven by the chips instead of a slider. */
    private var selectedTenorMonths: Int = 1

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_loan_amount_and_duration, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme

        setUpHeader(
            headerRoot = view.findViewById(R.id.header_layout),
            title = getString(R.string.apply_for_loan_heading),
            dotCount = 4,
            dotIndex = 1,
            screenNumber = "1/12",
            stepName = STEP_NAME
        ) {
            captureSelection(view)
            journeyHost.goToEmploymentDetails()
        }
        NanoLoanThemeApplier.applyChromeBackground(view.findViewById(R.id.rootLayout), theme)

        // Journey-entry prerequisites, in the real Apply Loan flow's order
        // (API_SEQUENCE_FLOWS §4.1 steps 2–3): product envelope + active-loan check.
        // Fired once per journey; results only tighten the canned slider bounds.
        if (savedInstanceState == null && !journeyData.prerequisitesLoaded) {
            journeyData.prerequisitesLoaded = true
            NanoLoanSDK.getLoanProducts { }
            NanoLoanSDK.getActiveLoan { }
        }

        view.findViewById<TextInputEditText>(R.id.et_loan_name).setText(journeyData.loanName)

        amountInclude = view.findViewById(R.id.amount)
        tenorInclude = view.findViewById(R.id.duration)

        // The nano product's bounds - the same ceiling the pre-approval screen showed.
        val minAmount = MockNanoLoanDataSource.MOCK_MIN_AMOUNT
        val maxAmount = MockNanoLoanDataSource.MOCK_MAX_AMOUNT
        setUpSliderCard(
            amountInclude,
            title = getString(R.string.loan_amount),
            type = getString(R.string.bhd_app_text),
            min = minAmount, max = maxAmount,
            value = journeyData.loanAmount.coerceIn(minAmount, maxAmount)
        )
        setUpTenorChips()

        estimateAdapter = EstimateRowsAdapter(emptyList())
        view.findViewById<RecyclerView>(R.id.rv_installment_details).apply {
            adapter = estimateAdapter
            layoutManager = LinearLayoutManager(requireContext())
        }

        setUpDueDates(view)
        refreshEstimates()

        amountInclude.findViewById<Slider>(R.id.slider).addOnChangeListener { _, value, _ ->
            amountInclude.findViewById<EditText>(R.id.number).setText(value.toInt().toString())
            refreshEstimates()
        }

        val nextBtn = view.findViewById<View>(R.id.next_btn)
        nextBtn.isEnabled = true
        NanoLoanThemeApplier.applyPrimaryButton(nextBtn, theme)
        nextBtn.setOnClickListener {
            captureSelection(view)
            journeyHost.goToEmploymentDetails()
        }
        view.findViewById<View>(R.id.tv_cancel).setOnClickListener {
            journeyHost.finishJourney()
        }
    }

    private fun setUpSliderCard(include: View, title: String, type: String, min: Int, max: Int, value: Int) {
        include.findViewById<TextView>(R.id.title).text = title
        include.findViewById<TextView>(R.id.type).text = type
        include.findViewById<TextView>(R.id.min).text = min.toString()
        include.findViewById<TextView>(R.id.max).text = max.toString()
        include.findViewById<EditText>(R.id.number).setText(value.toString())
        include.findViewById<Slider>(R.id.slider).apply {
            valueFrom = min.toFloat()
            valueTo = max.toFloat()
            this.value = value.toFloat()
        }
    }

    /**
     * §2.1 — discrete instalment counts from [com.flooss.nanoloan.config.NanoLoanConfiguration
     * .tenorOptions], capped by `maxTenorMonths`. Options above the cap render disabled
     * WITH the reason underneath rather than being dropped from the list.
     */
    private fun setUpTenorChips() {
        val config = NanoLoanSDK.currentConfiguration()
        val options = config.resolvedTenorOptions
        val cap = config.maxTenorMonths
        selectedTenorMonths = journeyData.loanDurationMonths
            .takeIf { it in options && it <= cap }
            ?: config.defaultTenorMonths

        val container = tenorInclude.findViewById<LinearLayout>(R.id.tenor_options)
        container.removeAllViews()
        options.forEach { months ->
            val chip = layoutInflater.inflate(R.layout.nanoloan_item_tenor, container, false)
            (chip.layoutParams as LinearLayout.LayoutParams).weight = 1f
            chip.findViewById<TextView>(R.id.tenor_value).text = months.toString()
            chip.findViewById<TextView>(R.id.tenor_unit).text = getString(
                if (months == 1) R.string.nanoloan_month_singular else R.string.nanoloan_month_plural
            )
            val enabled = months <= cap
            chip.findViewById<View>(R.id.tenor_card).apply {
                isEnabled = enabled
                if (enabled) setOnClickListener { selectTenor(months) }
            }
            chip.alpha = if (enabled) 1f else DISABLED_CHIP_ALPHA
            container.addView(chip)
        }

        val reason = tenorInclude.findViewById<TextView>(R.id.tenor_cap_reason)
        if (options.any { it > cap }) {
            reason.text = getString(R.string.nanoloan_tenor_cap_reason, cap)
            reason.visibility = View.VISIBLE
        } else {
            reason.visibility = View.GONE
        }

        selectTenor(selectedTenorMonths)
    }

    /** Applies the chip highlight and recomputes the instalment preview. */
    private fun selectTenor(months: Int) {
        selectedTenorMonths = months
        journeyData.loanDurationMonths = months
        val container = tenorInclude.findViewById<LinearLayout>(R.id.tenor_options)
        val options = NanoLoanSDK.currentConfiguration().resolvedTenorOptions
        options.forEachIndexed { index, value ->
            val chip = container.getChildAt(index) ?: return@forEachIndexed
            val selected = value == months
            val bg = if (selected) R.color.app_orange else R.color.white
            val text = if (selected) R.color.app_white else R.color.black
            chip.findViewById<View>(R.id.tenor_card)
                .setBackgroundColor(ResourcesCompat.getColor(resources, bg, null))
            val color = ResourcesCompat.getColor(resources, text, null)
            chip.findViewById<TextView>(R.id.tenor_value).setTextColor(color)
            chip.findViewById<TextView>(R.id.tenor_unit).setTextColor(color)
        }
        refreshEstimates()
    }

    private fun setUpDueDates(view: View) {
        val layout27 = view.findViewById<View>(R.id.layout_27th)
        val layout4 = view.findViewById<View>(R.id.layout_4th)
        layout27.findViewById<TextView>(R.id.tv_date).text = getString(R.string.due_date_title_27)
        layout27.findViewById<TextView>(R.id.tv_month).text = getString(R.string.title_current_month)
        layout4.findViewById<TextView>(R.id.tv_date).text = getString(R.string.due_date_title_4)
        layout4.findViewById<TextView>(R.id.tv_month).text = getString(R.string.title_next_month)

        layout27.findViewById<View>(R.id.layout_main_card).setOnClickListener { selectDueDate(view, 27) }
        layout4.findViewById<View>(R.id.layout_main_card).setOnClickListener { selectDueDate(view, 4) }
        selectDueDate(view, journeyData.selectedRepaymentDate)
    }

    /** Same highlight the real fragment applies: orange card + white text when selected. */
    private fun selectDueDate(view: View, day: Int) {
        journeyData.selectedRepaymentDate = day
        applyDueDateCard(view.findViewById(R.id.layout_27th), selected = day == 27)
        applyDueDateCard(view.findViewById(R.id.layout_4th), selected = day == 4)
        refreshEstimates()
    }

    private fun applyDueDateCard(item: View, selected: Boolean) {
        val card = item.findViewById<View>(R.id.layout_main_card)
        val res = resources
        val bg = if (selected) R.color.app_orange else R.color.white
        val text = if (selected) R.color.app_white else R.color.black
        card.setBackgroundColor(ResourcesCompat.getColor(res, bg, null))
        val textColor = ResourcesCompat.getColor(res, text, null)
        item.findViewById<TextView>(R.id.tv_date).setTextColor(textColor)
        item.findViewById<TextView>(R.id.tv_th).setTextColor(textColor)
        item.findViewById<TextView>(R.id.tv_month).setTextColor(textColor)
    }

    private fun refreshEstimates() {
        // The chips select a default during setup, before the estimate list exists;
        // onViewCreated's own refreshEstimates() fills the rows once it does.
        if (!this::tenorInclude.isInitialized || !this::estimateAdapter.isInitialized) return
        val amount = amountInclude.findViewById<Slider>(R.id.slider).value
        val duration = selectedTenorMonths
        estimateAdapter.update(
            listOf(
                KeyValueRow(
                    getString(R.string.monthly_payment),
                    getString(R.string.amount_bhd, NanoLoanMath.getInstallmentToPay(amount, duration))
                ),
                KeyValueRow(
                    getString(R.string.total_amount_to_pay),
                    getString(R.string.amount_bhd, NanoLoanMath.getTotalToPay(amount, duration))
                ),
                KeyValueRow(
                    getString(R.string.expected_first_payment_date),
                    NanoLoanMath.expectedFirstPaymentDate(journeyData.selectedRepaymentDate)
                ),
                KeyValueRow(
                    getString(R.string.expected_end_month),
                    NanoLoanMath.expectedEndMonth(journeyData.selectedRepaymentDate, duration)
                )
            )
        )
    }

    private fun captureSelection(view: View) {
        journeyData.loanName = view.findViewById<TextInputEditText>(R.id.et_loan_name)
            .text?.toString().orEmpty().ifBlank { "My Finance" }
        journeyData.loanAmount = amountInclude.findViewById<Slider>(R.id.slider).value.toInt()
        journeyData.loanDurationMonths = selectedTenorMonths
    }

    companion object {
        const val STEP_NAME = "amount_and_duration"

        /** Above-cap chips stay legible — greyed, not hidden (§2.1). */
        private const val DISABLED_CHIP_ALPHA = 0.4f
    }
}
