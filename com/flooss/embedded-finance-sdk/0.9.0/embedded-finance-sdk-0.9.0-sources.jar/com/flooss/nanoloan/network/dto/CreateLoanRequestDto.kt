package com.flooss.nanoloan.network.dto

import java.math.BigDecimal

/**
 * Wire shape of the body `POST api/v1/fo/loans` expects — a trimmed mirror of the app's
 * `CreateLoanReq`/`LoanEmployment` (`data/model/api/request/CreateLoanReq.kt`), same
 * field names for the subset this POC sends.
 */
data class CreateLoanRequestDto(
    val employment: LoanEmploymentDto,
    val loanAmount: BigDecimal,
    val loanPeriod: Long,
    val loanPeriodType: String,
    val productId: Long?,
    val loanPurposeId: Long?
)

data class LoanEmploymentDto(
    val employmentType: String,
    val employerName: String?,
    val occupation: String?,
    val monthlySalary: BigDecimal
)
