package com.flooss.nanoloan.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.result.NanoLoanResult
import com.google.android.material.textfield.TextInputEditText

/**
 * Reject-with-reason — REAL screen port of :app `LoanRejectReasonFragment` +
 * `fragment_loan_reject_reason.xml` ("Reject Reason"). Reached from the offer screen's
 * Reject button after the ported reject-confirmation bottom sheet
 * (`nanoloan_reject_confirmation_sheet.xml` <- app_loan_reject_confirmation_bottom_sheet).
 * Next fires the real `POST api/v1/fo/loans/{id}/offers/{offerGuid}/decline` with the
 * typed reason (the app's LoanOfferDeclineRequest {reason, rejectedAt, offerGuid}).
 */
internal class NanoLoanRejectReasonFragment : NanoLoanJourneyFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_reject_reason, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme

        setUpHeader(
            headerRoot = view.findViewById(R.id.header),
            title = getString(R.string.reject_reason),
            dotCount = 3,
            dotIndex = 1,
            screenNumber = "",
            stepName = STEP_NAME,
            onSkip = null
        )
        // The real screen uses the dot-less common_header_layout — hide the indicator
        // (INVISIBLE, not GONE: the title's RelativeLayout anchor chain ends at it).
        view.findViewById<View>(R.id.header).findViewById<View>(R.id.screen_indicator)
            .visibility = View.INVISIBLE
        NanoLoanThemeApplier.applyChromeBackground(view.findViewById(R.id.parent_layout), theme)

        val reasonField = view.findViewById<TextInputEditText>(R.id.et_reject_reason)
        val nextBtn = view.findViewById<View>(R.id.next_btn)
        NanoLoanThemeApplier.applyPrimaryButton(nextBtn, theme)
        nextBtn.setOnClickListener {
            val reason = reasonField.text?.toString()?.trim().orEmpty()
            if (reason.isEmpty()) {
                reasonField.error = getString(R.string.insert_reason)
                return@setOnClickListener
            }
            val offer = journeyData.offer ?: run {
                journeyHost.finishJourney()
                return@setOnClickListener
            }
            val progress = view.findViewById<View>(R.id.progress_bar)
            progress.visibility = View.VISIBLE
            NanoLoanSDK.declineOffer(offer.offerGuid, reason) { result ->
                if (!isAdded) return@declineOffer
                progress.visibility = View.GONE
                if (result is NanoLoanResult.Success) {
                    journeyHost.finishJourney()
                }
            }
        }
    }

    companion object {
        const val STEP_NAME = "reject_reason"
    }
}
