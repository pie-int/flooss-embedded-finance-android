package com.flooss.nanoloan.model

import java.math.BigDecimal

/**
 * Public request model for [com.flooss.nanoloan.NanoLoanSDK.submitLoanApplication].
 * A trimmed subset of the app's `CreateLoanReq`/`LoanEmployment`
 * (`data/model/api/request/CreateLoanReq.kt`) — real field names carried over 1:1 for the
 * fields this POC's core journey needs (amount/period/employment basics); the full
 * `CreateLoanReq` also carries salary-verification, cross-sell, device-variant, and
 * document-upload fields (`paySlip`/`bankStatement`/`salaryCertificate` refs,
 * `credolabReferenceNumber`, etc.) that belong to the KYC/salary-verification slice
 * (F3/F5) this pass leaves as backlog.
 */
data class LoanApplicationRequest(
    val loanAmount: BigDecimal,
    val loanPeriod: Long,
    val loanPeriodType: PeriodType,
    val productId: Long? = null,
    val loanPurposeId: Long? = null,
    val employment: LoanEmploymentInfo
)

enum class PeriodType { WEEKS, MONTHS }

enum class EmploymentType {
    GOVERNMENT_EMPLOYEE,
    RETIRED,
    PRIVATE_EMPLOYEE,
    CR_OWNER,
    FREELANCE,
    DOMESTIC_WORKER,
    UNEMPLOYED
}

data class LoanEmploymentInfo(
    val employmentType: EmploymentType,
    val employerName: String? = null,
    val occupation: String? = null,
    val monthlySalary: BigDecimal
)
