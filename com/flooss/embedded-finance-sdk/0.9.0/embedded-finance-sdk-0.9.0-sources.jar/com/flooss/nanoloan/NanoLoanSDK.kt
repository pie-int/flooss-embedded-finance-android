package com.flooss.nanoloan

import androidx.fragment.app.FragmentActivity
import com.flooss.nanoloan.config.NanoLoanConfiguration
import com.flooss.nanoloan.config.NanoLoanStep
import com.flooss.nanoloan.config.NanoStepOwner
import com.flooss.nanoloan.listener.NanoLoanEvent
import com.flooss.nanoloan.listener.NanoLoanListener
import com.flooss.nanoloan.listener.NanoLoanState
import com.flooss.nanoloan.logging.NanoLoanLogger
import com.flooss.nanoloan.model.AcceptanceOtpSession
import com.flooss.nanoloan.model.ActiveLoanInfo
import com.flooss.nanoloan.model.BankIbanDetail
import com.flooss.nanoloan.model.BankLinkResult
import com.flooss.nanoloan.model.BankProvider
import com.flooss.nanoloan.model.BureauInput
import com.flooss.nanoloan.model.FinalCheckResult
import com.flooss.nanoloan.model.EmploymentDetails
import com.flooss.nanoloan.model.HostOffer
import com.flooss.nanoloan.model.OfferSource
import com.flooss.nanoloan.model.NanoLoanCredentials
import com.flooss.nanoloan.model.LoanApplicationRequest
import com.flooss.nanoloan.model.LoanApplicationResult
import com.flooss.nanoloan.model.LoanOffer
import com.flooss.nanoloan.model.LoanProductInfo
import com.flooss.nanoloan.model.NanoLoanToken
import com.flooss.nanoloan.model.OfferInstallmentsPreview
import com.flooss.nanoloan.model.PreApprovalResult
import com.flooss.nanoloan.repo.NanoLoanRepository
import com.flooss.nanoloan.result.NanoLoanError
import com.flooss.nanoloan.result.NanoLoanResult
import com.flooss.nanoloan.session.NanoLoanSession
import com.flooss.nanoloan.telemetry.NanoTelemetryBridge
import com.flooss.nanoloan.ui.NanoLoanJourneySheetFragment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Public facade (design doc §9.1) — the only entry point host apps use.
 *
 * ## Manual-DI shortcut (documented per task instructions)
 * The design doc (§3, design principle 8) recommends routing [NanoLoanConfiguration]
 * through Hilt since the app's loan `ViewModel`/`Repo` layer already is. This module
 * deliberately does **not** pull in Hilt (no `hilt-android`, no `@HiltViewModel`, no
 * kapt): it is a plain manually-constructed singleton object owning its own
 * [NanoLoanRepository] (which owns its own OkHttp/Retrofit or mock data source). This is
 * a POC shortcut, not the target design — a production carve-out should follow §3's
 * recommendation and route this through Hilt (or another DI framework) so the host app's
 * own graph can participate. Kept manual here purely for POC speed and to avoid forcing
 * a kapt/Hilt dependency onto every host app that adopts the SDK before that decision is
 * made.
 *
 * ## What this POC slice implements vs. defers
 * See the module-level backlog in the implementation report — in short: the core
 * origination journey only (eligibility -> submit application -> active offer -> accept
 * /decline), token-handoff auth (design doc §7.2 Model A), and a MOCK network mode. KYC,
 * disbursement-method selection, BNPL, top-up, deferment, repayment, credential-handoff
 * auth, cert pinning, and Keystore-backed persistence are all out of scope for this pass.
 */
object NanoLoanSDK {

    private val listeners = mutableListOf<NanoLoanListener>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val session = NanoLoanSession()

    private var configuration: NanoLoanConfiguration? = null
    private var repository: NanoLoanRepository? = null
    private var logger: NanoLoanLogger? = null

    /** Design doc §6.2 — one-time, synchronous. Does not start any network/token work (§6.3). */
    fun initialize(config: NanoLoanConfiguration) {
        val newLogger = NanoLoanLogger(config.logLevel, config.logSinks)
        logger = newLogger
        configuration = config
        // Remote telemetry sink (off unless the host opted in). Installed BEFORE the
        // repository so the very first emission is captured, and appended to — never
        // replacing — the host's own log sinks.
        telemetry { NanoTelemetryBridge.install(config, newLogger) }
            ?.let { newLogger.update(config.logLevel, config.logSinks + it) }
        repository = NanoLoanRepository(
            config,
            newLogger,
            session,
            onMockApiCall = { method, path, status, durationMs ->
                newLogger.i("NanoLoanMockApi", "-> $method $path ... $status ${durationMs}ms (mock)")
                emitEvent(NanoLoanEvent.ApiCallSimulated(method, path, status, durationMs))
            },
            onLiveApiCall = { method, path, status, durationMs ->
                newLogger.i("NanoLoanApi", "-> $method $path ... $status ${durationMs}ms (live)")
                // OkHttp threads deliver this; hop to Main so listeners see the same
                // threading contract as every other callback.
                scope.launch {
                    emitEvent(NanoLoanEvent.ApiCallExecuted(method, path, status, durationMs))
                }
            },
            onSessionExpired = {
                newLogger.w("NanoLoanSDK", "session expired — single re-auth attempt did not recover")
                emitEvent(NanoLoanEvent.SessionExpired)
            }
        )
        newLogger.i("NanoLoanSDK", "initialize() environment=${config.environment} mock=${config.isMockMode}")
        if (config.isMockMode) {
            emitEvent(NanoLoanEvent.MockModeActive)
        }
    }

    fun addListener(listener: NanoLoanListener) {
        listeners.add(listener)
    }

    fun removeListener(listener: NanoLoanListener) {
        listeners.remove(listener)
    }

    /** Design doc §7.2 Model A — token handoff. The host already has a Salaf OAuth token; this stores it. */
    fun authenticate(token: NanoLoanToken, callback: (NanoLoanResult<Unit>) -> Unit) {
        val repo = requireRepository() ?: run {
            val error = NanoLoanError.Unknown("NanoLoanSDK.initialize() was never called")
            deliverFailure(error, callback)
            return
        }
        repo.authenticate(token)
        logger?.i("NanoLoanSDK", "authenticate() session token stored")
        emitEvent(NanoLoanEvent.SessionAuthenticated)
        setState(NanoLoanState.Idle)
        callback(NanoLoanResult.Success(Unit))
    }

    /**
     * Design doc §7.2 Model B — credential handoff. Runs the real Salaf OAuth2 password
     * grant (`POST api/v1/oauth/token`, ported from the app's
     * `SalafAuthTokenApi.hitSalafLoginApi`) with the host-supplied CPR + PIN, stores the
     * access+refresh token in the SDK session and holds the credentials IN MEMORY ONLY
     * for the single-retry 401 re-auth (see [NanoLoanRepository]). On an unrecoverable
     * 401 mid-journey the SDK emits [NanoLoanEvent.SessionExpired].
     */
    fun authenticate(credentials: NanoLoanCredentials, callback: (NanoLoanResult<Unit>) -> Unit) {
        val repo = requireRepository() ?: run {
            deliverFailure(NanoLoanError.Unknown("NanoLoanSDK.initialize() was never called"), callback)
            return
        }
        logger?.i("NanoLoanSDK", "authenticate(credentials) — running Salaf password grant")
        setState(NanoLoanState.Idle)
        scope.launch {
            when (val result = repo.authenticateWithCredentials(credentials)) {
                is NanoLoanResult.Success -> {
                    logger?.i("NanoLoanSDK", "authenticate(credentials) success — token stored")
                    emitEvent(NanoLoanEvent.SessionAuthenticated)
                    callback(result)
                }
                is NanoLoanResult.Failure -> {
                    logger?.e("NanoLoanSDK", "authenticate(credentials) failed: ${result.error.message}")
                    setState(NanoLoanState.Failed(result.error))
                    emitFailure(result.error)
                    callback(result)
                }
            }
        }
    }

    /**
     * Headless soft pre-approval (design doc §3.5 step 4, F2) — the host's own UI calls
     * this with the CPR + consents it collected (Option B input collection) and renders
     * the returned [PreApprovalResult] itself before ever launching SDK UI.
     *
     * Real endpoint (GET api/v1/fo/client/check-eligibility) identifies the caller
     * from the bearer token, not a request parameter — LoanApi.fetchSoouqBlackListStatus
     * takes only the token. `cpr` is kept on this signature to match the design doc's
     * §9.1 facade shape / F2 capability and is available for a future request-shape
     * change, but is not sent on the wire today.
     */
    fun checkLoanEligibility(cpr: String, callback: (NanoLoanResult<PreApprovalResult>) -> Unit) {
        // Correlator only: hashed on the way in per contract §1.1, raw value never stored.
        telemetry { NanoTelemetryBridge.noteCpr(cpr) }
        launchCall(
            action = "checkLoanEligibility",
            loading = NanoLoanState.CheckingEligibility,
            call = { it.checkEligibility(cpr) },
            onSuccess = { result ->
                setState(
                    if (result.approved) NanoLoanState.Eligible(result.eligibility)
                    else NanoLoanState.Ineligible(result.eligibility)
                )
                emitEvent(NanoLoanEvent.EligibilityChecked(result.eligibility.restricted))
            },
            callback = callback
        )
    }

    /** `GET api/v2/fo/products` — the loan product envelope (amount/period bounds). */
    fun getLoanProducts(callback: (NanoLoanResult<LoanProductInfo>) -> Unit) {
        launchCall(
            action = "getLoanProducts",
            loading = null,
            call = { it.getLoanProducts() },
            onSuccess = { },
            callback = callback
        )
    }

    /** `GET api/v1/fo/loans/active` — whether an active loan already blocks a new one. */
    fun getActiveLoan(callback: (NanoLoanResult<ActiveLoanInfo>) -> Unit) {
        launchCall(
            action = "getActiveLoan",
            loading = null,
            call = { it.getActiveLoan() },
            onSuccess = { },
            callback = callback
        )
    }

    /**
     * Real screen 2/4's save — `POST api/v1/fo/client-profile/employment-details`
     * (`UserProfileApi.saveEmploymentDetailsApi` / `EmployeeDetailReq` shape).
     */
    fun saveEmploymentDetails(details: EmploymentDetails, callback: (NanoLoanResult<Unit>) -> Unit) {
        launchCall(
            action = "saveEmploymentDetails",
            loading = null,
            call = { it.saveEmploymentDetails(details) },
            onSuccess = { emitEvent(NanoLoanEvent.EmploymentDetailsSaved) },
            callback = callback
        )
    }

    /** `GET api/v1/fo/loans/disbursement/bank-detail/{iban}` — resolve an IBAN's bank. */
    fun getBankDetailForIban(iban: String, callback: (NanoLoanResult<BankIbanDetail>) -> Unit) {
        launchCall(
            action = "getBankDetailForIban",
            loading = null,
            call = { it.getBankDetailForIban(iban) },
            onSuccess = { },
            callback = callback
        )
    }

    /**
     * `PUT api/v1/fo/applications/disburse-detail/{accountNumber}?disbursementMethod=...`
     * — confirm where the financing lands ("DISBURSEMENT_METHOD_BANK_IBAN" for the
     * bank-IBAN path, per the app's `DisbursementType`).
     */
    fun setDisbursementMethod(
        accountNumber: String,
        disbursementMethod: String,
        callback: (NanoLoanResult<Unit>) -> Unit
    ) {
        launchCall(
            action = "setDisbursementMethod",
            loading = null,
            call = { it.setDisbursementMethod(accountNumber, disbursementMethod) },
            onSuccess = { emitEvent(NanoLoanEvent.DisbursementMethodSet(disbursementMethod)) },
            callback = callback
        )
    }

    /** `GET api/v1/fo/tarabut/providers` — the Tarabut open-banking bank list. */
    fun getSalaryBankProviders(callback: (NanoLoanResult<List<BankProvider>>) -> Unit) {
        launchCall(
            action = "getSalaryBankProviders",
            loading = null,
            call = { it.getBankProviders() },
            onSuccess = { },
            callback = callback
        )
    }

    /**
     * Salary verification via bank link — `POST api/v1/fo/tarabut/intent` then
     * `POST api/v1/fo/tarabut/accounts/sync` (API_SEQUENCE_FLOWS §4.1 steps 5–6).
     */
    fun linkBankForSalaryVerification(providerId: String, callback: (NanoLoanResult<BankLinkResult>) -> Unit) {
        launchCall(
            action = "linkBankForSalaryVerification(providerId=$providerId)",
            loading = NanoLoanState.VerifyingSalary,
            call = { it.linkBankAccount(providerId) },
            onSuccess = {
                setState(NanoLoanState.SalaryVerified("BANK_SYNC"))
                emitEvent(NanoLoanEvent.SalaryVerified("BANK_SYNC"))
            },
            callback = callback
        )
    }

    /** Salary verification via document upload — `POST api/v1/salary/documents/{folder}/upload`. */
    fun uploadSalaryDocuments(callback: (NanoLoanResult<Int>) -> Unit) {
        launchCall(
            action = "uploadSalaryDocuments",
            loading = NanoLoanState.VerifyingSalary,
            call = { it.uploadSalaryDocuments() },
            onSuccess = {
                setState(NanoLoanState.SalaryVerified("DOCUMENT_UPLOAD"))
                emitEvent(NanoLoanEvent.SalaryVerified("DOCUMENT_UPLOAD"))
            },
            callback = callback
        )
    }

    fun submitLoanApplication(
        request: LoanApplicationRequest,
        callback: (NanoLoanResult<LoanApplicationResult>) -> Unit
    ) {
        launchCall(
            action = "submitLoanApplication",
            loading = NanoLoanState.SubmittingApplication,
            call = { it.submitLoanApplication(request) },
            onSuccess = { result ->
                setState(NanoLoanState.ApplicationSubmitted(result))
                emitEvent(NanoLoanEvent.ApplicationSubmitted(result.id))
            },
            callback = callback
        )
    }

    fun getActiveOffer(callback: (NanoLoanResult<LoanOffer>) -> Unit) {
        launchCall(
            action = "getActiveOffer",
            loading = NanoLoanState.LoadingOffer,
            call = { it.getActiveOffer() },
            onSuccess = { result ->
                setState(NanoLoanState.OfferAvailable(result))
                emitEvent(NanoLoanEvent.OfferReceived(result.offerGuid))
                // v2 §3.2 — the offer object itself, which NanoLoanEvent.OfferReceived
                // does not carry, so offer_shown can report amount/tenor/APR/instalment.
                telemetry { NanoTelemetryBridge.offerShown(result) }
            },
            callback = callback
        )
    }

    /** `GET api/v2/fo/loans/installments` — the offer's repayment schedule preview (§4.3). */
    fun getOfferInstallments(callback: (NanoLoanResult<OfferInstallmentsPreview>) -> Unit) {
        launchCall(
            action = "getOfferInstallments",
            loading = null,
            call = { it.getOfferInstallments() },
            onSuccess = { },
            callback = callback
        )
    }

    /** `GET api/v1/fo/loans/loan-agreement?loanAppId=...` — the offer's agreement document (§4.3). */
    fun getLoanAgreement(offerId: String, callback: (NanoLoanResult<Unit>) -> Unit) {
        launchCall(
            action = "getLoanAgreement(offerId=$offerId)",
            loading = null,
            call = { it.getLoanAgreement(offerId) },
            onSuccess = { },
            callback = callback
        )
    }

    /**
     * Steps 1–2 of the acceptance chain (§4.4): `POST security/verifyEmail/sendEmailOtp`
     * then `POST security/verifyPhone/sendSms`. In MOCK mode the email leg is
     * auto-passed (event [NanoLoanEvent.EmailOtpSent] with autoVerified=true) to keep
     * the demo short; the SMS OTP is what the journey's OTP screen collects.
     */
    fun requestAcceptanceOtp(callback: (NanoLoanResult<AcceptanceOtpSession>) -> Unit) {
        launchCall(
            action = "requestAcceptanceOtp",
            loading = NanoLoanState.RequestingAcceptanceOtp,
            call = { it.requestAcceptanceOtp() },
            onSuccess = {
                emitEvent(NanoLoanEvent.EmailOtpSent(autoVerified = currentConfiguration().isMockMode))
                emitEvent(NanoLoanEvent.SmsOtpSent)
                setState(NanoLoanState.AwaitingAcceptanceOtp)
            },
            callback = callback
        )
    }

    /** Step 4 of the acceptance chain (§4.4): `POST .../verify-otp` with the SMS OTP. */
    fun verifyAcceptanceOtp(offerId: String, otp: String, callback: (NanoLoanResult<Unit>) -> Unit) {
        launchCall(
            action = "verifyAcceptanceOtp(offerId=$offerId)",
            loading = NanoLoanState.VerifyingAcceptanceOtp,
            call = { it.verifyAcceptanceOtp(offerId, otp) },
            onSuccess = {
                setState(NanoLoanState.OfferAccepted)
                emitEvent(NanoLoanEvent.AcceptanceOtpVerified(offerId))
            },
            callback = callback
        )
    }

    fun acceptOffer(offerId: String, callback: (NanoLoanResult<Unit>) -> Unit) {
        launchCall(
            action = "acceptOffer(offerId=$offerId)",
            loading = NanoLoanState.AcceptingOffer,
            call = { it.acceptOffer(offerId) },
            onSuccess = {
                setState(NanoLoanState.OfferAccepted)
                emitEvent(NanoLoanEvent.OfferAccepted(offerId))
            },
            callback = callback
        )
    }

    /**
     * Not on the task's explicit facade list but part of its in-scope journey
     * ("offer accept/decline") — declines the currently active offer.
     */
    fun declineOffer(offerId: String, reason: String? = null, callback: (NanoLoanResult<Unit>) -> Unit) {
        launchCall(
            action = "declineOffer(offerId=$offerId)",
            loading = NanoLoanState.DecliningOffer,
            call = { it.declineOffer(offerId, reason) },
            onSuccess = {
                setState(NanoLoanState.OfferDeclined)
                emitEvent(NanoLoanEvent.OfferDeclined(offerId))
            },
            callback = callback
        )
    }

    /**
     * Themed UI entry point (design doc §9.3 — one-call full-journey). Walks eligibility
     * -> application form -> offer display -> accept/decline, styled from the
     * [NanoLoanConfiguration.theme] this instance was initialized with. Presents as a
     * modal bottom sheet over the host activity (standard embedded-finance SDK pattern),
     * which is why the entry point now requires a [FragmentActivity].
     */
    fun presentLoanOfferJourney(activity: FragmentActivity, hostOffer: HostOffer? = null) {
        requireNotNull(configuration) { "NanoLoanSDK.initialize() must be called before presentLoanOfferJourney()" }
        this.hostOffer = hostOffer
        telemetry { NanoTelemetryBridge.journeyStarted() }
        NanoLoanJourneySheetFragment().show(activity.supportFragmentManager, NanoLoanJourneySheetFragment.TAG)
    }

    // ── §2.2 two-offer comparison ────────────────────────────────────────────────────

    /**
     * The host's own offer for this customer, for the duration of one journey. The SDK
     * NEVER invents one: null here means the comparison screen does not exist for this
     * journey and the single-offer screen runs instead.
     */
    private var hostOffer: HostOffer? = null

    /**
     * SDK_V3_PRODUCT_GAPS §2.2 — present the journey with the two-offer comparison, the
     * host's offer beside the Flooss one. [hostOffer] is displayed exactly as supplied;
     * the SDK does not recompute or adjust a competitor's numbers, and amounts are
     * integer fils throughout.
     *
     * Choosing the host's offer ends the SDK journey — the customer is the host's from
     * that point. Choosing Flooss continues into the rest of the journey.
     */
    fun presentOfferComparison(activity: FragmentActivity, hostOffer: HostOffer) {
        presentLoanOfferJourney(activity, hostOffer)
    }

    internal fun currentHostOffer(): HostOffer? = hostOffer

    // ── §2.4 final financial check (phase two of the decision) ───────────────────────

    /**
     * Bureau/BCRB material for this journey, supplied by the host. Empty by default, and
     * an empty one is NOT a neutral default: without a BCRB document reference nothing
     * can be made final, so the check declines with that reason. The SDK never invents
     * bureau data.
     */
    private var bureauInput: BureauInput = BureauInput()

    /**
     * §2.4 — hand the SDK the bureau/BCRB material the host holds, any time before the
     * journey reaches the final check. Call it again to replace it; the latest document
     * is the one that counts.
     */
    fun provideBureauData(bureauData: BureauInput) {
        bureauInput = bureauData
        logger?.i(
            "NanoLoanSDK",
            "bureau data provided (bcrbDocument=${bureauData.bcrbDocumentReference != null})"
        )
    }

    internal fun currentBureauInput(): BureauInput = bureauInput

    /** §2.3 — the additional-KYC step completed. Field KEYS only; the answers stay local. */
    internal fun notifyKycDetailsSubmitted(fields: List<String>) {
        emitEvent(NanoLoanEvent.KycDetailsSubmitted(fields))
    }

    // ── §2.5 / §2.6 mandate and signature hooks ──────────────────────────────────────

    /** §2.6 — the signature ceremony completed. The provider binding is deliberately absent. */
    internal fun notifyDocumentSigned(documentType: String, signedAt: String) {
        logger?.i("NanoLoanSDK", "document signed: $documentType at $signedAt")
        emitEvent(NanoLoanEvent.DocumentSigned(documentType, signedAt))
    }

    /** §2.5 — the mandate screen was reached. */
    internal fun notifyDirectDebitSetup() {
        emitEvent(NanoLoanEvent.DirectDebitSetup)
    }

    /** §2.5 — the customer authorised the mandate. [maskedAccount] is already masked. */
    internal fun notifyMandateAuthorised(maskedAccount: String) {
        logger?.i("NanoLoanSDK", "direct debit mandate authorised ($maskedAccount)")
        emitEvent(NanoLoanEvent.MandateAuthorised(maskedAccount))
    }

    /**
     * SDK_V3_PRODUCT_GAPS §2.4 — the second phase of the two-phase decision. The host
     * passes in the bureau/BCRB material it holds; the SDK answers accept or reject with
     * a coded reason.
     *
     * **Final approval is subject to the latest BCRB document from the host.** That is a
     * statement of fact about where the authority sits, shown on the screen, and is not
     * modelled here as an SDK-owned rule. There is no final-check endpoint on the backend
     * yet: outside MOCK this fails loudly rather than producing a credit decision the SDK
     * has no right to make.
     */
    fun submitFinalCheck(
        bureauData: BureauInput,
        callback: (NanoLoanResult<FinalCheckResult>) -> Unit
    ) {
        emitEvent(NanoLoanEvent.FinalCheckStarted)
        launchCall(
            action = "submitFinalCheck",
            loading = null,
            call = { it.submitFinalCheck(bureauData) },
            onSuccess = { result ->
                emitEvent(NanoLoanEvent.FinalDecisionMade(result.approved, result.reasonCode))
            },
            callback = callback
        )
    }

    internal fun notifyOfferComparisonShown(hostOfferPresent: Boolean) {
        emitEvent(NanoLoanEvent.OfferComparisonShown(hostOfferPresent))
    }

    internal fun notifyOfferSelected(source: OfferSource) {
        logger?.i("NanoLoanSDK", "offer selected: $source")
        emitEvent(NanoLoanEvent.OfferSelected(source))
    }

    /**
     * Flush whatever telemetry is buffered — call from the host's `onPause`/`onStop` so a
     * backgrounded (and possibly soon-killed) process does not take its events with it.
     * A no-op when telemetry is disabled, and never throws.
     */
    fun flushTelemetry() {
        telemetry { NanoTelemetryBridge.flush() }
    }

    /** Journey-UI hook: a journey step fragment became visible. */
    internal fun notifyStepEntered(internalStepName: String) {
        telemetry { NanoTelemetryBridge.stepEntered(internalStepName) }
    }

    /** Journey-UI hook: the journey sheet went away, successfully or not. */
    internal fun notifyJourneyFinished(completed: Boolean) {
        telemetry { NanoTelemetryBridge.journeyDismissed(completed) }
    }

    // ── Step-ownership Option B machinery (design doc §3.5, §9.5) ─────────────────────

    /** Pending HOST-owned step the journey is paused on, with its resume continuation. */
    private var pendingHostStep: NanoLoanStep? = null
    private var hostInputContinuation: ((Map<String, String>) -> Unit)? = null

    /**
     * Option B (§9.5): the host collected [values] for the HOST-owned [step] announced by
     * [NanoLoanEvent.InputRequired] and hands them back; the SDK validates that this step
     * is actually pending and resumes the paused journey.
     */
    fun submitStepInput(
        step: NanoLoanStep,
        values: Map<String, String>,
        callback: (NanoLoanResult<Unit>) -> Unit = {}
    ) {
        val pending = pendingHostStep
        val continuation = hostInputContinuation
        if (pending != step || continuation == null) {
            deliverFailure(
                NanoLoanError.Api(
                    message = "No pending host input for step $step" +
                        (pending?.let { " (waiting on $it)" } ?: ""),
                    enableTryAgain = false
                ),
                callback
            )
            return
        }
        pendingHostStep = null
        hostInputContinuation = null
        logger?.i("NanoLoanSDK", "submitStepInput(step=$step) — resuming journey")
        emitEvent(NanoLoanEvent.StepInputSubmitted(step))
        scope.launch { continuation(values) }
        callback(NanoLoanResult.Success(Unit))
    }

    /** Which side owns [step] under the current configuration (default SDK). */
    fun ownerOf(step: NanoLoanStep): NanoStepOwner =
        configuration?.ownerOf(step) ?: NanoStepOwner.SDK

    /**
     * Journey-UI hook: pause on a HOST-owned [step] — emits
     * [NanoLoanEvent.InputRequired] with the step's field catalogue and stores the
     * continuation [submitStepInput] resumes. A second pause request while one is
     * pending replaces the previous continuation (last writer wins — journeys are
     * strictly sequential).
     */
    internal fun requestHostInput(
        step: NanoLoanStep,
        fields: List<String>,
        onSubmitted: (Map<String, String>) -> Unit
    ) {
        pendingHostStep = step
        hostInputContinuation = onSubmitted
        logger?.i("NanoLoanSDK", "journey paused — awaiting host input for $step ($fields)")
        emitEvent(NanoLoanEvent.InputRequired(step, fields))
    }

    /** Journey-UI hook for the demo-mode Skip affordance (task step 4). */
    internal fun notifyStepSkipped(stepName: String) {
        logger?.i("NanoLoanSDK", "journey step skipped: $stepName")
        emitEvent(NanoLoanEvent.StepSkipped(stepName))
    }

    internal fun currentConfiguration(): NanoLoanConfiguration =
        requireNotNull(configuration) { "NanoLoanSDK.initialize() must be called first" }

    internal fun currentRepository(): NanoLoanRepository =
        requireNotNull(repository) { "NanoLoanSDK.initialize() must be called first" }

    internal fun currentLogger(): NanoLoanLogger =
        requireNotNull(logger) { "NanoLoanSDK.initialize() must be called first" }

    private fun requireRepository(): NanoLoanRepository? = repository

    private fun <T> launchCall(
        action: String,
        loading: NanoLoanState?,
        call: suspend (NanoLoanRepository) -> NanoLoanResult<T>,
        onSuccess: (T) -> Unit,
        callback: (NanoLoanResult<T>) -> Unit
    ) {
        val repo = repository
        if (repo == null) {
            deliverFailure(NanoLoanError.Unknown("NanoLoanSDK.initialize() was never called"), callback)
            return
        }
        logger?.i("NanoLoanSDK", "-> $action")
        loading?.let { setState(it) }
        scope.launch {
            val result = call(repo)
            when (result) {
                is NanoLoanResult.Success -> {
                    logger?.i("NanoLoanSDK", "<- $action success")
                    onSuccess(result.value)
                    callback(result)
                }
                is NanoLoanResult.Failure -> {
                    logger?.e("NanoLoanSDK", "<- $action failed: ${result.error.message}")
                    setState(NanoLoanState.Failed(result.error))
                    emitFailure(result.error)
                    callback(result)
                }
            }
        }
    }

    private fun <T> deliverFailure(error: NanoLoanError, callback: (NanoLoanResult<T>) -> Unit) {
        setState(NanoLoanState.Failed(error))
        emitFailure(error)
        callback(NanoLoanResult.Failure(error))
    }

    private fun setState(state: NanoLoanState) {
        listeners.forEach { it.onStateUpdate(state) }
        telemetry { NanoTelemetryBridge.onState(state) }
    }

    private fun emitEvent(event: NanoLoanEvent) {
        listeners.forEach { it.onEvent(event) }
        telemetry { NanoTelemetryBridge.onEvent(event) }
    }

    private fun emitFailure(error: NanoLoanError) {
        listeners.forEach { it.onFailure(error) }
        telemetry { NanoTelemetryBridge.onFailure(error) }
    }

    /**
     * Contract §1.5, enforced at the call site as well as inside the pipeline: telemetry
     * is fire-and-forget, so nothing it does — including failing to initialise at all —
     * may surface to the host or interrupt the journey. The host's listeners are always
     * notified FIRST, so even a catastrophic telemetry failure cannot reorder or suppress
     * a callback the host depends on.
     */
    private inline fun <T> telemetry(block: () -> T): T? = try {
        block()
    } catch (t: Throwable) {
        logger?.w("NanoLoanSDK", "telemetry suppressed: ${t.javaClass.simpleName}")
        null
    }
}
