package com.flooss.nanoloan.repo

import com.flooss.nanoloan.config.NanoLoanConfiguration
import com.flooss.nanoloan.logging.NanoLoanLogger
import com.flooss.nanoloan.model.AcceptanceOtpSession
import com.flooss.nanoloan.model.ActiveLoanInfo
import com.flooss.nanoloan.model.BankIbanDetail
import com.flooss.nanoloan.model.BankLinkResult
import com.flooss.nanoloan.model.BankProvider
import com.flooss.nanoloan.model.BureauInput
import com.flooss.nanoloan.model.FinalCheckResult
import com.flooss.nanoloan.model.EmploymentDetails
import com.flooss.nanoloan.model.LoanApplicationRequest
import com.flooss.nanoloan.model.LoanApplicationResult
import com.flooss.nanoloan.model.LoanOffer
import com.flooss.nanoloan.model.LoanProductInfo
import com.flooss.nanoloan.model.NanoLoanCredentials
import com.flooss.nanoloan.model.OfferInstallmentsPreview
import com.flooss.nanoloan.model.PreApprovalResult
import com.flooss.nanoloan.network.NanoLoanNetworkClient
import com.flooss.nanoloan.result.NanoLoanError
import com.flooss.nanoloan.result.NanoLoanResult
import com.flooss.nanoloan.session.NanoLoanSession
import java.math.BigDecimal

/**
 * Orchestrates [NanoLoanSession] (token + offer-id bookkeeping) against whichever
 * [NanoLoanDataSource] the configuration selects — [RealNanoLoanDataSource] for
 * DEV/QA/UAT/PROD, [MockNanoLoanDataSource] for
 * [com.flooss.nanoloan.config.NanoLoanEnvironment.MOCK]. This is the one place that
 * switch happens; [com.flooss.nanoloan.NanoLoanSDK] never talks to a data source
 * directly.
 *
 * ## 401 re-auth (design doc §7.2 Model B, §7.3)
 * Every journey call goes through [withSession]: on a
 * [NanoLoanError.NotAuthenticated] failure (HTTP 401/403 mapped by
 * [RealNanoLoanDataSource]) with credentials held in the session, the repository
 * re-runs the Salaf password grant ONCE and retries the call once — the SDK-side
 * equivalent of the app's `AuthInterceptor` 401 branch. If the re-auth or the retry
 * fails again (or no credentials are held — Model A token handoff), [onSessionExpired]
 * fires and the failure propagates.
 *
 * @param onMockApiCall invoked by the MOCK data source for every simulated wire call
 * (real method + path) so the facade can surface the API sequence as events.
 * @param onLiveApiCall invoked for every REAL wire call (real status; -1 = transport
 * failure) — same purpose, live modes.
 * @param onSessionExpired invoked when a 401 could not be recovered by the single
 * re-auth attempt; the facade emits [com.flooss.nanoloan.listener.NanoLoanEvent.SessionExpired].
 */
internal class NanoLoanRepository(
    private val configuration: NanoLoanConfiguration,
    private val logger: NanoLoanLogger,
    private val session: NanoLoanSession,
    onMockApiCall: (method: String, path: String, httpStatus: Int, durationMs: Int) -> Unit,
    onLiveApiCall: (method: String, path: String, httpStatus: Int, durationMs: Int) -> Unit =
        { _, _, _, _ -> },
    private val onSessionExpired: () -> Unit = {}
) {
    private val dataSource: NanoLoanDataSource = if (configuration.isMockMode) {
        MockNanoLoanDataSource(onMockApiCall)
    } else {
        RealNanoLoanDataSource(
            NanoLoanNetworkClient.create(configuration, logger, onLiveApiCall),
            logger
        )
    }

    /** Acceptance-OTP session (verificationUUIDs) from the last requestAcceptanceOtp(). */
    private var acceptanceOtpSession: AcceptanceOtpSession? = null

    fun authenticate(token: com.flooss.nanoloan.model.NanoLoanToken) {
        session.credentials = null
        session.authenticate(token)
    }

    /** Model B — run the real Salaf password grant and hold both token and credentials. */
    suspend fun authenticateWithCredentials(credentials: NanoLoanCredentials): NanoLoanResult<Unit> {
        val result = dataSource.login(
            cpr = credentials.cpr,
            pin = credentials.pin,
            clientId = configuration.oauthClientId,
            clientSecret = configuration.oauthClientSecret.get(),
            scope = configuration.oauthScope
        )
        return when (result) {
            is NanoLoanResult.Success -> {
                session.authenticate(result.value)
                session.credentials = credentials
                signInToWallet(credentials)
            }
            is NanoLoanResult.Failure -> result
        }
    }

    private fun walletDevice(): WalletDevice? = configuration.environment.walletBaseUrl?.let {
        WalletDevice(it, session.deviceId, android.os.Build.MANUFACTURER.orEmpty(), android.os.Build.MODEL.orEmpty())
    }

    /**
     * The lending backend refreshes eKYC with the customer's wallet token when an
     * application is submitted, so Model B signs in to the wallet too. A new device stops
     * here with [NanoLoanError.DeviceVerificationRequired] until [verifyDevice] runs.
     */
    private suspend fun signInToWallet(credentials: NanoLoanCredentials): NanoLoanResult<Unit> {
        val device = walletDevice() ?: run {
            session.authenticateWallet("mock-wallet-token", 1800)
            return NanoLoanResult.Success(Unit)
        }
        return when (val signIn = dataSource.walletSignIn(device, credentials.mobileNumber, credentials.pin)) {
            is NanoLoanResult.Failure -> signIn
            is NanoLoanResult.Success -> when (val outcome = signIn.value) {
                is WalletSignIn.Signed -> {
                    session.authenticateWallet(outcome.accessToken, outcome.expiresInSeconds)
                    NanoLoanResult.Success(Unit)
                }
                is WalletSignIn.OtpRequired -> {
                    session.pendingDeviceAction = outcome.actionUuid to outcome.phoneNumber
                    NanoLoanResult.Failure(
                        com.flooss.nanoloan.result.NanoLoanError.DeviceVerificationRequired(maskPhone(outcome.phoneNumber))
                    )
                }
            }
        }
    }

    /** Finish a sign-in that stopped at [NanoLoanError.DeviceVerificationRequired]. */
    suspend fun verifyDevice(otp: String): NanoLoanResult<Unit> {
        val credentials = session.credentials ?: return notAuthenticated()
        val (actionUuid, _) = session.pendingDeviceAction ?: return signInToWallet(credentials)
        val device = walletDevice() ?: return NanoLoanResult.Success(Unit)
        return when (val signed = dataSource.walletVerifyDevice(device, actionUuid, otp, credentials.mobileNumber, credentials.pin)) {
            is NanoLoanResult.Success -> {
                session.authenticateWallet(signed.value.accessToken, signed.value.expiresInSeconds)
                NanoLoanResult.Success(Unit)
            }
            is NanoLoanResult.Failure -> signed
        }
    }

    private fun maskPhone(phone: String): String =
        if (phone.length <= 2) phone else "•".repeat(phone.length - 2) + phone.takeLast(2)

    suspend fun checkEligibility(cpr: String): NanoLoanResult<PreApprovalResult> =
        withSession { token ->
            when (val result = dataSource.checkEligibility(token, cpr)) {
                is NanoLoanResult.Success -> {
                    val eligibility = result.value
                    NanoLoanResult.Success(
                        PreApprovalResult(
                            approved = !eligibility.restricted,
                            // Indicative ceiling = the SHARIYAH product's maxLoanAmount; in
                            // MOCK mode the canned product envelope, on the wire this comes
                            // from getLoanProducts() and stays null until fetched.
                            indicativeMaxAmount = if (eligibility.restricted) null else BigDecimal(MockNanoLoanDataSource.MOCK_MAX_AMOUNT),
                            reason = eligibility.restrictedReason,
                            eligibility = eligibility
                        )
                    )
                }
                is NanoLoanResult.Failure -> result
            }
        }

    suspend fun getLoanProducts(): NanoLoanResult<LoanProductInfo> =
        withSession { token -> dataSource.getProducts(token) }

    suspend fun getActiveLoan(): NanoLoanResult<ActiveLoanInfo> =
        withSession { token -> dataSource.getActiveLoan(token) }

    suspend fun getEmploymentOptions(): NanoLoanResult<com.flooss.nanoloan.model.EmploymentOptions> =
        withSession { token -> dataSource.getEmploymentOptions(token) }

    suspend fun saveEmploymentDetails(details: EmploymentDetails): NanoLoanResult<Unit> =
        withSession { token -> dataSource.saveEmploymentDetails(token, details) }

    suspend fun getBankProviders(): NanoLoanResult<List<BankProvider>> =
        withSession { token -> dataSource.getBankProviders(token) }

    suspend fun linkBankAccount(providerId: String): NanoLoanResult<BankLinkResult> =
        withSession { token -> dataSource.linkBankAccount(token, providerId) }

    suspend fun uploadSalaryDocuments(
        documents: List<com.flooss.nanoloan.model.SalaryDocument>
    ): NanoLoanResult<List<com.flooss.nanoloan.model.UploadedDocument>> =
        withSession { token -> dataSource.uploadSalaryDocuments(token, documents) }

    suspend fun getCustomerProfile(): NanoLoanResult<com.flooss.nanoloan.model.CustomerProfile> =
        withSession { token -> dataSource.getCustomerProfile(token) }

    suspend fun submitLoanApplication(request: LoanApplicationRequest): NanoLoanResult<LoanApplicationResult> {
        // The wallet token lasts 30 minutes; a trusted device signs in again without an SMS.
        if (!session.walletTokenIsFresh()) {
            session.credentials?.let { credentials ->
                val refreshed = signInToWallet(credentials)
                if (refreshed is NanoLoanResult.Failure) return refreshed
            }
        }
        return withSession { token -> dataSource.submitLoanApplication(token, request, session.walletToken) }
    }

    suspend fun getActiveOffer(): NanoLoanResult<LoanOffer> =
        withSession { token ->
            when (val result = dataSource.getActiveOffer(token)) {
                is NanoLoanResult.Success -> {
                    session.rememberOffer(result.value.offerGuid, result.value.id)
                    result
                }
                is NanoLoanResult.Failure -> result
            }
        }

    /**
     * §2.4 — the second phase of the decision, against host-supplied bureau/BCRB data.
     *
     * **There is no `final-check` endpoint on Salaf today.** The two-phase decision is a
     * v3 product requirement and the backend contract for it does not exist yet, so:
     *
     *  - MOCK simulates the call the real one would be
     *    (`POST api/v1/fo/applications/final-check`) and answers from what the HOST
     *    supplied — no BCRB document reference means nothing can be made final, so the
     *    decision is a decline with that reason code; otherwise it approves at the active
     *    offer's own figures. That is a reflection of the host's input, deliberately NOT
     *    an SDK-owned credit rule.
     *  - Live environments FAIL, loudly and unrecoverably, rather than inventing a
     *    decision. A fabricated approval here would be a fabricated credit decision.
     */
    suspend fun submitFinalCheck(bureau: BureauInput): NanoLoanResult<FinalCheckResult> {
        if (!configuration.isMockMode) {
            logger.e(
                "NanoLoanRepository",
                "submitFinalCheck has no backend endpoint outside MOCK — refusing to invent a decision"
            )
            return NanoLoanResult.Failure(
                NanoLoanError.Api(
                    message = "Final check is not available in this environment: Salaf exposes no " +
                        "final-check endpoint yet. The SDK will not produce a credit decision of its own.",
                    enableTryAgain = false
                )
            )
        }
        return withSession { token ->
            (dataSource as MockNanoLoanDataSource).submitFinalCheck(token, bureau)
        }
    }

    suspend fun getOfferInstallments(): NanoLoanResult<OfferInstallmentsPreview> =
        withSession { token -> dataSource.getOfferInstallments(token) }

    suspend fun getLoanAgreement(offerGuid: String): NanoLoanResult<Unit> {
        val applicationId = session.applicationIdFor(offerGuid) ?: return unknownOffer(offerGuid)
        return withSession { token -> dataSource.getLoanAgreement(token, applicationId) }
    }

    suspend fun getBankDetailForIban(iban: String): NanoLoanResult<BankIbanDetail> =
        withSession { token -> dataSource.getBankDetailForIban(token, iban) }

    suspend fun setDisbursementMethod(
        accountNumber: String,
        disbursementMethod: String
    ): NanoLoanResult<Unit> =
        withSession { token ->
            dataSource.setDisbursementMethod(token, accountNumber, disbursementMethod)
        }

    suspend fun requestAcceptanceOtp(): NanoLoanResult<AcceptanceOtpSession> =
        withSession { token ->
            when (val result = dataSource.requestAcceptanceOtp(token)) {
                is NanoLoanResult.Success -> {
                    acceptanceOtpSession = result.value
                    result
                }
                is NanoLoanResult.Failure -> result
            }
        }

    suspend fun acceptOffer(offerGuid: String): NanoLoanResult<Unit> {
        val applicationId = session.applicationIdFor(offerGuid) ?: return unknownOffer(offerGuid)
        return withSession { token -> dataSource.acceptOffer(token, applicationId, offerGuid) }
    }

    suspend fun verifyAcceptanceOtp(offerGuid: String, otp: String): NanoLoanResult<Unit> {
        val applicationId = session.applicationIdFor(offerGuid) ?: return unknownOffer(offerGuid)
        return withSession { token ->
            dataSource.verifyAcceptanceOtp(
                token, applicationId, offerGuid, otp, acceptanceOtpSession?.phoneVerificationUUID
            )
        }
    }

    suspend fun declineOffer(offerGuid: String, reason: String?): NanoLoanResult<Unit> {
        val applicationId = session.applicationIdFor(offerGuid) ?: return unknownOffer(offerGuid)
        return withSession { token -> dataSource.declineOffer(token, applicationId, offerGuid, reason) }
    }

    /**
     * Session guard + single-retry re-auth. See class doc — the SDK-side port of the
     * app's `AuthInterceptor` 401 branch, minus the interceptor (repository level keeps
     * the retry visible and testable, and keeps runBlocking out of OkHttp threads).
     */
    private suspend fun <T> withSession(
        call: suspend (bearerToken: String) -> NanoLoanResult<T>
    ): NanoLoanResult<T> {
        val token = session.bearerToken() ?: return notAuthenticated()
        val result = call(token)
        if (result !is NanoLoanResult.Failure || result.error !is NanoLoanError.NotAuthenticated) {
            return result
        }

        val credentials = session.credentials
        if (credentials == null) {
            logger.w("NanoLoanRepository", "401 with no held credentials (Model A) — session expired")
            onSessionExpired()
            return result
        }

        logger.i("NanoLoanRepository", "401 — attempting single re-auth with held credentials")
        when (val reAuth = authenticateWithCredentials(credentials)) {
            is NanoLoanResult.Failure -> {
                logger.e("NanoLoanRepository", "re-auth failed: ${reAuth.error.message}")
                onSessionExpired()
                return result
            }
            is NanoLoanResult.Success -> {
                val retryToken = session.bearerToken() ?: return notAuthenticated()
                val retried = call(retryToken)
                if (retried is NanoLoanResult.Failure && retried.error is NanoLoanError.NotAuthenticated) {
                    onSessionExpired()
                }
                return retried
            }
        }
    }

    private fun <T> notAuthenticated(): NanoLoanResult<T> =
        NanoLoanResult.Failure(NanoLoanError.NotAuthenticated())

    private fun <T> unknownOffer(offerGuid: String): NanoLoanResult<T> =
        NanoLoanResult.Failure(
            NanoLoanError.Api(message = "Unknown offer '$offerGuid' — call getActiveOffer() first", enableTryAgain = false)
        )
}
