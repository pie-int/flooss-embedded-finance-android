package com.flooss.nanoloan.network.dto

/** `GET {wallet}api/v1/public/rsa-public-key` — Base64 of the PEM the wallet encrypts PINs with. */
internal data class WalletPublicKeyDto(val data: String? = null)

/** `POST {wallet}api/v1/customer/validate` — the wallet app's VerifyReq. */
internal data class WalletValidateRequestDto(
    val username: String,
    val pin: String,
    val udid: String,
    val isBioLogin: Boolean = false,
    val firstLogin: Boolean = false
)

internal data class WalletValidateResponseDto(val data: WalletValidateDataDto? = null, val message: String? = null)

internal data class WalletValidateDataDto(
    val valid: Boolean? = null,
    val trustedDevice: Boolean? = null,
    val actionUuid: String? = null,
    val phoneNumber: String? = null
)

/** `POST {wallet}api/v1/system/verify-otp` — the wallet app's SmsVerifyReq; otp is RSA-encrypted. */
internal data class WalletVerifyOtpRequestDto(val actionUuid: String, val otp: String, val phoneNumber: String)

/** `POST {wallet}oauth/token`. */
internal data class WalletTokenDto(
    val access_token: String? = null,
    val expires_in: Long? = null
)
