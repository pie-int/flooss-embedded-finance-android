package com.flooss.nanoloan.telemetry

import com.flooss.nanoloan.config.NanoLoanStep
import com.flooss.nanoloan.listener.NanoLoanState
import com.flooss.nanoloan.result.NanoLoanError

/**
 * Projection of the SDK's own internal event/state stream onto the contract's CLOSED
 * vocabularies. There is deliberately no parallel event system: the SDK emits what it
 * always emitted, and [NanoTelemetryBridge] tees it through here.
 *
 * Where an internal signal has no contract name it is DROPPED rather than renamed into
 * something adjacent — a wrong-but-valid name is worse than a missing event, because it
 * silently corrupts the funnel analytics in §5.
 */
internal object NanoTelemetryMapper {

    /**
     * Journey fragment `STEP_NAME` -> contract §3 `step`. The SDK's step granularity is
     * finer than the contract's (ten screens, eight step values), so two disbursement
     * screens and the reject-reason sheet collapse onto their parent step.
     */
    fun contractStep(internalStepName: String?): String? = when (internalStepName) {
        // v3 screens with no contract `step` member deliberately return null.
        "kyc_details", "final_check", "direct_debit_mandate" -> null
        "digital_signature" -> NanoTelemetryContract.Step.AGREEMENTS
        "amount_and_duration" -> NanoTelemetryContract.Step.APPLY
        "employment_details" -> NanoTelemetryContract.Step.EMPLOYMENT
        "salary_verification" -> NanoTelemetryContract.Step.SALARY
        "application_details" -> NanoTelemetryContract.Step.CONFIRM
        "offer_review", "reject_reason", "offer_comparison" -> NanoTelemetryContract.Step.OFFER
        "disbursement_channel_selection", "disbursement_bank_iban" -> NanoTelemetryContract.Step.DISBURSEMENT
        "acceptance_otp" -> NanoTelemetryContract.Step.OTP
        "accept_confirmation" -> NanoTelemetryContract.Step.AGREEMENTS
        else -> null
    }

    /**
     * Ownership-configurable [NanoLoanStep] -> contract §3 `step`, or null where the
     * closed set has no member for it. The v3 steps (KYC, final check, mandate) have
     * none; the signature IS the agreements step, so that one maps. As everywhere else
     * here, an absent value beats a wrong-but-valid one.
     */
    fun contractStep(step: NanoLoanStep): String? = when (step) {
        NanoLoanStep.EMPLOYMENT_DETAILS -> NanoTelemetryContract.Step.EMPLOYMENT
        NanoLoanStep.SALARY_VERIFICATION -> NanoTelemetryContract.Step.SALARY
        NanoLoanStep.EMAIL_VERIFICATION -> NanoTelemetryContract.Step.OTP
        NanoLoanStep.DIGITAL_SIGNATURE -> NanoTelemetryContract.Step.AGREEMENTS
        NanoLoanStep.KYC_DETAILS,
        NanoLoanStep.FINAL_CHECK,
        NanoLoanStep.DIRECT_DEBIT_MANDATE -> null
    }

    /**
     * [NanoLoanState] -> contract §4 `state` name, or null for the four internal
     * transient states the contract has no name for (`ApplicationSubmitted`,
     * `AcceptingOffer`, `DecliningOffer` — plus `LoadingOffer`/`OfferAvailable` which DO
     * map, onto `AwaitingOffer`/`OfferReady`). Dropping them loses no funnel stage: each
     * is immediately followed by one that does map.
     */
    fun stateName(state: NanoLoanState): String? = when (state) {
        is NanoLoanState.Idle -> NanoTelemetryContract.State.IDLE
        is NanoLoanState.CheckingEligibility -> NanoTelemetryContract.State.CHECKING_ELIGIBILITY
        is NanoLoanState.Eligible -> NanoTelemetryContract.State.ELIGIBLE
        is NanoLoanState.Ineligible -> NanoTelemetryContract.State.INELIGIBLE
        is NanoLoanState.VerifyingSalary -> NanoTelemetryContract.State.VERIFYING_SALARY
        is NanoLoanState.SalaryVerified -> NanoTelemetryContract.State.SALARY_VERIFIED
        is NanoLoanState.SubmittingApplication -> NanoTelemetryContract.State.SUBMITTING_APPLICATION
        is NanoLoanState.LoadingOffer -> NanoTelemetryContract.State.AWAITING_OFFER
        is NanoLoanState.OfferAvailable -> NanoTelemetryContract.State.OFFER_READY
        is NanoLoanState.RequestingAcceptanceOtp -> NanoTelemetryContract.State.REQUESTING_ACCEPTANCE_OTP
        is NanoLoanState.AwaitingAcceptanceOtp -> NanoTelemetryContract.State.AWAITING_ACCEPTANCE_OTP
        is NanoLoanState.VerifyingAcceptanceOtp -> NanoTelemetryContract.State.VERIFYING_ACCEPTANCE_OTP
        is NanoLoanState.OfferAccepted -> NanoTelemetryContract.State.ACCEPTED
        is NanoLoanState.OfferDeclined -> NanoTelemetryContract.State.REJECTED
        is NanoLoanState.Failed -> NanoTelemetryContract.State.FAILED
        // No contract name — deliberately dropped, see the KDoc.
        is NanoLoanState.ApplicationSubmitted -> null
        is NanoLoanState.AcceptingOffer -> null
        is NanoLoanState.DecliningOffer -> null
    }

    /** [NanoLoanError] -> contract §3 `kind: error` `attrs.type`. */
    fun errorType(error: NanoLoanError): String = when (error) {
        is NanoLoanError.NotAuthenticated -> NanoTelemetryContract.ErrorType.NOT_AUTHENTICATED
        // The back-office's error types are a closed set; a new device is a sign-in step.
        is NanoLoanError.DeviceVerificationRequired -> NanoTelemetryContract.ErrorType.NOT_AUTHENTICATED
        is NanoLoanError.UserBlocked -> NanoTelemetryContract.ErrorType.USER_BLOCKED
        is NanoLoanError.Captcha -> NanoTelemetryContract.ErrorType.CAPTCHA
        is NanoLoanError.NoInternet -> NanoTelemetryContract.ErrorType.NETWORK
        is NanoLoanError.WrongPinOtp -> NanoTelemetryContract.ErrorType.VALIDATION
        is NanoLoanError.Api -> NanoTelemetryContract.ErrorType.API
        is NanoLoanError.Unknown -> NanoTelemetryContract.ErrorType.API
    }

    /**
     * A NanoLoanError carries no HTTP status of its own, only the backend's business
     * `errorCode`. NotAuthenticated is the one case where the status is unambiguous.
     */
    fun httpStatus(error: NanoLoanError): Int? = when (error) {
        is NanoLoanError.NotAuthenticated -> 401
        is NanoLoanError.NoInternet -> -1
        else -> null
    }

    /** `enableTryAgain` is the SDK's own "is this recoverable" judgement — reuse it. */
    fun recoverable(error: NanoLoanError): Boolean = error.enableTryAgain

    /** Contract §3 `kind: log` `attrs.level`. */
    fun logLevel(level: com.flooss.nanoloan.logging.NanoLogLevel): String? = when (level) {
        com.flooss.nanoloan.logging.NanoLogLevel.ERROR -> "error"
        com.flooss.nanoloan.logging.NanoLogLevel.WARNING -> "warn"
        com.flooss.nanoloan.logging.NanoLogLevel.INFO -> "info"
        com.flooss.nanoloan.logging.NanoLogLevel.DEBUG -> "debug"
        com.flooss.nanoloan.logging.NanoLogLevel.NONE -> null
    }
}
