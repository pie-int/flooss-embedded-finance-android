package com.flooss.nanoloan.repo

import com.flooss.nanoloan.model.AcceptanceOtpSession
import com.flooss.nanoloan.model.ActiveLoanInfo
import com.flooss.nanoloan.model.BankLinkResult
import com.flooss.nanoloan.model.BankProvider
import com.flooss.nanoloan.model.EligibilityResult
import com.flooss.nanoloan.model.LoanApplicationRequest
import com.flooss.nanoloan.model.LoanApplicationResult
import com.flooss.nanoloan.model.LoanOffer
import com.flooss.nanoloan.model.LoanProductInfo
import com.flooss.nanoloan.model.LoanStatus
import com.flooss.nanoloan.model.OfferInstallmentsPreview
import com.flooss.nanoloan.result.NanoLoanResult
import kotlinx.coroutines.delay
import java.math.BigDecimal
import kotlin.random.Random

/**
 * MOCK data source — used when [com.flooss.nanoloan.config.NanoLoanEnvironment.MOCK] is
 * configured. Never touches the network; returns canned successful responses after a
 * short delay so the sample host app can demonstrate the full journey + callback
 * sequence without live network access. Every function here is the MOCK path —
 * contrast with [RealNanoLoanDataSource], the REAL network path.
 *
 * Every simulated wire call reports itself through [onApiCall] with the REAL method +
 * path from API_SEQUENCE_FLOWS.md §4.1–§4.4, in the real call order, so the host's
 * event log shows the exact API sequence a live integration would produce, and with the
 * MEASURED wall-clock elapsed time of the simulated call — the mock's own delay, actually
 * timed rather than assumed to equal [MOCK_DELAY_MS].
 */
internal class MockNanoLoanDataSource(
    private val onApiCall: (method: String, path: String, httpStatus: Int, durationMs: Int) -> Unit
) : NanoLoanDataSource {

    /** The last application submitted this session; the canned offer is priced from it. */
    @Volatile private var lastApplication: LoanApplicationRequest? = null

    private suspend fun simulate(method: String, path: String, status: Int = 200) {
        val startedAtNanos = System.nanoTime()
        delay(MOCK_DELAY_MS)
        val durationMs = ((System.nanoTime() - startedAtNanos) / 1_000_000L)
            .coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()
        onApiCall(method, path, status, durationMs)
    }

    override suspend fun login(
        cpr: String,
        pin: String,
        clientId: String,
        clientSecret: String,
        scope: String
    ): NanoLoanResult<com.flooss.nanoloan.model.NanoLoanToken> {
        simulate("POST", "/api/v1/oauth/token")
        // Demo rule: any 4+ digit PIN passes; "0000" simulates a wrong-PIN 401.
        if (pin == "0000") {
            return NanoLoanResult.Failure(
                com.flooss.nanoloan.result.NanoLoanError.WrongPinOtp(message = "Invalid CPR or PIN")
            )
        }
        return NanoLoanResult.Success(
            com.flooss.nanoloan.model.NanoLoanToken(
                accessToken = "mock-salaf-access-token-${Random.nextInt(100000)}",
                refreshToken = "mock-salaf-refresh-token",
                expiresIn = 3600
            )
        )
    }

    override suspend fun getEmploymentOptions(
        bearerToken: String
    ): NanoLoanResult<com.flooss.nanoloan.model.EmploymentOptions> {
        simulate("GET", "/api/v1/fo/profile/attributes/EducationLevel")
        fun o(id: Long, label: String) = com.flooss.nanoloan.model.EmploymentOption(id, label)
        // Same ids and labels UAT returned on 2026-11-03.
        return NanoLoanResult.Success(
            com.flooss.nanoloan.model.EmploymentOptions(
                educationLevels = listOf(o(238, "High school Diploma & lower"), o(239, "University Diploma")),
                workExperience = listOf(o(233, "less than 2"), o(234, "2 to 5")),
                yearsInCurrentJob = listOf(o(228, "less than 2"), o(229, "2 to 3"))
            )
        )
    }

    override suspend fun saveEmploymentDetails(
        bearerToken: String,
        details: com.flooss.nanoloan.model.EmploymentDetails
    ): NanoLoanResult<Unit> {
        simulate("POST", "/api/v1/fo/client-profile/employment-details")
        return NanoLoanResult.Success(Unit)
    }

    override suspend fun getBankDetailForIban(
        bearerToken: String,
        iban: String
    ): NanoLoanResult<com.flooss.nanoloan.model.BankIbanDetail> {
        simulate("GET", "/api/v1/fo/loans/disbursement/bank-detail/$iban")
        return NanoLoanResult.Success(
            com.flooss.nanoloan.model.BankIbanDetail(
                bankName = "National Bank of Bahrain",
                bic = "NBOBBHBM",
                iban = iban
            )
        )
    }

    override suspend fun setDisbursementMethod(
        bearerToken: String,
        accountNumber: String,
        disbursementMethod: String
    ): NanoLoanResult<Unit> {
        simulate("PUT", "/api/v1/fo/applications/disburse-detail/$accountNumber?disbursementMethod=$disbursementMethod")
        return NanoLoanResult.Success(Unit)
    }

    override suspend fun checkEligibility(bearerToken: String, cpr: String): NanoLoanResult<EligibilityResult> {
        simulate("GET", "/api/v1/fo/client/check-eligibility")
        val restricted = isMockRejectedCpr(cpr)
        return NanoLoanResult.Success(
            EligibilityResult(
                restricted = restricted,
                restrictedReason = if (restricted) "Client is restricted (Soouq blacklist)" else null,
                remainingDays = if (restricted) 30 else 0,
                remainingHours = 0,
                remainingMinutes = 0,
                restrictedUntil = if (restricted) "2026-10-04" else ""
            )
        )
    }

    override suspend fun getProducts(bearerToken: String): NanoLoanResult<LoanProductInfo> {
        simulate("GET", "/api/v2/fo/products")
        return NanoLoanResult.Success(
            LoanProductInfo(
                id = 1L,
                guid = "mock-shariyah-product",
                displayName = "Sharia Financing",
                minLoanAmount = BigDecimal(MOCK_MIN_AMOUNT),
                maxLoanAmount = BigDecimal(MOCK_MAX_AMOUNT),
                minLoanPeriod = 2,
                maxLoanPeriod = 36,
                periodType = "MONTHS"
            )
        )
    }

    override suspend fun getActiveLoan(bearerToken: String): NanoLoanResult<ActiveLoanInfo> {
        simulate("GET", "/api/v1/fo/loans/active")
        return NanoLoanResult.Success(ActiveLoanInfo(hasActiveLoan = false, loanId = null, status = null))
    }

    override suspend fun getBankProviders(bearerToken: String): NanoLoanResult<List<BankProvider>> {
        simulate("GET", "/api/v1/fo/tarabut/providers")
        return NanoLoanResult.Success(MOCK_BANKS)
    }

    override suspend fun linkBankAccount(bearerToken: String, providerId: String): NanoLoanResult<BankLinkResult> {
        simulate("POST", "/api/v1/fo/tarabut/intent")
        // Real flow: customer completes the Tarabut connect web journey here, then the
        // app syncs the linked accounts.
        simulate("POST", "/api/v1/fo/tarabut/accounts/sync")
        return NanoLoanResult.Success(
            BankLinkResult(
                intentId = "mock-intent-${Random.nextInt(100000)}",
                synced = true,
                message = "Accounts synced"
            )
        )
    }

    override suspend fun uploadSalaryDocuments(
        bearerToken: String,
        documents: List<com.flooss.nanoloan.model.SalaryDocument>
    ): NanoLoanResult<List<com.flooss.nanoloan.model.UploadedDocument>> {
        simulate("POST", "/api/v1/salary/documents/EMPLOYMENT_BANK_STATEMENT/upload")
        return NanoLoanResult.Success(
            documents.take(MOCK_UPLOADED_DOCUMENTS).mapIndexed { i, d ->
                com.flooss.nanoloan.model.UploadedDocument("mock-doc-${i + 1}", d.fileName)
            }
        )
    }

    override suspend fun getCustomerProfile(
        bearerToken: String
    ): NanoLoanResult<com.flooss.nanoloan.model.CustomerProfile> {
        simulate("GET", "/api/v1/fo/client-profile")
        return NanoLoanResult.Success(
            com.flooss.nanoloan.model.CustomerProfile(
                fullName = "Sara Test",
                monthlySalary = java.math.BigDecimal(800),
                employerName = "Batelco",
                occupation = "Engineer"
            )
        )
    }

    override suspend fun walletSignIn(device: WalletDevice, mobileNumber: String, pin: String): NanoLoanResult<WalletSignIn> =
        NanoLoanResult.Success(WalletSignIn.Signed("mock-wallet-token", 1800))

    override suspend fun walletVerifyDevice(
        device: WalletDevice,
        actionUuid: String,
        otp: String,
        mobileNumber: String,
        pin: String
    ): NanoLoanResult<WalletSignIn.Signed> = NanoLoanResult.Success(WalletSignIn.Signed("mock-wallet-token", 1800))

    override suspend fun submitLoanApplication(
        bearerToken: String,
        request: LoanApplicationRequest,
        floossToken: String?
    ): NanoLoanResult<LoanApplicationResult> {
        simulate("POST", "/api/v1/fo/loans")
        lastApplication = request
        val applicationId = MOCK_APPLICATION_ID_BASE + Random.nextInt(1000)
        return NanoLoanResult.Success(
            LoanApplicationResult(
                id = applicationId,
                guid = "mock-application-$applicationId",
                status = LoanStatus.IN_APPROVAL_PROCESS,
                loanAmount = request.loanAmount,
                period = request.loanPeriod,
                periodType = request.loanPeriodType,
                anyActiveOfferExists = false
            )
        )
    }

    override suspend fun getActiveOffer(bearerToken: String): NanoLoanResult<LoanOffer> {
        simulate("GET", "/api/v1/fo/offers/active")
        val quote = mockQuote()
        return NanoLoanResult.Success(
            LoanOffer(
                id = MOCK_APPLICATION_ID_BASE,
                offerGuid = MOCK_OFFER_GUID,
                status = LoanStatus.OFFER,
                productName = "Nano Personal Finance",
                loanAmount = quote.principal,
                principalAmount = quote.principal,
                installmentAmount = quote.installment,
                totalAmount = quote.total,
                interestRate = "4.99%",
                period = quote.months.toLong(),
                periodType = com.flooss.nanoloan.model.PeriodType.MONTHS,
                offerExpiryDate = "2026-12-31"
            )
        )
    }

    /**
     * §2.4 — the second-phase decision. NOT on [NanoLoanDataSource]: no such endpoint
     * exists on Salaf yet, so only the mock can answer it and the repository refuses
     * outright in live environments rather than fabricating a credit decision.
     *
     * The answer is derived from what the HOST supplied, not from an SDK credit rule:
     * without a BCRB document reference nothing can be made final, so it declines with
     * that reason code. With one it approves at the canned offer's own figures.
     */
    suspend fun submitFinalCheck(
        bearerToken: String,
        bureau: com.flooss.nanoloan.model.BureauInput
    ): NanoLoanResult<com.flooss.nanoloan.model.FinalCheckResult> {
        simulate("POST", "/api/v1/fo/applications/final-check")
        if (bureau.bcrbDocumentReference.isNullOrBlank()) {
            return NanoLoanResult.Success(
                com.flooss.nanoloan.model.FinalCheckResult(
                    approved = false,
                    reasonCode = com.flooss.nanoloan.model.FinalCheckResult.REASON_BCRB_DOCUMENT_MISSING,
                    reasonMessage = "No current BCRB document was supplied for this application."
                )
            )
        }
        val quote = mockQuote()
        return NanoLoanResult.Success(
            com.flooss.nanoloan.model.FinalCheckResult(
                approved = true,
                approvedAmountFils = quote.principal.movePointRight(3).toLong(),
                tenorMonths = quote.months,
                monthlyInstalmentFils = quote.installment.movePointRight(3).toLong(),
                totalPayableFils = quote.total.movePointRight(3).toLong()
            )
        )
    }

    override suspend fun getOfferInstallments(bearerToken: String): NanoLoanResult<OfferInstallmentsPreview> {
        simulate("GET", "/api/v2/fo/loans/installments")
        val quote = mockQuote()
        return NanoLoanResult.Success(
            OfferInstallmentsPreview(
                pendingCount = quote.months,
                firstDueDate = "2026-09-27",
                installmentAmount = quote.installment
            )
        )
    }

    override suspend fun getLoanAgreement(bearerToken: String, loanAppId: Long): NanoLoanResult<Unit> {
        simulate("GET", "/api/v1/fo/loans/loan-agreement?loanAppId=$loanAppId")
        return NanoLoanResult.Success(Unit)
    }

    override suspend fun requestAcceptanceOtp(bearerToken: String): NanoLoanResult<AcceptanceOtpSession> {
        simulate("POST", "/api/v1/security/verifyEmail/sendEmailOtp")
        simulate("POST", "/api/v1/security/verifyPhone/sendSms")
        return NanoLoanResult.Success(
            AcceptanceOtpSession(
                emailVerificationUUID = "mock-email-uuid-${Random.nextInt(100000)}",
                phoneVerificationUUID = "mock-phone-uuid-${Random.nextInt(100000)}",
                maskedPhone = MOCK_MASKED_PHONE
            )
        )
    }

    override suspend fun acceptOffer(
        bearerToken: String,
        applicationId: Long,
        offerGuid: String
    ): NanoLoanResult<Unit> {
        simulate("POST", "/api/v1/fo/loans/normal/$applicationId/offers/$offerGuid/accept")
        return NanoLoanResult.Success(Unit)
    }

    override suspend fun verifyAcceptanceOtp(
        bearerToken: String,
        applicationId: Long,
        offerGuid: String,
        otp: String,
        phoneVerificationUUID: String?
    ): NanoLoanResult<Unit> {
        simulate("POST", "/api/v1/fo/loans/normal/$applicationId/offers/$offerGuid/verify-otp")
        // Mock accepts any 4–6 digit OTP.
        return NanoLoanResult.Success(Unit)
    }

    override suspend fun declineOffer(
        bearerToken: String,
        applicationId: Long,
        offerGuid: String,
        reason: String?
    ): NanoLoanResult<Unit> {
        simulate("POST", "/api/v1/fo/loans/$applicationId/offers/$offerGuid/decline")
        return NanoLoanResult.Success(Unit)
    }

    private class MockQuote(val principal: BigDecimal, val months: Int, val installment: BigDecimal, val total: BigDecimal)

    /**
     * The canned offer, priced from what the customer actually applied for with the same
     * ported formula the amount screen showed ([com.flooss.nanoloan.ui.NanoLoanMath]), so
     * offer, comparison, final decision and confirmation agree with each other.
     */
    private fun mockQuote(): MockQuote {
        val request = lastApplication
        val principal = (request?.loanAmount ?: BigDecimal(MOCK_DEFAULT_AMOUNT)).setScale(3)
        val months = (request?.loanPeriod?.toInt() ?: MOCK_DEFAULT_MONTHS).coerceAtLeast(1)
        val total = BigDecimal(com.flooss.nanoloan.ui.NanoLoanMath.totalToPay(principal.toFloat(), months))
            .setScale(3, java.math.RoundingMode.HALF_UP)
        val installment = total.divide(BigDecimal(months), 3, java.math.RoundingMode.HALF_UP)
        return MockQuote(principal, months, installment, total)
    }

    companion object {
        /**
         * Mock rejection trigger, identical on Android and iOS so one demo script works on
         * both: a CPR that STARTS with "999" or ENDS with "99" is restricted (Soouq blacklist).
         */
        fun isMockRejectedCpr(cpr: String): Boolean {
            val digits = cpr.trim()
            return digits.startsWith("999") || digits.endsWith("99")
        }

        private const val MOCK_DELAY_MS = 450L
        private const val MOCK_APPLICATION_ID_BASE = 900000L
        const val MOCK_OFFER_GUID = "mock-offer-guid"
        // Nano product bounds, identical to the iOS mock product (50-1000 BHD). The
        // pre-approval ceiling, the apply slider and the offer all come from these.
        const val MOCK_MIN_AMOUNT = 50
        const val MOCK_MAX_AMOUNT = 1000
        const val MOCK_DEFAULT_AMOUNT = 300
        const val MOCK_DEFAULT_MONTHS = 3
        const val MOCK_UPLOADED_DOCUMENTS = 3
        const val MOCK_MASKED_PHONE = "+973 •••• ••34"

        // Real Bahrain retail banks Tarabut lists in the app's bank picker.
        private val MOCK_BANKS = listOf(
            BankProvider("nbb", "NBB", "National Bank of Bahrain", "", "BH", "ACTIVE"),
            BankProvider("bbk", "BBK", "Bank of Bahrain and Kuwait", "", "BH", "ACTIVE"),
            BankProvider("ahli", "AUB", "Ahli United Bank", "", "BH", "ACTIVE"),
            BankProvider("bisb", "BisB", "Bahrain Islamic Bank", "", "BH", "ACTIVE"),
            BankProvider("khaleeji", "KHCB", "Khaleeji Commercial Bank", "", "BH", "ACTIVE"),
            BankProvider("salam", "ASBB", "Al Salam Bank", "", "BH", "ACTIVE")
        )
    }
}
