package com.flooss.nanoloan.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.model.EmploymentType
import com.flooss.nanoloan.model.LoanApplicationRequest
import com.flooss.nanoloan.model.LoanEmploymentInfo
import com.flooss.nanoloan.model.PeriodType
import com.flooss.nanoloan.result.NanoLoanResult
import java.math.BigDecimal

/**
 * Step 2 — REAL screen port of :app `ApplyLoanDetailFragment` +
 * `fragment_apply_loan_detail.xml` (application summary, dots 3/4 — the real app
 * numbers it 3/4 because its screen 2 is employment detail, not ported in this POC).
 * The summary rows mirror AppUtil.getApplyLoanDetailFromCreateLoan; customer fields the
 * real app reads from the logged-in profile come from canned demo values. Confirm runs
 * the SDK's real facade sequence: submitLoanApplication (POST api/v1/fo/loans, §4.1
 * step 7) -> getActiveOffer (all against MockNanoLoanDataSource in MOCK mode).
 * Eligibility is NOT re-checked here — the host runs checkLoanEligibility() as the
 * pre-approval seam before the journey ever opens (design doc §3.5 step 4).
 */
internal class NanoLoanApplyDetailFragment : NanoLoanJourneyFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_apply_loan_detail, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme

        setUpHeader(
            headerRoot = view.findViewById(R.id.parent_layout_header),
            title = getString(R.string.nanoloan_title_review_request),
            dotCount = 4,
            dotIndex = 4,
            screenNumber = "4/12",
            stepName = STEP_NAME
        ) {
            submitAndLoadOffer(view)
        }

        view.findViewById<ImageView>(R.id.loan_icon_iv)
            .setImageResource(R.drawable.ic_camera_placeholder)

        val amount = journeyData.loanAmount
        val duration = journeyData.loanDurationMonths
        val bhd = getString(R.string.bhd_app_text)
        // Mirrors AppUtil.getApplyLoanDetailFromCreateLoan row-for-row; the admin fee and
        // VAT are NanoLoanMath's, the same figures the offer screen and the total use.
        // Name and salary come from the customer's Flooss profile, loaded below.
        val rows = mutableListOf(
            KeyValueRow(getString(R.string.loan_name), journeyData.loanName),
            KeyValueRow(getString(R.string.loan_amount), "$amount $bhd"),
            KeyValueRow(
                getString(R.string.loan_duration),
                "$duration " + getString(
                    if (duration == 1) R.string.nanoloan_month_singular else R.string.nanoloan_month_plural
                )
            ),
            KeyValueRow(
                getString(R.string.approximate_installment),
                NanoLoanMath.getInstallmentToPay(amount.toFloat(), duration) + " $bhd"
            ),
            KeyValueRow(
                getString(R.string.approximate_total_to_pay),
                NanoLoanMath.getTotalToPay(amount.toFloat(), duration) + " $bhd"
            ),
            KeyValueRow(getString(R.string.approximate_processing_fee), "${NanoLoanMath.adminFeeText()} $bhd"),
            KeyValueRow(getString(R.string.approximate_vat), "${NanoLoanMath.adminFeeVatText()} $bhd"),
            KeyValueRow(getString(R.string.type), " " + getString(R.string.sharia_financing))
        )
        val list = view.findViewById<RecyclerView>(R.id.loan_detail_rv).apply {
            adapter = LoanDetailRowsAdapter(rows)
            layoutManager = LinearLayoutManager(requireContext())
        }

        val confirmBtn = view.findViewById<View>(R.id.confirm_btn)
        NanoLoanThemeApplier.applyPrimaryButton(confirmBtn, theme)
        confirmBtn.isEnabled = false
        confirmBtn.setOnClickListener { submitAndLoadOffer(view) }

        val progress = view.findViewById<View>(R.id.progress_bar)
        progress.visibility = View.VISIBLE
        NanoLoanSDK.loadCustomerProfile { result ->
            if (!isAdded) return@loadCustomerProfile
            progress.visibility = View.GONE
            when (result) {
                is NanoLoanResult.Success -> {
                    profile = result.value
                    val names = result.value.fullName.orEmpty().split(" ").filter { it.isNotBlank() }
                    rows += KeyValueRow(getString(R.string.first_name), names.firstOrNull().orEmpty())
                    rows += KeyValueRow(getString(R.string.last_name), names.drop(1).joinToString(" "))
                    list.adapter = LoanDetailRowsAdapter(rows)
                    if (result.value.monthlySalary == null) {
                        toast(R.string.nanoloan_salary_missing)
                    } else {
                        confirmBtn.isEnabled = true
                    }
                }
                is NanoLoanResult.Failure -> toast(R.string.nanoloan_profile_failed)
            }
        }
        view.findViewById<View>(R.id.cancel_btn).setOnClickListener {
            journeyHost.finishJourney()
        }
    }

    private var profile: com.flooss.nanoloan.model.CustomerProfile? = null

    private fun toast(message: Int) =
        android.widget.Toast.makeText(requireContext(), message, android.widget.Toast.LENGTH_LONG).show()

    private fun submitAndLoadOffer(view: View) {
        val salary = profile?.monthlySalary ?: return toast(R.string.nanoloan_salary_missing)
        val progress = view.findViewById<View>(R.id.progress_bar)
        progress.visibility = View.VISIBLE

        val request = LoanApplicationRequest(
            loanAmount = BigDecimal(journeyData.loanAmount),
            loanPeriod = journeyData.loanDurationMonths.toLong(),
            loanPeriodType = PeriodType.MONTHS,
            productId = journeyData.productId,
            loanName = journeyData.loanName,
            selectedRepaymentDate = journeyData.selectedRepaymentDate,
            employment = LoanEmploymentInfo(
                employmentType = EmploymentType.PRIVATE_EMPLOYEE,
                employerName = journeyData.employmentDetails?.companyName ?: profile?.employerName,
                occupation = journeyData.employmentDetails?.jobTitle ?: profile?.occupation,
                monthlySalary = salary,
                workStartDate = journeyData.employmentDetails?.startDate,
                bankStatements = journeyData.salaryDocuments
            )
        )
        NanoLoanSDK.submitLoanApplication(request) { submitted ->
            if (!isAdded) return@submitLoanApplication
            when (submitted) {
                is NanoLoanResult.Failure -> {
                    progress.visibility = View.GONE
                    toast(R.string.nanoloan_application_failed)
                }
                is NanoLoanResult.Success -> NanoLoanSDK.getActiveOffer { offer ->
                    if (!isAdded) return@getActiveOffer
                    progress.visibility = View.GONE
                    if (offer is NanoLoanResult.Success) {
                        journeyData.offer = offer.value
                        journeyHost.goToOfferComparison()
                    }
                }
            }
        }
    }

    companion object {
        const val STEP_NAME = "application_details"
    }
}
