package com.flooss.nanoloan.model

import java.math.BigDecimal

/**
 * Public response model for [com.flooss.nanoloan.NanoLoanSDK.getActiveOffer]. Another
 * trimmed subset of the app's `Loan` DTO, this time the offer-relevant fields
 * (`installmentAmount`, `totalAmount`, `interestRate`, `offerExpiryDate`, `product`).
 * Backed by the real `GET api/v1/fo/offers/active` endpoint
 * (`WebServiceConstants.GET_ACTIVE_OFFER`, `LoanApi.getActiveOffer`).
 *
 * [id] + [offerGuid] together are what `LoanApi.acceptOfferNormal`/`.rejectOffer` need as
 * path params (`{id}`/`{offerGuid}`) — the SDK facade's `acceptOffer(offerId)`/
 * `declineOffer(offerId)` take just [offerGuid] and resolve [id] from the last offer this
 * session fetched (see `NanoLoanSession.lastOfferApplicationId`).
 */
data class LoanOffer(
    val id: Long,
    val offerGuid: String,
    val status: LoanStatus,
    val productName: String?,
    val loanAmount: BigDecimal?,
    val principalAmount: BigDecimal?,
    val installmentAmount: BigDecimal?,
    val totalAmount: BigDecimal?,
    val interestRate: String?,
    val period: Long?,
    val periodType: PeriodType?,
    val offerExpiryDate: String?
)
