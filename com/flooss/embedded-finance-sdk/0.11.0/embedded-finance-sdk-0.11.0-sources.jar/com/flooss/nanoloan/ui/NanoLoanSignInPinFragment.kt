package com.flooss.nanoloan.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.ui.widget.CustomFontTextView

/**
 * sign_in step, screen 2: the customer's Flooss PIN, for the wallet and then Salaf.
 *
 * The PIN never leaves this screen as text: it is read into a CharArray, the field is
 * cleared at once, and the array is wiped when the sign-in ends ([SignInSession.clearPin]).
 * It is never logged and never reaches telemetry or a listener. The window is FLAG_SECURE
 * while the screen shows, so it is kept out of screenshots and the recents preview.
 */
internal class NanoLoanSignInPinFragment : NanoLoanJourneyFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_sign_in_pin, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setSecure(true)
        val theme = NanoLoanSDK.currentConfiguration().theme
        setUpHeader(
            headerRoot = view.findViewById(R.id.header),
            title = getString(R.string.nanoloan_sign_in_title),
            dotCount = 2,
            dotIndex = 2,
            screenNumber = "",
            stepName = STEP_NAME,
            onSkip = null
        )

        val boxes = buildPinBoxes(view.findViewById(R.id.pin_boxes))
        val field = view.findViewById<EditText>(R.id.et_pin)
        val error = view.findViewById<TextView>(R.id.tv_pin_error)
        val next = view.findViewById<View>(R.id.btn_pin_next)
        NanoLoanThemeApplier.applyPrimaryButton(next, theme)
        next.alpha = 0.5f

        field.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val length = s?.length ?: 0
                boxes.forEachIndexed { index, box -> box.text = if (index < length) MASK else "" }
                if (length > 0) error.visibility = View.GONE
                val complete = length == PIN_LENGTH
                next.isEnabled = complete
                next.alpha = if (complete) 1f else 0.5f
            }
        })
        field.requestFocus()
        submitOnDone(field, PIN_LENGTH, next)

        next.setOnClickListener {
            val text = field.text ?: return@setOnClickListener
            if (text.length != PIN_LENGTH) return@setOnClickListener
            val pin = CharArray(text.length)
            text.getChars(0, text.length, pin, 0)
            text.clear()
            submit(view, pin)
        }
    }

    private fun submit(view: View, pin: CharArray) {
        val signIn = NanoLoanSDK.activeJourneyBridge()?.signIn ?: run {
            pin.fill('\u0000')
            return
        }
        signIn.holdPin(pin)
        val progress = view.findViewById<View>(R.id.progress_bar)
        progress.visibility = View.VISIBLE
        NanoLoanSDK.signInCustomer(signIn.mobileNumber, pin) { outcome ->
            if (!isAdded) return@signInCustomer
            progress.visibility = View.GONE
            journeyHost.onSignInOutcome(outcome)?.let { message ->
                val error = view.findViewById<TextView>(R.id.tv_pin_error)
                error.text = message
                error.visibility = View.VISIBLE
                view.findViewById<EditText>(R.id.et_pin).requestFocus()
            }
        }
    }

    override fun onDestroyView() {
        setSecure(false)
        super.onDestroyView()
    }

    private fun setSecure(on: Boolean) {
        val window = (parentFragment as? NanoLoanJourneySheetFragment)?.dialog?.window ?: return
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun buildPinBoxes(container: LinearLayout): List<TextView> {
        val density = resources.displayMetrics.density
        val size = (34 * density).toInt()
        val spacing = (6 * density).toInt()
        return (0 until PIN_LENGTH).map { index ->
            val box = CustomFontTextView(container.context)
            box.setBackgroundResource(R.drawable.nanoloan_pin_box_bg)
            box.gravity = android.view.Gravity.CENTER
            box.textSize = 16f
            box.setTextColor(resources.getColor(R.color.app_blue, null))
            val params = LinearLayout.LayoutParams(size, size)
            if (index > 0) params.marginStart = spacing
            container.addView(box, params)
            box
        }
    }

    companion object {
        const val STEP_NAME = "sign_in_pin"
        const val PIN_LENGTH = 6
        private const val MASK = "•"
    }
}
