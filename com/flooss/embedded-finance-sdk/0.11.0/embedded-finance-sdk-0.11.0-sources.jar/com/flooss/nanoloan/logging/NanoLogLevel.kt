package com.flooss.nanoloan.logging

/** Ordered so `level.ordinal <= configured.ordinal` gates what reaches a sink. Design doc §11. */
enum class NanoLogLevel {
    NONE,
    ERROR,
    WARNING,
    INFO,
    DEBUG
}
