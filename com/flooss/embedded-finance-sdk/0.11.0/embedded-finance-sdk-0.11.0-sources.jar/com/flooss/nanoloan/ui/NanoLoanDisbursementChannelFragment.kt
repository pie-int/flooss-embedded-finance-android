package com.flooss.nanoloan.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.model.DisbursementTarget
import com.flooss.nanoloan.result.NanoLoanResult

/**
 * Post-acceptance disbursement channel selection — REAL screen port of :app
 * `LoanDisbursementChannelSelectionFragment` + `fragment_disbursement_channel_selection.xml`
 * ("Select Disbursement Channel", dots 3/3). The Flooss-card carousel path needs the
 * host app's wallet domain (cards/wallet repos), so this port renders the real
 * fragment's own no-cards branch (next disabled, "No Card available to show") and the
 * live path is the real "Or Enter Bank IBAN" button -> [NanoLoanDisbursementIbanFragment].
 * STC path not ported (optional per scope).
 *
 * Only the payout targets the partner's financing settings allow are shown (WALLET is the
 * card section and Next, BANK_IBAN the IBAN button). With the IBAN as the only target it
 * is preselected: the card section goes and Next continues to the IBAN entry.
 */
internal class NanoLoanDisbursementChannelFragment : NanoLoanJourneyFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_disbursement_channel, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme

        setUpHeader(
            headerRoot = view.findViewById(R.id.header),
            title = getString(R.string.nanoloan_title_disbursement),
            dotCount = 3,
            dotIndex = 3,
            screenNumber = "8/12",
            stepName = STEP_NAME
        ) {
            // Demo-mode Skip: jump straight to the OTP leg with no disbursement change.
            startAcceptanceOtp(view)
        }
        NanoLoanThemeApplier.applyChromeBackground(view.findViewById(R.id.root_layout), theme)

        val targets = NanoLoanSDK.allowedDisbursementTargets()
        val walletAllowed = DisbursementTarget.WALLET in targets
        val ibanAllowed = DisbursementTarget.BANK_IBAN in targets
        val nextButton = view.findViewById<View>(R.id.next_btn)
        val ibanButton = view.findViewById<View>(R.id.bank_iban_btn)
        ibanButton.setOnClickListener { journeyHost.goToDisbursementIban() }

        if (ibanAllowed && !walletAllowed) {
            // The partner allows the IBAN only: it is the selection, Next continues to it.
            view.findViewById<View>(R.id.card_container).visibility = View.GONE
            view.findViewById<View>(R.id.channel_divider).visibility = View.GONE
            ibanButton.visibility = View.GONE
            nextButton.isEnabled = true
            nextButton.setOnClickListener { journeyHost.goToDisbursementIban() }
        } else {
            // Real fragment's handleNoCardsLayout() branch: no wallet cards -> Next disabled.
            nextButton.isEnabled = false
            if (!ibanAllowed) {
                ibanButton.visibility = View.GONE
                view.findViewById<View>(R.id.channel_divider).visibility = View.GONE
            }
            if (!walletAllowed) {
                view.findViewById<View>(R.id.card_container).visibility = View.GONE
                nextButton.visibility = View.GONE
            }
        }
        view.findViewById<View>(R.id.tv_cancel).setOnClickListener {
            journeyHost.navigateBack()
        }
    }

    /** Same chain the real screen fires after a channel pick: sendSms -> OTP entry. */
    private fun startAcceptanceOtp(view: View) {
        val progress = view.findViewById<View>(R.id.progress_bar)
        progress.visibility = View.VISIBLE
        NanoLoanSDK.requestAcceptanceOtp { result ->
            if (!isAdded) return@requestAcceptanceOtp
            progress.visibility = View.GONE
            if (result is NanoLoanResult.Success) {
                journeyData.maskedOtpPhone = result.value.maskedPhone
                journeyHost.goToOtp()
            }
        }
    }

    companion object {
        const val STEP_NAME = "disbursement_channel_selection"
    }
}
