package com.flooss.nanoloan.listener

/**
 * Discrete, one-shot signals distinct from [NanoLoanState] (design doc §7.3, §9.1):
 * things that happen rather than states the journey sits in.
 */
sealed class NanoLoanEvent {
    data object SessionAuthenticated : NanoLoanEvent()

    /** Irrecoverable session expiry (design doc §7.3) — SDK does not silently re-auth. */
    data object SessionExpired : NanoLoanEvent()

    data object MockModeActive : NanoLoanEvent()

    /**
     * Demo-mode only: the journey UI's Skip affordance (visible only in MOCK mode)
     * advanced past [stepName] using canned data.
     */
    data class StepSkipped(val stepName: String) : NanoLoanEvent()

    /**
     * MOCK mode only: one simulated wire call, with the REAL method + path (from
     * API_SEQUENCE_FLOWS.md) it would have hit — emitted in the real call order so the
     * host can render the exact API sequence of a live integration.
     */
    data class ApiCallSimulated(
        val method: String,
        val path: String,
        val httpStatus: Int,
        /** Wall-clock milliseconds the simulated call actually took (the mock's own delay). */
        val durationMs: Int
    ) : NanoLoanEvent()

    /**
     * LIVE (non-MOCK) modes: one REAL wire call the SDK just executed — method, path and
     * the actual HTTP status the backend returned ([httpStatus] = -1 when the request
     * never got a response, i.e. a transport/DNS failure). The live twin of
     * [ApiCallSimulated] so the host's event log shows the real API sequence too.
     */
    data class ApiCallExecuted(
        val method: String,
        val path: String,
        val httpStatus: Int,
        /**
         * Wall-clock milliseconds measured around `chain.proceed()` in the SDK's OkHttp
         * interceptor — request write, server time and response-header read, excluding
         * body deserialization. Contract §3 `api_call.durationMs`. Measured on a
         * transport failure too, where it is the time until the failure.
         */
        val durationMs: Int
    ) : NanoLoanEvent()

    /**
     * Step-ownership Option B (design doc §3.5, §9.5): [step] is configured as
     * [com.flooss.nanoloan.config.NanoStepOwner.HOST], so the SDK paused the journey and
     * is waiting for the host to collect [fields] in its own UI and call
     * [com.flooss.nanoloan.NanoLoanSDK.submitStepInput].
     */
    data class InputRequired(
        val step: com.flooss.nanoloan.config.NanoLoanStep,
        val fields: List<String>
    ) : NanoLoanEvent()

    /** Option B resume: the host submitted [step]'s input and the journey continues. */
    data class StepInputSubmitted(val step: com.flooss.nanoloan.config.NanoLoanStep) : NanoLoanEvent()

    data class EligibilityChecked(val restricted: Boolean) : NanoLoanEvent()
    data class ApplicationSubmitted(val applicationId: Long) : NanoLoanEvent()
    data class OfferReceived(val offerId: String) : NanoLoanEvent()

    /** Salary verification finished — [method] is "BANK_SYNC" (Tarabut) or "DOCUMENT_UPLOAD". */
    data class SalaryVerified(val method: String) : NanoLoanEvent()

    /**
     * Email-OTP leg of the acceptance chain (`POST security/verifyEmail/sendEmailOtp`).
     * In MOCK mode it is auto-passed ([autoVerified] = true) to keep the demo short —
     * the real journey shows a separate email-OTP entry.
     */
    data class EmailOtpSent(val autoVerified: Boolean) : NanoLoanEvent()

    /** SMS-OTP leg of the acceptance chain (`POST security/verifyPhone/sendSms`). */
    data object SmsOtpSent : NanoLoanEvent()

    /** `POST .../verify-otp` passed — the acceptance is confirmed. */
    data class AcceptanceOtpVerified(val offerId: String) : NanoLoanEvent()

    data class OfferAccepted(val offerId: String) : NanoLoanEvent()
    data class OfferDeclined(val offerId: String) : NanoLoanEvent()

    /** Employment details saved (`POST api/v1/fo/client-profile/employment-details`). */
    data object EmploymentDetailsSaved : NanoLoanEvent()

    /**
     * Disbursement method chosen and confirmed against the backend
     * (`GET fo/loans/disbursement/bank-detail/{iban}` +
     * `PUT fo/applications/disburse-detail/{accountNumber}`) — [type] is
     * "BANK_ACCOUNT" (IBAN path) or "FLOOSS_CARD".
     */
    data class DisbursementMethodSet(val type: String) : NanoLoanEvent()

    // ── v3 screens (SDK_V3_PRODUCT_GAPS §2) ──────────────────────────────────────────

    /**
     * §2.2 — the two-offer comparison was presented. [hostOfferPresent] is false when the
     * host supplied none and the journey fell back to the single-offer screen.
     */
    data class OfferComparisonShown(val hostOfferPresent: Boolean) : NanoLoanEvent()

    /** §2.2 — the customer picked a side. HOST ends the SDK journey; FLOOSS continues it. */
    data class OfferSelected(
        val source: com.flooss.nanoloan.model.OfferSource
    ) : NanoLoanEvent()

    /** §2.3 — the additional-KYC step was completed. Field KEYS only, never values. */
    data class KycDetailsSubmitted(val fields: List<String>) : NanoLoanEvent()

    /** §2.4 — the second-phase decision started against host-supplied bureau data. */
    data object FinalCheckStarted : NanoLoanEvent()

    /**
     * §2.4 — the final decision. [reasonCode] is null on approval and a coded reason on
     * decline; free text never travels here.
     */
    data class FinalDecisionMade(
        val approved: Boolean,
        val reasonCode: String?
    ) : NanoLoanEvent()

    /** §2.6 — a document was signed. [signedAt] is an ISO-8601 instant. */
    data class DocumentSigned(val documentType: String, val signedAt: String) : NanoLoanEvent()

    /** §2.5 — the direct-debit mandate screen was reached. */
    data object DirectDebitSetup : NanoLoanEvent()

    /** §2.5 — the customer explicitly authorised the mandate. */
    data class MandateAuthorised(val maskedAccount: String) : NanoLoanEvent()
}
