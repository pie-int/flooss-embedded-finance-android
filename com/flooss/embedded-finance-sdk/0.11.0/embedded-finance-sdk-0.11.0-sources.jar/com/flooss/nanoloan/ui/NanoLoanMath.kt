package com.flooss.nanoloan.ui

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Ported from :app AppUtil.calculateTotalToPay/getTotalToPay/getInstallmentToPay and
 * AppConstants (PROFIT_RATE/ADMIN_FEE/VAT) so the amount+duration screen's estimated
 * figures behave exactly like the real screen while sliding.
 */
internal object NanoLoanMath {

    private const val PROFIT_RATE = 0.1676
    /**
     * The admin fee and its VAT: the single source for the review screen, the offer
     * screen and the total every screen shows (the total already includes both).
     */
    const val ADMIN_FEE = 6.5
    const val VAT = 0.65

    fun adminFeeText(): String = formatDouble(ADMIN_FEE)

    fun adminFeeVatText(): String = formatDouble(VAT)

    private fun calculateTotalToPay(amount: Float, duration: Int): Double =
        amount + (((amount * PROFIT_RATE) / 12) * duration) + ADMIN_FEE + VAT

    /** Unrounded total, for pricing a mock offer that must match this screen's figures. */
    fun totalToPay(amount: Float, duration: Int): Double = calculateTotalToPay(amount, duration)

    fun getTotalToPay(amount: Float, duration: Int): String =
        String.format(Locale.ENGLISH, "%.0f", calculateTotalToPay(amount, duration))

    fun getInstallmentToPay(amount: Float, duration: Int): String {
        val totalToPay = calculateTotalToPay(amount, duration)
        return String.format(Locale.ENGLISH, "%.0f", totalToPay / duration)
    }

    /** :app AppUtil.formatDouble — 3-dp amounts ("135.500"). */
    fun formatDouble(number: Double): String =
        DecimalFormat("0.000", DecimalFormatSymbols(Locale.US)).format(number)

    fun expectedFirstPaymentDate(repaymentDay: Int): String {
        val calendar = Calendar.getInstance()
        if (calendar.get(Calendar.DAY_OF_MONTH) >= repaymentDay || repaymentDay == 4) {
            calendar.add(Calendar.MONTH, 1)
        }
        calendar.set(Calendar.DAY_OF_MONTH, repaymentDay)
        return SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(calendar.time)
    }

    fun expectedEndMonth(repaymentDay: Int, durationMonths: Int): String {
        val calendar = Calendar.getInstance()
        if (calendar.get(Calendar.DAY_OF_MONTH) >= repaymentDay || repaymentDay == 4) {
            calendar.add(Calendar.MONTH, 1)
        }
        calendar.add(Calendar.MONTH, durationMonths - 1)
        return SimpleDateFormat("MMM yyyy", Locale.ENGLISH).format(calendar.time)
    }
}
