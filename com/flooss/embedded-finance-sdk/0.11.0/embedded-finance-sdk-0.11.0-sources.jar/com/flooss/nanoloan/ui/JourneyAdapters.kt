package com.flooss.nanoloan.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.flooss.nanoloan.R

internal data class KeyValueRow(val label: String, val value: String)

/**
 * Ported from :app `EstimateDataLoanAmtDurationAdapter` (the estimated
 * installment/total rows card on the amount+duration screen). Data-binding-free.
 */
internal class EstimateRowsAdapter(
    private var items: List<KeyValueRow>
) : RecyclerView.Adapter<EstimateRowsAdapter.RowViewHolder>() {

    fun update(items: List<KeyValueRow>) {
        this.items = items
        notifyDataSetChanged()
    }

    class RowViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvLabel: TextView = itemView.findViewById(R.id.tv_item_label)
        val tvValue: TextView = itemView.findViewById(R.id.tv_item_value)
        val divider: View = itemView.findViewById(R.id.item_divider)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_estimated_data_loan_amt_duration, parent, false)
        return RowViewHolder(view)
    }

    override fun onBindViewHolder(holder: RowViewHolder, position: Int) {
        val item = items[position]
        holder.tvLabel.text = item.label
        holder.tvValue.text = item.value
        holder.divider.visibility = if (position == items.lastIndex) View.GONE else View.VISIBLE
    }

    override fun getItemCount(): Int = items.size
}

/**
 * Ported from :app `ApplyLoanDetailListAdapter`/`LoanDetailListAdapter` — both inflate
 * loan_detail_item rows (label/value + divider). Data-binding-free.
 */
internal class LoanDetailRowsAdapter(
    private val items: List<KeyValueRow>
) : RecyclerView.Adapter<LoanDetailRowsAdapter.RowViewHolder>() {

    class RowViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTv: TextView = itemView.findViewById(R.id.titleTv)
        val descriptionTv: TextView = itemView.findViewById(R.id.descriptionTv)
        val divider: View = itemView.findViewById(R.id.divider)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.loan_detail_item, parent, false)
        return RowViewHolder(view)
    }

    override fun onBindViewHolder(holder: RowViewHolder, position: Int) {
        val item = items[position]
        holder.titleTv.text = item.label
        holder.descriptionTv.text = item.value
        holder.divider.visibility = if (position != items.lastIndex) View.VISIBLE else View.GONE
    }

    override fun getItemCount(): Int = items.size
}
