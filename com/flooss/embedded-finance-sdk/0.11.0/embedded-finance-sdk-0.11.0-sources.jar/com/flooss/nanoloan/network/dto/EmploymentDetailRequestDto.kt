package com.flooss.nanoloan.network.dto

/**
 * Body of `POST api/v1/fo/client-profile/employment-details` — the backend's
 * `ClientProfileEmploymentDetailsData`. The three ids are required (400 otherwise).
 */
internal data class EmploymentDetailRequestDto(
    val employerName: String,
    val occupation: String,
    val educationLevel: Long,
    val workExperience: Long,
    val yearsInCurrentJob: Long
)

/** `GET api/v1/fo/profile/attributes/{type}` — e.g. EducationLevel, WorkExperience. */
internal data class ProfileAttributesDto(
    val target: List<ProfileAttributeDto>? = null
)

internal data class ProfileAttributeDto(
    val id: Long? = null,
    val description: String? = null,
    val active: Boolean? = null
)
