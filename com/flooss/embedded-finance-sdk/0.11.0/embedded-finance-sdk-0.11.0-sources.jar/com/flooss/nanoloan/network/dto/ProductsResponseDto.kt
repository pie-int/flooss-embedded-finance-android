package com.flooss.nanoloan.network.dto

import com.google.gson.annotations.SerializedName
import java.math.BigDecimal

/**
 * Wire shape of `GET api/v2/fo/products` (`WebServiceConstants.GET_PRODUCT`,
 * `SalafApi.hitGetProductApi` -> `Response<Product>`). Trimmed mirror of the app's
 * `LoanProductRes` — the map is keyed by product type; this journey only reads the
 * `SHARIYAH` (personal Sharia financing) entry, and of it only the amount/period
 * envelope fields.
 */
data class ProductsResponseDto(
    @SerializedName("products") val products: ProductMapDto?
)

data class ProductMapDto(
    @SerializedName("SHARIYAH") val shariyah: ProductDetailsDto?
)

data class ProductDetailsDto(
    @SerializedName("id") val id: Long?,
    @SerializedName("guid") val guid: String?,
    @SerializedName("displayName") val displayName: String?,
    @SerializedName("productName") val productName: String?,
    @SerializedName("type") val type: String?,
    @SerializedName("defLoanAmount") val defLoanAmount: Double?,
    @SerializedName("defLoanPeriod") val defLoanPeriod: Int?,
    @SerializedName("minLoanAmount") val minLoanAmount: BigDecimal?,
    @SerializedName("maxLoanAmount") val maxLoanAmount: BigDecimal?,
    @SerializedName("minLoanPeriod") val minLoanPeriod: Int?,
    @SerializedName("maxLoanPeriod") val maxLoanPeriod: Int?,
    @SerializedName("periodType") val periodType: String?
)
