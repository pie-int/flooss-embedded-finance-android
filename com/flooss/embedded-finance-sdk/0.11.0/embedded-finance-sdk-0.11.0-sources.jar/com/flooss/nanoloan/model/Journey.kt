package com.flooss.nanoloan.model

import com.flooss.nanoloan.result.NanoLoanResult
import java.math.BigDecimal

/** What the customer came to do. [AUTO] lets Flooss choose from the partner's settings. */
enum class JourneyIntent {
    MERCHANT_CHECKOUT,
    CASH_LOAN,
    AUTO
}

/** The journey Flooss decided to run (never [JourneyIntent.AUTO]). */
enum class JourneyMode {
    MERCHANT_CHECKOUT,
    CASH_LOAN
}

/** How an allowed journey ended. A refusal or an error is a failure instead, not a status. */
enum class JourneyStatus {
    /** The customer finished the journey. */
    COMPLETED,

    /** The customer closed or backed out of the journey. */
    ABANDONED,

    /** The customer declined Flooss's offer. */
    OFFER_DECLINED,

    /** The customer chose the host's own offer on the comparison screen. */
    HOST_OFFER_SELECTED,

    /** Flooss could not finance the customer (not eligible, nothing financeable, final check declined). */
    NOT_APPROVED,

    /** The mobile number the customer entered has no Flooss account; they were offered the Flooss app. */
    NOT_A_FLOOSS_CUSTOMER,

    /** The customer's Flooss account is locked or blocked, so they cannot sign in. */
    ACCOUNT_LOCKED,

    /** The customer already has an application Flooss is reviewing; [JourneyResult.applicationId] names it. */
    APPLICATION_IN_REVIEW,

    /** The customer has an active loan and Flooss cannot finance another; see [JourneyResult.outstandingAmount]. */
    EXISTING_LOAN,

    /** The customer has an overdue loan; see [JourneyResult.outstandingAmount]. */
    LOAN_OVERDUE
}

/**
 * Merchant checkout: the host's backend creates the Salaf payment code for the amount
 * Flooss finances and hands it back through [callback]. Called on the main thread; the
 * host may answer from any thread.
 */
fun interface CheckoutCodeProvider {
    fun createCheckoutCode(
        financedAmount: BigDecimal,
        currency: String,
        callback: (NanoLoanResult<String>) -> Unit
    )
}

/**
 * Input to [com.flooss.nanoloan.NanoLoanSDK.startJourney].
 *
 * @param amount the basket or requested amount in [currency] major units; prefills the
 * amount screen of a cash loan and is what a merchant checkout splits.
 * @param orderRef the host's own order reference, echoed into the journey record.
 * @param externalUserRef overrides [com.flooss.nanoloan.config.NanoLoanConfiguration.externalUserRef]
 * for this journey; the same opacity rule applies (a PII-shaped value is not sent).
 * @param checkoutCodeProvider required by merchant checkout steps; ignored by a cash loan.
 * @param mobileNumber the customer's mobile number, if the host knows it: only prefills the
 * SDK's sign-in screen, which the customer can edit. The SDK signs the customer in itself;
 * a host never collects the Flooss PIN or the CPR.
 */
data class JourneyRequest(
    val intent: JourneyIntent,
    val amount: BigDecimal? = null,
    val currency: String = "BHD",
    val orderRef: String? = null,
    val externalUserRef: String? = null,
    val checkoutCodeProvider: CheckoutCodeProvider? = null,
    val mobileNumber: String? = null
) {
    /** The mobile number is the customer's; keep it out of logs and event descriptions. */
    override fun toString(): String =
        "JourneyRequest(intent=$intent, amount=$amount, currency=$currency, orderRef=$orderRef, " +
            "externalUserRef=$externalUserRef, checkoutCodeProvider=$checkoutCodeProvider, " +
            "mobileNumber=${if (mobileNumber == null) "null" else "•••"})"
}

/**
 * The outcome of an allowed journey. Amounts are in the journey's currency major units
 * and null when the journey ended before they were known.
 */
data class JourneyResult(
    val journeyId: String,
    val mode: JourneyMode,
    val status: JourneyStatus,
    val financedAmount: BigDecimal?,
    /** What the customer still pays the merchant themselves (partial financing). */
    val remainderAmount: BigDecimal?,
    /** Set for [JourneyStatus.APPLICATION_IN_REVIEW] (the application under review) and for a completed application. */
    val applicationId: Long?,
    val merchantTransactionRef: String?,
    /** What the customer still owes on their existing loan; set only for [JourneyStatus.EXISTING_LOAN] and [JourneyStatus.LOAN_OVERDUE]. */
    val outstandingAmount: BigDecimal? = null
)
