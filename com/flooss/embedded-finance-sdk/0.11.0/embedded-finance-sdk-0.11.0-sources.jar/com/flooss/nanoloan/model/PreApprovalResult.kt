package com.flooss.nanoloan.model

import java.math.BigDecimal

/**
 * Result of the host-driven soft pre-approval (design doc §3.5 step 4 — "soft
 * eligibility check" on lightweight signals). Wraps the real
 * `GET api/v1/fo/client/check-eligibility` response ([eligibility]) and adds the
 * host-facing pre-approval surface the Benefit Pay reference flow needs to render its
 * own result screen: an approved flag, an indicative maximum amount (from the SHARIYAH
 * product's `maxLoanAmount` — `GET api/v2/fo/products`), and a reject reason.
 */
data class PreApprovalResult(
    val approved: Boolean,
    val indicativeMaxAmount: BigDecimal?,
    val currency: String = "BHD",
    val reason: String?,
    val eligibility: EligibilityResult
)
