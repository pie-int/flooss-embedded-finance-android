package com.flooss.nanoloan.ui.widget

import android.content.Context
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.res.ResourcesCompat
import com.flooss.nanoloan.R

/**
 * Ported from :app `com.pie.flooss.util.CustomFontButton`. Only adaptation: the Arabic
 * check reads the SDK's configured locale instead of the app's `loadLocale()`.
 */
class CustomFontButton : AppCompatButton {
    constructor(context: Context?, attrs: AttributeSet?, defStyle: Int) : super(
        context!!,
        attrs,
        defStyle
    ) {
        init(attrs)
    }

    constructor(context: Context?, attrs: AttributeSet?) : super(context!!, attrs) {
        init(attrs)
    }

    constructor(context: Context?) : super(context!!) {
        init(null)
    }

    private fun init(attrs: AttributeSet?) {
        if (attrs != null) {
            var fontId = R.font.exosoft_regular
            if (NanoLoanFontResolver.isArabic()) {
                // Loading specific font for Arabic
                fontId = R.font.somarsans_regular
            }
            val a = context.obtainStyledAttributes(attrs, R.styleable.TypefaceTextView)
            val fontResource =
                a.getResourceId(R.styleable.TypefaceTextView_font, fontId)
            try {
                typeface = ResourcesCompat.getFont(context, fontResource)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            a.recycle()
        }
    }
}
