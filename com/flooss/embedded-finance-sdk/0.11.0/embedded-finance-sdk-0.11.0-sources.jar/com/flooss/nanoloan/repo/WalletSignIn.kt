package com.flooss.nanoloan.repo

/** What the wallet's device check decided for this sign-in. */
internal sealed class WalletSignIn {
    data class Signed(val accessToken: String, val expiresInSeconds: Long, val customerId: Long? = null) : WalletSignIn()

    /** New device: an SMS code went to [phoneNumber]; verify it against [actionUuid]. */
    data class OtpRequired(val actionUuid: String, val phoneNumber: String) : WalletSignIn()

    /** The wallet refused the PIN; [failedCount] is its count of wrong attempts, 0 when it did not say. */
    data class WrongPin(val failedCount: Int) : WalletSignIn()
}

/** Where the wallet sign-in runs and as which device. */
internal data class WalletDevice(val baseUrl: String, val udid: String, val make: String, val model: String)
