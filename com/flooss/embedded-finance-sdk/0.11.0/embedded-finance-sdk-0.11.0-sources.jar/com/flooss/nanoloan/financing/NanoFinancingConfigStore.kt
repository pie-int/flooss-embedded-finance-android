package com.flooss.nanoloan.financing

import android.content.SharedPreferences
import java.security.MessageDigest

/** The last good settings, as the back office sent them. */
internal data class StoredFinancingConfig(val json: String, val etag: String?, val fetchedAtMillis: Long)

internal interface NanoFinancingConfigStore {
    fun load(): StoredFinancingConfig?
    fun save(stored: StoredFinancingConfig)
    fun clear()
}

internal class InMemoryFinancingConfigStore : NanoFinancingConfigStore {
    @Volatile private var stored: StoredFinancingConfig? = null
    override fun load(): StoredFinancingConfig? = stored
    override fun save(stored: StoredFinancingConfig) { this.stored = stored }
    override fun clear() { stored = null }
}

/**
 * One entry per environment and partner key, so switching either never serves another
 * one's settings. The key itself is never written: only a truncated SHA-256 of it names
 * the entry.
 */
internal class SharedPreferencesFinancingConfigStore(
    private val prefs: SharedPreferences,
    environment: String,
    partnerKey: String
) : NanoFinancingConfigStore {

    private val prefix = "financing_config.$environment.${keyHash(partnerKey)}"

    override fun load(): StoredFinancingConfig? {
        val json = prefs.getString("$prefix.json", null) ?: return null
        return StoredFinancingConfig(
            json = json,
            etag = prefs.getString("$prefix.etag", null),
            fetchedAtMillis = prefs.getLong("$prefix.fetchedAt", 0L)
        )
    }

    override fun save(stored: StoredFinancingConfig) {
        prefs.edit()
            .putString("$prefix.json", stored.json)
            .putString("$prefix.etag", stored.etag)
            .putLong("$prefix.fetchedAt", stored.fetchedAtMillis)
            .apply()
    }

    override fun clear() {
        prefs.edit().remove("$prefix.json").remove("$prefix.etag").remove("$prefix.fetchedAt").apply()
    }

    companion object {
        fun keyHash(partnerKey: String): String =
            MessageDigest.getInstance("SHA-256").digest(partnerKey.toByteArray(Charsets.UTF_8))
                .take(8).joinToString("") { "%02x".format(it) }
    }
}
