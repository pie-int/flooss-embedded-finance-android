package com.flooss.nanoloan.config

private const val BACK_OFFICE_URL = "https://self-manage.flooss.com"

/**
 * The Flooss environment the SDK talks to. This is the only network choice a host makes:
 * the lending backend and the SDK Operations Back-Office addresses belong to the
 * environment and are not configurable.
 *
 * [UAT] and [PROD] hit the real Salaf backend (the app's `SERVER_URL_SALAF` per-flavor
 * values). [MOCK] never makes a lending call: [com.flooss.nanoloan.repo.NanoLoanRepository]
 * routes to [com.flooss.nanoloan.repo.MockNanoLoanDataSource], which returns canned
 * responses, so a host can build its integration with no Flooss credentials. Every
 * environment reports to the back-office, which records the session under its environment.
 */
enum class NanoLoanEnvironment(
    internal val loanBaseUrl: String?,
    /** The Flooss wallet; its token lets the lending backend refresh eKYC at submission. */
    internal val walletBaseUrl: String?,
    internal val backOfficeUrl: String
) {
    UAT("https://salaf-backend.ir-uat.flooss.com/pie/", "https://flooss-backend.ir-uat.flooss.com/flooss/", BACK_OFFICE_URL),
    PROD("https://mapp.flooss.com/pie/", "https://mapp.flooss.com/flooss/", BACK_OFFICE_URL),
    MOCK(null, null, BACK_OFFICE_URL)
}
