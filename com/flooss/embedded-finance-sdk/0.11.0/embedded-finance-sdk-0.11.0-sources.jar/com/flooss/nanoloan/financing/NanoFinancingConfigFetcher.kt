package com.flooss.nanoloan.financing

import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/** Outcome of one `GET /v1/sdk/config`. */
internal sealed class FinancingFetchResult {
    data class Fetched(val config: NanoFinancingConfig, val json: String, val etag: String?) : FinancingFetchResult()

    /** 304 — the cached copy is still current. */
    object NotModified : FinancingFetchResult()

    /**
     * 401/403 — an answer, not an outage. [environmentRefused]: 403 environment_mismatch or
     * environment_disabled (the key may not use this environment); otherwise the key itself
     * was refused (bad, revoked, stopped tenant).
     */
    data class Refused(val status: Int, val environmentRefused: Boolean = false) : FinancingFetchResult()

    /** 400 (`invalid_environment`, …): the request itself was refused, with the back office's `error` code. */
    data class Invalid(val code: String?) : FinancingFetchResult()

    /** Transport failure, 5xx, any other status, or a body that is not a settings object. */
    data class Failed(val reason: String) : FinancingFetchResult()
}

/** Seam so the cache and gating logic are unit-testable with no socket. */
internal interface NanoFinancingConfigFetcher {
    fun fetch(etag: String?): FinancingFetchResult
}

/**
 * Reads the partner's financing settings from the back office the telemetry already
 * reports to: same base URL, same `Authorization: Bearer <partnerKey>`, same timeouts as
 * [com.flooss.nanoloan.telemetry.OkHttpTelemetrySender]. Its own [OkHttpClient], so the
 * call never shows up in the journey's `ApiCallExecuted` stream.
 */
internal class OkHttpFinancingConfigFetcher(
    private val baseUrl: String,
    private val apiKey: () -> String,
    /** Sent as `?environment=`: a test key covers MOCK/DEV/QA/UAT, so the SDK names its own. */
    private val environment: String,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .build()
) : NanoFinancingConfigFetcher {

    override fun fetch(etag: String?): FinancingFetchResult {
        return try {
            val request = Request.Builder()
                .url(baseUrl.trimEnd('/') + CONFIG_PATH + "?environment=" + environment)
                .addHeader("Authorization", "Bearer ${apiKey()}")
                .addHeader("Accept", "application/json")
                // The ETag is opaque (it may end in ":paused"); it goes back exactly as received.
                .apply { if (etag != null) addHeader("If-None-Match", etag) }
                .get()
                .build()
            client.newCall(request).execute().use { response ->
                when {
                    response.code == 304 -> FinancingFetchResult.NotModified
                    response.code == 401 || response.code == 403 -> FinancingFetchResult.Refused(
                        response.code,
                        environmentRefused = com.flooss.nanoloan.journey.OkHttpJourneyApi.errorCode(response.body?.string()) in
                            com.flooss.nanoloan.journey.OkHttpJourneyApi.ENVIRONMENT_REFUSALS
                    )
                    response.code == 400 -> FinancingFetchResult.Invalid(
                        com.flooss.nanoloan.journey.OkHttpJourneyApi.errorCode(response.body?.string())
                    )
                    response.isSuccessful -> {
                        val json = response.body?.string().orEmpty()
                        NanoFinancingConfig.parse(json)
                            ?.let { FinancingFetchResult.Fetched(it, json, response.header("ETag")) }
                            ?: FinancingFetchResult.Failed("unreadable body")
                    }
                    else -> FinancingFetchResult.Failed("HTTP ${response.code}")
                }
            }
        } catch (t: Throwable) {
            FinancingFetchResult.Failed(t.javaClass.simpleName)
        }
    }

    companion object {
        const val CONFIG_PATH = "/v1/sdk/config"
    }
}
