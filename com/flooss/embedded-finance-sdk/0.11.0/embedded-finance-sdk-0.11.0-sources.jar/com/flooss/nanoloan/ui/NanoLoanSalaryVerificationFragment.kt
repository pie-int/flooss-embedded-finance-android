package com.flooss.nanoloan.ui

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.model.BankProvider
import com.flooss.nanoloan.model.SalaryDocument
import com.flooss.nanoloan.result.NanoLoanResult

/**
 * Step 2 — salary verification (API_SEQUENCE_FLOWS §4.1 steps 4–6 + §4.2). Derived
 * from :app `BaseConnectToBankFragment` + `fragment_connect_to_bank.xml` (method
 * chooser) with `fragment_select_bank.xml`'s Tarabut bank list inlined — see the
 * layout header comment for exactly what is ported vs recreated.
 *
 * Two paths, both against the SDK facade (mock-simulated wire calls in MOCK mode):
 *  - Link bank: pick a provider from `GET fo/tarabut/providers` -> the SDK runs
 *    `POST fo/tarabut/intent` + `POST fo/tarabut/accounts/sync` behind a spinner.
 *  - Upload documents: `POST api/v1/salary/documents/{folder}/upload` (simulated —
 *    no document picker in the demo).
 */
internal class NanoLoanSalaryVerificationFragment : NanoLoanJourneyFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_salary_verification, container, false)

    private val pickStatements =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            val root = view ?: return@registerForActivityResult
            if (uris.isNotEmpty()) uploadDocuments(root, uris.take(MAX_STATEMENTS))
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme

        setUpHeader(
            headerRoot = view.findViewById(R.id.header_layout),
            title = getString(R.string.nanoloan_title_verify_salary),
            dotCount = 4,
            dotIndex = 3,
            screenNumber = "3/12",
            stepName = STEP_NAME
        ) {
            journeyData.salaryVerificationMethod = null
            journeyHost.goToApplyDetail()
        }
        NanoLoanThemeApplier.applyChromeBackground(view.findViewById(R.id.rootLayout), theme)

        val banksList = view.findViewById<RecyclerView>(R.id.banksList)
        banksList.layoutManager = LinearLayoutManager(requireContext())

        // Bank list load = the real flow's `GET api/v1/fo/tarabut/providers`.
        NanoLoanSDK.getSalaryBankProviders { result ->
            if (!isAdded) return@getSalaryBankProviders
            if (result is NanoLoanResult.Success) {
                banksList.adapter = BankRowsAdapter(result.value) { bank -> linkBank(view, bank) }
            }
        }

        view.findViewById<View>(R.id.upload_documents_btn).setOnClickListener {
            pickStatements.launch(arrayOf("application/pdf"))
        }
        view.findViewById<View>(R.id.cancel_btn).setOnClickListener {
            journeyHost.finishJourney()
        }
    }

    private fun linkBank(view: View, bank: BankProvider) {
        val overlay = view.findViewById<View>(R.id.progress_overlay)
        view.findViewById<TextView>(R.id.progress_text).text =
            getString(R.string.nanoloan_connecting_bank)
        overlay.visibility = View.VISIBLE
        NanoLoanSDK.linkBankForSalaryVerification(bank.providerId) { result ->
            if (!isAdded) return@linkBankForSalaryVerification
            overlay.visibility = View.GONE
            if (result is NanoLoanResult.Success) {
                journeyData.salaryVerificationMethod = "BANK_SYNC"
                journeyData.selectedBankName = bank.displayName
                journeyHost.goToApplyDetail()
            }
        }
    }

    private fun uploadDocuments(view: View, uris: List<Uri>) {
        val resolver = requireContext().contentResolver
        val documents = uris.mapNotNull { uri ->
            val bytes = runCatching { resolver.openInputStream(uri)?.use { it.readBytes() } }.getOrNull()
            val name = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            } ?: "statement.pdf"
            bytes?.takeIf { it.isNotEmpty() }?.let { SalaryDocument(name, it) }
        }
        val overlay = view.findViewById<View>(R.id.progress_overlay)
        view.findViewById<TextView>(R.id.progress_text).text =
            getString(R.string.nanoloan_upload_documents)
        overlay.visibility = View.VISIBLE
        NanoLoanSDK.uploadSalaryDocuments(documents) { result ->
            if (!isAdded) return@uploadSalaryDocuments
            overlay.visibility = View.GONE
            when (result) {
                is NanoLoanResult.Success -> {
                    journeyData.salaryDocuments = result.value
                    journeyData.salaryVerificationMethod = "DOCUMENT_UPLOAD"
                    journeyData.selectedBankName = null
                    journeyHost.goToApplyDetail()
                }
                is NanoLoanResult.Failure ->
                    Toast.makeText(requireContext(), R.string.nanoloan_upload_failed, Toast.LENGTH_LONG).show()
            }
        }
    }

    companion object {
        private const val MAX_STATEMENTS = 3
        const val STEP_NAME = "salary_verification"
    }
}

/** Bank rows for the inlined Tarabut picker (see nanoloan_item_bank.xml). */
private class BankRowsAdapter(
    private val banks: List<BankProvider>,
    private val onPick: (BankProvider) -> Unit
) : RecyclerView.Adapter<BankRowsAdapter.BankViewHolder>() {

    class BankViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val initials: TextView = itemView.findViewById(R.id.bank_initials)
        val name: TextView = itemView.findViewById(R.id.bank_name)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BankViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.nanoloan_item_bank, parent, false)
        return BankViewHolder(view)
    }

    override fun onBindViewHolder(holder: BankViewHolder, position: Int) {
        val bank = banks[position]
        holder.initials.text = bank.name
        holder.name.text = bank.displayName
        holder.itemView.setOnClickListener { onPick(bank) }
    }

    override fun getItemCount(): Int = banks.size
}
