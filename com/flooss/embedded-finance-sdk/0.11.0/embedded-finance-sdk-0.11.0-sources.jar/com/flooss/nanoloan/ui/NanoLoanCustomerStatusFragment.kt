package com.flooss.nanoloan.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.os.bundleOf
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.journey.CustomerStatusScreen
import com.flooss.nanoloan.model.JourneyStatus
import java.math.BigDecimal

/**
 * What sign-in found about the customer, before any financing step: no Flooss account
 * (with a way to get the Flooss app), a locked account, an application already in review,
 * an overdue loan, or a running loan with Salaf's answer on more financing. Only the
 * eligible running-loan card lets the journey go on; the others end it with their status.
 */
internal class NanoLoanCustomerStatusFragment : NanoLoanJourneyFragment() {

    enum class Kind { NOT_A_FLOOSS_CUSTOMER, ACCOUNT_LOCKED, APPLICATION_IN_REVIEW, LOAN_OVERDUE, ACTIVE_LOAN_ELIGIBLE, EXISTING_LOAN }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_customer_status, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme
        val args = requireArguments()
        val kind = Kind.valueOf(args.getString(ARG_KIND) ?: Kind.ACCOUNT_LOCKED.name)
        setUpHeader(
            headerRoot = view.findViewById(R.id.header),
            title = getString(R.string.nanoloan_status_title),
            dotCount = 1,
            dotIndex = 1,
            screenNumber = "",
            stepName = STEP_NAME,
            onSkip = null
        )
        NanoLoanThemeApplier.applyChromeBackground(view.findViewById(R.id.rootLayout), theme)

        val heading = view.findViewById<TextView>(R.id.status_heading)
        val detail = view.findViewById<TextView>(R.id.status_detail)
        val note = view.findViewById<TextView>(R.id.status_note)
        val primary = view.findViewById<TextView>(R.id.status_primary_btn)
        val secondary = view.findViewById<TextView>(R.id.status_secondary_btn)
        NanoLoanThemeApplier.applyPrimaryButton(primary, theme)

        val close = { status: JourneyStatus -> journeyHost.finishJourney(status) }
        when (kind) {
            Kind.NOT_A_FLOOSS_CUSTOMER -> {
                heading.setText(R.string.nanoloan_not_customer_heading)
                detail.setText(R.string.nanoloan_not_customer_detail)
                primary.setText(R.string.nanoloan_get_flooss)
                primary.setOnClickListener { openFlooss() }
                secondary.visibility = View.VISIBLE
                secondary.setOnClickListener { close(JourneyStatus.NOT_A_FLOOSS_CUSTOMER) }
            }
            Kind.ACCOUNT_LOCKED -> {
                heading.setText(R.string.nanoloan_locked_heading)
                detail.setText(R.string.nanoloan_locked_detail)
                primary.setText(R.string.nanoloan_close)
                primary.setOnClickListener { close(JourneyStatus.ACCOUNT_LOCKED) }
            }
            Kind.APPLICATION_IN_REVIEW -> {
                heading.setText(R.string.nanoloan_in_review_heading)
                detail.setText(R.string.nanoloan_in_review_detail)
                args.getString(ARG_APPLICATION_ID)?.let {
                    note.text = getString(R.string.nanoloan_in_review_reference, it)
                    note.visibility = View.VISIBLE
                }
                primary.setText(R.string.nanoloan_close)
                primary.setOnClickListener { close(JourneyStatus.APPLICATION_IN_REVIEW) }
            }
            Kind.LOAN_OVERDUE -> {
                heading.setText(R.string.nanoloan_overdue_heading)
                detail.setText(R.string.nanoloan_overdue_detail)
                showCard(view, args)
                primary.setText(R.string.nanoloan_close)
                primary.setOnClickListener { close(JourneyStatus.LOAN_OVERDUE) }
            }
            Kind.ACTIVE_LOAN_ELIGIBLE -> {
                heading.setText(R.string.nanoloan_active_loan_heading)
                showCard(view, args)
                note.setText(R.string.nanoloan_active_loan_eligible)
                note.visibility = View.VISIBLE
                primary.setText(R.string.nanoloan_continue)
                primary.setOnClickListener { journeyHost.completeStep() }
                secondary.visibility = View.VISIBLE
                secondary.setText(R.string.cancel)
                secondary.setOnClickListener { close(JourneyStatus.ABANDONED) }
            }
            Kind.EXISTING_LOAN -> {
                heading.setText(R.string.nanoloan_active_loan_heading)
                showCard(view, args)
                note.setText(R.string.nanoloan_active_loan_not_eligible)
                note.visibility = View.VISIBLE
                primary.setText(R.string.nanoloan_close)
                primary.setOnClickListener { close(JourneyStatus.EXISTING_LOAN) }
            }
        }
        if (detail.text.isNullOrEmpty()) detail.visibility = View.GONE
    }

    private fun showCard(view: View, args: Bundle) {
        view.findViewById<View>(R.id.status_card).visibility = View.VISIBLE
        view.findViewById<TextView>(R.id.status_outstanding).text = money(args.getString(ARG_OUTSTANDING))
        val next = args.getString(ARG_NEXT_AMOUNT)
        val due = args.getString(ARG_NEXT_DATE)
        if (next != null || due != null) {
            view.findViewById<View>(R.id.status_next_row).visibility = View.VISIBLE
            view.findViewById<TextView>(R.id.status_next_amount).text = money(next)
            view.findViewById<TextView>(R.id.status_next_due).text = due?.take(10) ?: "-"
        }
    }

    private fun money(amount: String?): String =
        amount?.toBigDecimalOrNull()?.let { NanoLoanMath.formatDouble(it.toDouble()) + " " + getString(R.string.bhd_app_text).trim() } ?: "-"

    /** The Flooss Bahrain app on Google Play (`com.pie.flooss`, the Flooss app's applicationId). */
    private fun openFlooss() {
        // Its own task, so the store does not stack on the host's screens and back returns here.
        fun view(uri: String) = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(view("market://details?id=$FLOOSS_PACKAGE"))
        } catch (e: ActivityNotFoundException) {
            // No Play Store on the device: the web listing opens in the browser instead.
            startActivity(view("https://play.google.com/store/apps/details?id=$FLOOSS_PACKAGE"))
        }
    }

    companion object {
        const val STEP_NAME = "customer_status"
        const val FLOOSS_PACKAGE = "com.pie.flooss"
        private const val ARG_KIND = "kind"
        private const val ARG_OUTSTANDING = "outstanding"
        private const val ARG_NEXT_AMOUNT = "next_amount"
        private const val ARG_NEXT_DATE = "next_date"
        private const val ARG_APPLICATION_ID = "application_id"

        fun forOutcome(kind: Kind): NanoLoanCustomerStatusFragment =
            NanoLoanCustomerStatusFragment().apply { arguments = bundleOf(ARG_KIND to kind.name) }

        fun forScreen(screen: CustomerStatusScreen): NanoLoanCustomerStatusFragment {
            fun BigDecimal?.arg() = this?.toPlainString()
            val args = when (screen) {
                is CustomerStatusScreen.InReview -> bundleOf(
                    ARG_KIND to Kind.APPLICATION_IN_REVIEW.name,
                    ARG_APPLICATION_ID to screen.applicationId?.toString()
                )
                is CustomerStatusScreen.Overdue -> bundleOf(
                    ARG_KIND to Kind.LOAN_OVERDUE.name,
                    ARG_OUTSTANDING to screen.outstandingAmount.arg()
                )
                is CustomerStatusScreen.ActiveLoan -> bundleOf(
                    ARG_KIND to (if (screen.eligible) Kind.ACTIVE_LOAN_ELIGIBLE else Kind.EXISTING_LOAN).name,
                    ARG_OUTSTANDING to screen.outstandingAmount.arg(),
                    ARG_NEXT_AMOUNT to screen.nextInstalmentAmount.arg(),
                    ARG_NEXT_DATE to screen.nextInstalmentDate
                )
            }
            return NanoLoanCustomerStatusFragment().apply { arguments = args }
        }
    }
}
