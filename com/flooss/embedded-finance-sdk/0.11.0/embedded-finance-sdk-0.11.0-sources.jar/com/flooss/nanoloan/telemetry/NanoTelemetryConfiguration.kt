package com.flooss.nanoloan.telemetry

import com.flooss.nanoloan.config.SecretProvider

/**
 * Host opt-in block for the remote telemetry sink (NanoLoan SDK Operations Back-Office).
 *
 * Telemetry is **off unless the host turns it on**: the no-arg default of this class is a
 * fully disabled sink, and [com.flooss.nanoloan.config.NanoLoanConfiguration.telemetry]
 * defaults to it. Nothing is buffered, no thread is started and no socket is opened while
 * [enabled] is false.
 *
 * [apiKey] is a [SecretProvider] for exactly the reason
 * [com.flooss.nanoloan.config.NanoLoanConfiguration.oauthClientSecret] is: the tenant SDK
 * key (`nlk_live_…` / `nlk_test_…`) is a bearer credential. This module never declares one
 * and never persists one; the host resolves it at call time from its own remote config or
 * secure storage.
 */
internal data class NanoTelemetryConfiguration(
    val enabled: Boolean = false,
    /** Base URL of the back-office, e.g. `http://10.0.2.2:3001`. `/v1/ingest` is appended. */
    val endpoint: String = "",
    val apiKey: SecretProvider = SecretProvider { "" },
    val flushIntervalSeconds: Long = 30L,
    /** Contract §2 caps a batch at 500 events; larger values are clamped, not rejected. */
    val maxBatchSize: Int = DEFAULT_MAX_BATCH_SIZE,
    /**
     * Routes the telemetry pipeline's own diagnostics (batch built, POST status, drops)
     * into the SDK logger. Never logs event payloads — only counts and status codes.
     */
    val debugLogging: Boolean = false,
    /**
     * In-memory ring capacity. Beyond this the OLDEST buffered event is dropped and
     * counted (contract §1.5 — lossy-tolerant, never unbounded, never blocking).
     */
    val maxBufferedEvents: Int = DEFAULT_MAX_BUFFERED_EVENTS,
    /**
     * Back-office v2 spec §3.2 — commercial attributes (approved amount, tenor, APR,
     * instalment, pre-approved amount, disbursement method) on the existing lifecycle
     * events. **Off by default**: a partner opts in to sending commercial data, exactly
     * as it opts in to telemetry at all. None of it is PII, and no new event kinds are
     * introduced — only extra attrs on events the SDK already emits.
     */
    val businessMetrics: Boolean = false
) {
    /** Clamped to the contract cap and to a sane floor — a 0-size batch would never flush. */
    val effectiveMaxBatchSize: Int
        get() = maxBatchSize.coerceIn(1, NanoTelemetryContract.MAX_BATCH_SIZE)

    val effectiveFlushIntervalSeconds: Long
        get() = flushIntervalSeconds.coerceIn(1L, 3600L)

    /** Enabled AND actually addressable. A misconfigured block stays silent, it never throws. */
    fun isOperational(): Boolean =
        enabled && endpoint.isNotBlank() && runCatching { apiKey.get() }.getOrNull()?.isNotBlank() == true

    /** `<endpoint>/v1/ingest`, tolerant of a trailing slash on the host-supplied base URL. */
    fun ingestUrl(): String = endpoint.trimEnd('/') + INGEST_PATH

    companion object {
        const val DEFAULT_MAX_BATCH_SIZE = 100
        const val DEFAULT_MAX_BUFFERED_EVENTS = 1000
        const val INGEST_PATH = "/v1/ingest"

        /** Explicit "off" for hosts that prefer to state it. Identical to the default. */
        val disabled = NanoTelemetryConfiguration()
    }
}
