package com.flooss.nanoloan.telemetry

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit
import kotlin.math.min
import kotlin.random.Random

/** Outcome of one POST attempt, classified per contract §2's response table. */
internal sealed class TelemetrySendResult {
    /** 2xx. */
    data class Accepted(val status: Int, val body: String?) : TelemetrySendResult()

    /** 5xx or a transport failure — safe to retry (ingestion is idempotent, §1.4). */
    data class Retryable(val status: Int, val reason: String) : TelemetrySendResult()

    /** 429 — retry, but not before [retryAfterMillis] if the server named one. */
    data class RateLimited(val retryAfterMillis: Long?) : TelemetrySendResult()

    /** 4xx other than 429 — the batch is bad or the key is; retrying cannot help. */
    data class Rejected(val status: Int, val body: String?) : TelemetrySendResult()
}

/** Seam so the batching/retry logic is unit-testable with no socket. */
internal interface NanoTelemetrySender {
    fun send(url: String, apiKey: String, batchId: String, body: String): TelemetrySendResult
}

/**
 * Contract §2 POST. Its own [OkHttpClient] on purpose: telemetry must not share a
 * connection pool, interceptor chain or timeouts with the customer journey's calls, and
 * must never appear in the SDK's own `ApiCallExecuted` stream (which would make the
 * telemetry of the telemetry recurse).
 */
internal class OkHttpTelemetrySender(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .build()
) : NanoTelemetrySender {

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    override fun send(url: String, apiKey: String, batchId: String, body: String): TelemetrySendResult {
        return try {
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Idempotency-Key", batchId)
                .post(body.toRequestBody(jsonMediaType))
                .build()
            client.newCall(request).execute().use { response ->
                val text = runCatching { response.body?.string() }.getOrNull()
                when {
                    response.isSuccessful -> TelemetrySendResult.Accepted(response.code, text)
                    response.code == 429 ->
                        TelemetrySendResult.RateLimited(parseRetryAfter(response.header("Retry-After")))
                    response.code in 500..599 ->
                        TelemetrySendResult.Retryable(response.code, "server error")
                    else -> TelemetrySendResult.Rejected(response.code, text)
                }
            }
        } catch (t: Throwable) {
            // Fire-and-forget: EVERY throwable, not just IOException. A telemetry POST is
            // never allowed to escape into the host's process (contract §1.5).
            TelemetrySendResult.Retryable(-1, t.javaClass.simpleName)
        }
    }

    companion object {
        /** `Retry-After` is seconds (the HTTP-date form is not used by the back-office). */
        internal fun parseRetryAfter(header: String?): Long? =
            header?.trim()?.toLongOrNull()?.takeIf { it >= 0 }?.times(1000L)
    }
}

/**
 * Exponential backoff with full jitter — `random(0, min(base * 2^attempt, cap))`. Full
 * jitter rather than fixed backoff so a back-office restart does not get a synchronised
 * retry stampede from every device that failed against it at the same moment.
 */
internal object NanoTelemetryBackoff {
    const val BASE_DELAY_MS = 1_000L
    const val MAX_DELAY_MS = 60_000L
    const val MAX_ATTEMPTS = 5

    fun delayMillis(attempt: Int, random: Random = Random.Default): Long {
        val bounded = attempt.coerceIn(0, 16)
        val ceiling = min(MAX_DELAY_MS, BASE_DELAY_MS shl bounded)
        return random.nextLong(0, ceiling + 1)
    }

    /**
     * The wait before retry number [attempt]. A server-named `Retry-After` is a FLOOR, not
     * the delay: the jittered backoff is added on top, so a fleet told "1s" by the same
     * 429 does not come back in the same instant and get rate-limited again.
     */
    fun retryDelayMillis(attempt: Int, retryAfterMs: Long?, random: Random = Random.Default): Long =
        (retryAfterMs ?: 0L).coerceAtLeast(0L) + delayMillis(attempt, random)
}
