package com.flooss.nanoloan.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.result.NanoLoanResult
import com.google.android.material.textfield.TextInputEditText

/**
 * Bank-IBAN disbursement entry — REAL screen port of :app
 * `LoanDisbursementBankIBANFragment` + `fragment_disbursement_bank_iban.xml` ("Enter
 * Account IBAN", dots 3/3). Next runs the real two-call chain
 * (§ LoanOfferViewModel.hitGetBankDetails / hitDisbursementMethodIBANOrSTCApi):
 *  1. `GET  api/v1/fo/loans/disbursement/bank-detail/{iban}` — resolve the bank
 *  2. `PUT  api/v1/fo/applications/disburse-detail/{accountNumber}?disbursementMethod=DISBURSEMENT_METHOD_BANK_IBAN`
 * then the acceptance-OTP leg (`sendEmailOtp` + `sendSms`) before the OTP entry, in the
 * real order. The app's AppBankDetailBottomSheet confirm step is folded into the note
 * line (resolved bank name shown inline) — porting that bottom sheet is backlog.
 */
internal class NanoLoanDisbursementIbanFragment : NanoLoanJourneyFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_disbursement_iban, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme

        setUpHeader(
            headerRoot = view.findViewById(R.id.header),
            title = getString(R.string.nanoloan_title_disbursement),
            dotCount = 3,
            dotIndex = 3,
            screenNumber = "8/12",
            stepName = STEP_NAME
        ) {
            confirmIban(view, DEMO_SKIP_IBAN)
        }
        NanoLoanThemeApplier.applyChromeBackground(view.findViewById(R.id.root_layout), theme)

        val bhd = getString(R.string.bhd_app_text)
        val amount = journeyData.offer?.loanAmount?.toInt() ?: journeyData.loanAmount
        view.findViewById<TextView>(R.id.paymentAmountTxt).text = "$amount $bhd"

        val nextBtn = view.findViewById<View>(R.id.next_btn)
        NanoLoanThemeApplier.applyPrimaryButton(nextBtn, theme)
        nextBtn.setOnClickListener {
            val field = view.findViewById<TextInputEditText>(R.id.et_iban)
            val iban = NanoIban.normalize(field.text?.toString().orEmpty())
            if (iban.isEmpty()) {
                field.error = getString(R.string.enter_iban)
                return@setOnClickListener
            }
            if (!NanoIban.passesMod97Check(iban)) {
                field.error = getString(R.string.nanoloan_iban_invalid)
                return@setOnClickListener
            }
            confirmIban(view, iban)
        }
        view.findViewById<View>(R.id.tv_cancel).setOnClickListener {
            journeyHost.navigateBack()
        }
    }

    private fun confirmIban(view: View, iban: String) {
        val progress = view.findViewById<View>(R.id.progress_bar)
        progress.visibility = View.VISIBLE
        NanoLoanSDK.getBankDetailForIban(iban) { detail ->
            if (!isAdded) return@getBankDetailForIban
            when (detail) {
                is NanoLoanResult.Failure -> progress.visibility = View.GONE
                is NanoLoanResult.Success -> {
                    journeyData.disbursementIban = iban
                    journeyData.disbursementBankName = detail.value.bankName
                    view.findViewById<TextView>(R.id.iban_in_24_hr).text =
                        listOfNotNull(detail.value.bankName, getString(R.string.money_disbursed_text))
                            .joinToString(" — ")
                    NanoLoanSDK.setDisbursementMethod(iban, DISBURSEMENT_METHOD_BANK_IBAN) { set ->
                        if (!isAdded) return@setDisbursementMethod
                        when (set) {
                            is NanoLoanResult.Failure -> progress.visibility = View.GONE
                            is NanoLoanResult.Success -> startAcceptanceOtp(view, progress)
                        }
                    }
                }
            }
        }
    }

    private fun startAcceptanceOtp(view: View, progress: View) {
        NanoLoanSDK.requestAcceptanceOtp { result ->
            if (!isAdded) return@requestAcceptanceOtp
            progress.visibility = View.GONE
            if (result is NanoLoanResult.Success) {
                journeyData.maskedOtpPhone = result.value.maskedPhone
                journeyHost.goToOtp()
            }
        }
    }

    companion object {
        const val STEP_NAME = "disbursement_bank_iban"
        // Mod-97-valid, the same canned IBAN the iOS Skip uses.
        private const val DEMO_SKIP_IBAN = "BH57NBOB00001234567890"

        // The app's DisbursementType.DISBURSEMENT_METHOD_BANK_IBAN wire value.
        private const val DISBURSEMENT_METHOD_BANK_IBAN = "BANK_ACCOUNT"
    }
}
