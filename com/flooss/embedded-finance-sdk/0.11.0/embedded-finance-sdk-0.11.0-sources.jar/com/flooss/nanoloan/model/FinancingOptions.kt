package com.flooss.nanoloan.model

/** Where a cash loan may be paid out, as the partner's back-office settings allow. */
enum class DisbursementTarget {
    /** The customer's Flooss wallet / card. */
    WALLET,

    /** A bank account, by IBAN. */
    BANK_IBAN
}

/**
 * The partner's financing settings as the Flooss back office last returned them, read
 * with [com.flooss.nanoloan.NanoLoanSDK.financingOptions]. Read-only: the host uses it to
 * decide which entry points to show. The SDK enforces the same settings itself, so a
 * hidden button is a courtesy, not the control.
 *
 * Amounts are in [currency] major units, as the back office sends them.
 */
data class FinancingOptions(
    /** Settings revision; increases each time the partner's settings change. */
    val version: Int,
    /** Master switch. False while the partner is paused: no journey may start. */
    val journeysEnabled: Boolean,
    val merchantCheckoutEnabled: Boolean,
    val partialFinancing: Boolean,
    val minFinancedAmount: Double?,
    val maxFinancedAmount: Double?,
    val currency: String?,
    val cashLoanEnabled: Boolean,
    val disbursementTargets: List<DisbursementTarget>,
    /** This SDK is older than the partner's minimum; every journey is refused until it is upgraded. */
    val sdkUpgradeRequired: Boolean
) {
    /**
     * Whether [com.flooss.nanoloan.NanoLoanSDK.presentLoanOfferJourney] and the
     * programmatic cash-loan calls will be allowed — the one flag to show the cash-loan
     * button on.
     */
    val canStartCashLoan: Boolean
        get() = journeysEnabled && cashLoanEnabled && !sdkUpgradeRequired && disbursementTargets.isNotEmpty()
}
