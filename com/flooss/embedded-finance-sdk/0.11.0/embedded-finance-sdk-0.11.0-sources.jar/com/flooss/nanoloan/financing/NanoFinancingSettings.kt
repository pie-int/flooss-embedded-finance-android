package com.flooss.nanoloan.financing

import com.flooss.nanoloan.model.DisbursementTarget
import com.flooss.nanoloan.model.FinancingOptions
import com.flooss.nanoloan.result.NanoLoanError
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * The partner's financing settings: fetched at initialize, refreshed before a gated call
 * once the copy is older than [MAX_AGE_MS], persisted as the last good copy.
 *
 * Fail closed. With no settings ever read, every gated journey is refused with
 * [NanoLoanError.JourneyNotEnabled.SETTINGS_UNAVAILABLE]. A failed refresh keeps the last
 * good copy. A 400/401/403 is the back office answering "no" (invalid request, bad key,
 * other environment, stopped tenant), so it drops the cached copy instead of serving it.
 *
 * @param fetcher null when there is nothing to ask with: no partner key, or a key for the
 * other environment. Settings are then unavailable.
 * @param fixed MOCK: these settings, no network, never refreshed.
 */
internal class NanoFinancingSettings(
    private val fetcher: NanoFinancingConfigFetcher?,
    private val store: NanoFinancingConfigStore,
    private val sdkVersion: String,
    private val fixed: NanoFinancingConfig? = null,
    private val clock: () -> Long = System::currentTimeMillis,
    private val io: CoroutineDispatcher = Dispatchers.IO,
    private val log: (String) -> Unit = {}
) {
    private val mutex = Mutex()

    @Volatile private var cached: NanoFinancingConfig? = fixed
    @Volatile private var etag: String? = null
    @Volatile private var fetchedAt: Long = 0L
    @Volatile private var lastFailureAt: Long = Long.MIN_VALUE / 2
    /** The refusal reason of the last 401/403, while no settings are in hand because of it. */
    @Volatile private var refusedReason: String? = null
    @Volatile private var refusedParams: Map<String, String> = emptyMap()

    init {
        if (fixed == null) {
            store.load()?.let { stored ->
                NanoFinancingConfig.parse(stored.json)?.let { config ->
                    cached = config
                    etag = stored.etag
                    fetchedAt = stored.fetchedAtMillis
                }
            }
        }
    }

    /** The settings in hand right now, without a refresh. */
    fun current(): NanoFinancingConfig? = cached

    /** Payout targets the disbursement screen may offer. Empty when no settings are in hand. */
    fun allowedTargets(): List<DisbursementTarget> = cached?.cashLoan?.disbursementTargets.orEmpty()

    /** Fetch now, regardless of age (initialize). */
    suspend fun refresh() = refresh(force = true)

    suspend fun refreshIfStale() = refresh(force = false)

    private suspend fun refresh(force: Boolean) {
        if (fixed != null) return
        val source = fetcher ?: return
        mutex.withLock {
            // A caller that queued behind a refresh finds the copy fresh and stops here.
            if (!force && !needsRefresh()) return
            val result = withContext(io) { source.fetch(etag.takeIf { cached != null }) }
            val now = clock()
            when (result) {
                is FinancingFetchResult.Fetched -> {
                    cached = result.config
                    etag = result.etag
                    fetchedAt = now
                    refusedReason = null
                    refusedParams = emptyMap()
                    store.save(StoredFinancingConfig(result.json, result.etag, now))
                    log("financing settings v${result.config.version} fetched")
                }
                is FinancingFetchResult.NotModified -> {
                    fetchedAt = now
                    refusedReason = null
                    refusedParams = emptyMap()
                    store.load()?.let { store.save(it.copy(fetchedAtMillis = now)) }
                    log("financing settings unchanged (304)")
                }
                is FinancingFetchResult.Refused -> {
                    cached = null
                    etag = null
                    refusedReason = if (result.environmentRefused) NanoLoanError.JourneyNotEnabled.SETTINGS_UNAVAILABLE
                    else NanoLoanError.JourneyNotEnabled.PARTNER_KEY_REJECTED
                    refusedParams = emptyMap()
                    lastFailureAt = now
                    store.clear()
                    log("financing settings refused (HTTP ${result.status}); journeys are closed")
                }
                is FinancingFetchResult.Invalid -> {
                    cached = null
                    etag = null
                    refusedReason = NanoLoanError.JourneyNotEnabled.INVALID_REQUEST
                    refusedParams = result.code?.let { mapOf(NanoLoanError.JourneyNotEnabled.ERROR_PARAM to it) }.orEmpty()
                    lastFailureAt = now
                    store.clear()
                    log("financing settings request invalid (HTTP 400 ${result.code}); journeys are closed")
                }
                is FinancingFetchResult.Failed -> {
                    lastFailureAt = now
                    log(
                        "financing settings refresh failed (${result.reason}); " +
                            if (cached != null) "using the last good copy" else "none cached"
                    )
                }
            }
        }
    }

    private fun needsRefresh(): Boolean {
        val now = clock()
        if (cached == null) return true
        if (now - lastFailureAt < RETRY_AFTER_FAILURE_MS) return false
        return now - fetchedAt >= MAX_AGE_MS
    }

    /** Null when [journey] may run; otherwise the refusal to hand the host. */
    suspend fun gateCashLoan(journey: String): NanoLoanError.JourneyNotEnabled? {
        refreshIfStale()
        val config = cached ?: return NanoLoanError.JourneyNotEnabled(
            journey,
            refusedReason ?: NanoLoanError.JourneyNotEnabled.SETTINGS_UNAVAILABLE,
            reasonParams = refusedParams
        )
        if (config.sdkUpgradeRequired(sdkVersion)) {
            return NanoLoanError.JourneyNotEnabled(journey, NanoLoanError.JourneyNotEnabled.SDK_UPGRADE_REQUIRED)
        }
        if (!config.journeysEnabled || !config.cashLoan.enabled || config.cashLoan.disbursementTargets.isEmpty()) {
            return NanoLoanError.JourneyNotEnabled(journey, NanoLoanError.JourneyNotEnabled.DISABLED_BY_PARTNER_SETTINGS)
        }
        return null
    }

    /** The host-facing read; the refusal when no settings are in hand. */
    suspend fun options(): Pair<FinancingOptions?, NanoLoanError.JourneyNotEnabled?> {
        refreshIfStale()
        val config = cached ?: return null to NanoLoanError.JourneyNotEnabled(
            NanoLoanError.JourneyNotEnabled.FINANCING_OPTIONS,
            refusedReason ?: NanoLoanError.JourneyNotEnabled.SETTINGS_UNAVAILABLE,
            reasonParams = refusedParams
        )
        return config.toOptions(sdkVersion) to null
    }

    companion object {
        const val MAX_AGE_MS = 5 * 60 * 1000L

        /**
         * After a failed fetch, gated calls use the cached copy for this long before trying
         * again, so an outage does not add a network timeout to every call. With nothing
         * cached every gated call tries again: it would be refused otherwise.
         */
        const val RETRY_AFTER_FAILURE_MS = 30 * 1000L
    }
}
