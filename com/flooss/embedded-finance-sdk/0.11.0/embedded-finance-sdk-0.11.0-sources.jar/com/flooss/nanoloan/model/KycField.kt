package com.flooss.nanoloan.model

/**
 * SDK_V3_PRODUCT_GAPS §2.3 — one field in the additional-KYC step, described rather than
 * hardcoded so a host can extend the step without a new SDK build.
 *
 * eKYC gives the SDK identity, not a full customer profile; this step collects what it
 * did not provide. The list lives on
 * [com.flooss.nanoloan.config.NanoLoanConfiguration.kycFields] and the screen is built
 * from it, so adding a field is a configuration change on the host's side.
 *
 * @param key the identifier the value is returned under. Stable — this is what reaches
 *   the host and, as a KEY only, the telemetry.
 * @param label what the customer reads. Supplied by the host so it can be localised on
 *   the host's own terms.
 * @param keyboard which keyboard to present.
 * @param required whether the step's action stays disabled until it is filled.
 */
data class KycField(
    val key: String,
    val label: String,
    val keyboard: KycKeyboard = KycKeyboard.TEXT,
    val required: Boolean = true
)

/** Input type for a [KycField]. Deliberately a small closed set, not a raw InputType int. */
enum class KycKeyboard { TEXT, NUMBER, EMAIL, PHONE }
