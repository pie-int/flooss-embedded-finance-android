package com.flooss.nanoloan.ui

/**
 * ISO 13616 IBAN check — the same rule iOS applies (`passesMod97Check`, a port of the
 * app's `String.passesMod97Check`): alphanumeric, at least four characters, and the
 * rearranged number modulo 97 equals 1.
 */
internal object NanoIban {

    /** Spaces dropped, upper-cased — the form both the check and the backend take. */
    fun normalize(raw: String): String = raw.replace(" ", "").trim().uppercase()

    fun passesMod97Check(iban: String): Boolean {
        if (iban.length < 4) return false
        val upper = iban.uppercase()
        if (!upper.all { it in '0'..'9' || it in 'A'..'Z' }) return false
        val rearranged = upper.substring(4) + upper.substring(0, 4)
        var remainder = 0
        for (character in rearranged) {
            val value = Character.digit(character, 36)
            remainder = if (value < 10) (remainder * 10 + value) % 97 else (remainder * 100 + value) % 97
        }
        return remainder == 1
    }
}
