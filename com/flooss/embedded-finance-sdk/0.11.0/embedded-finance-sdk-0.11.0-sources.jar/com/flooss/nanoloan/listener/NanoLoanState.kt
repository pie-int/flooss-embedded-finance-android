package com.flooss.nanoloan.listener

import com.flooss.nanoloan.model.EligibilityResult
import com.flooss.nanoloan.model.LoanApplicationResult
import com.flooss.nanoloan.model.LoanOffer

/**
 * Coarse-grained journey state, emitted via [NanoLoanListener.onStateUpdate] around every
 * facade call — this is the core loan-origination journey only (design doc scope: F2, F4,
 * F6 subset): eligibility -> application submission -> offer retrieval -> accept/decline.
 */
sealed class NanoLoanState {
    data object Idle : NanoLoanState()
    data object CheckingEligibility : NanoLoanState()
    data class Eligible(val result: EligibilityResult) : NanoLoanState()
    data class Ineligible(val result: EligibilityResult) : NanoLoanState()
    data object VerifyingSalary : NanoLoanState()
    data class SalaryVerified(val method: String) : NanoLoanState()
    data object SubmittingApplication : NanoLoanState()
    data class ApplicationSubmitted(val result: LoanApplicationResult) : NanoLoanState()
    data object LoadingOffer : NanoLoanState()
    data class OfferAvailable(val offer: LoanOffer) : NanoLoanState()
    data object RequestingAcceptanceOtp : NanoLoanState()
    data object AwaitingAcceptanceOtp : NanoLoanState()
    data object VerifyingAcceptanceOtp : NanoLoanState()
    data object AcceptingOffer : NanoLoanState()
    data object OfferAccepted : NanoLoanState()
    data object DecliningOffer : NanoLoanState()
    data object OfferDeclined : NanoLoanState()
    data class Failed(val error: com.flooss.nanoloan.result.NanoLoanError) : NanoLoanState()
}
