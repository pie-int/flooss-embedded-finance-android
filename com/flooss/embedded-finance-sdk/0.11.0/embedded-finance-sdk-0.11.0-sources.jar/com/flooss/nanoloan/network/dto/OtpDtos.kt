package com.flooss.nanoloan.network.dto

/**
 * Wire shapes of the acceptance-OTP chain, field-for-field mirrors of the app's DTOs:
 * - `POST api/v1/security/verifyEmail/sendEmailOtp` (`WebServiceConstants.EMAIL_VERIFICATION`,
 *   `LoanApi.verifyEmail`) -> req `EmailVerificationRequest(email)`,
 *   res `EmailVerificationResponse(verificationUUID)`
 * - `POST api/v1/security/verifyPhone/sendSms` (`WebServiceConstants.SEND_SALAF_SMS`,
 *   `LoanApi.sendSms`) -> req `PhoneVerificationRequest(phone)`,
 *   res `VerificationActionData(verificationUUID)`
 */
data class EmailVerificationRequestDto(val email: String)

data class EmailVerificationResponseDto(val verificationUUID: String?)

data class PhoneVerificationRequestDto(val phone: String? = null)

data class VerificationActionDataDto(val verificationUUID: String? = null)
