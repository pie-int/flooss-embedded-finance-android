package com.flooss.nanoloan.repo

import com.flooss.nanoloan.logging.NanoLoanLogger
import com.flooss.nanoloan.model.AcceptanceOtpSession
import com.flooss.nanoloan.model.ActiveLoanInfo
import com.flooss.nanoloan.model.BankLinkResult
import com.flooss.nanoloan.model.BankProvider
import com.flooss.nanoloan.model.EligibilityResult
import com.flooss.nanoloan.model.LoanApplicationRequest
import com.flooss.nanoloan.model.LoanApplicationResult
import com.flooss.nanoloan.model.LoanOffer
import com.flooss.nanoloan.model.LoanProductInfo
import com.flooss.nanoloan.model.LoanStatus
import com.flooss.nanoloan.model.OfferInstallmentsPreview
import com.flooss.nanoloan.model.PeriodType
import com.flooss.nanoloan.network.NanoLoanApi
import com.flooss.nanoloan.network.dto.AcceptOfferRequestDto
import com.flooss.nanoloan.network.dto.CreateLoanRequestDto
import com.flooss.nanoloan.network.dto.DeclineOfferRequestDto
import com.flooss.nanoloan.model.NanoLoanToken
import com.flooss.nanoloan.network.dto.EmailVerificationRequestDto
import com.flooss.nanoloan.network.dto.EmploymentDetailRequestDto
import com.flooss.nanoloan.network.dto.LoanEmploymentDto
import com.flooss.nanoloan.network.dto.LoanResponseDto
import com.flooss.nanoloan.network.dto.PhoneVerificationRequestDto
import com.flooss.nanoloan.network.dto.TarabutTokenRequestDto
import com.flooss.nanoloan.result.NanoLoanError
import com.flooss.nanoloan.result.NanoLoanResult
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Response
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * REAL data source — hits [NanoLoanApi] over the network built from
 * [com.flooss.nanoloan.config.NanoLoanConfiguration.loanBaseUrl]. Error-body parsing
 * mirrors the app's `data/network/SafeApiRequest.kt#apiRequest` logic field-for-field
 * (`message`/`title`/`errorClassification`/`enableFeedback`/`enableTryAgain`/`txnId`/
 * `errorCode`) and the two special-cased error codes it branches on
 * (`AppConstants.USER_BLOCKED_CODE` = 30002, `AppConstants.SHOW_CAPTCHA` = 31012,
 * `AppConstants.USER_BLOCKED_SCREENA_REJECTION` = 90040) — ported here so the SDK's
 * `NanoLoanError` mapping matches the real backend's error contract, not a guess.
 */
internal class RealNanoLoanDataSource(
    private val api: NanoLoanApi,
    private val logger: NanoLoanLogger
) : NanoLoanDataSource {

    override suspend fun login(
        cpr: String,
        pin: String,
        clientId: String,
        clientSecret: String,
        scope: String
    ): NanoLoanResult<NanoLoanToken> =
        // Faithful port of the app's Salaf grant (SalafAuthTokenApi.hitSalafLoginApi as
        // called by AuthRepo.hitSalafLoginApi / AuthInterceptor's Salaf branch):
        // password travels PLAIN in the form body (no AesUtil.encrypt on this grant),
        // device_token is the FCM token in the app (the SDK has no FCM — empty, which
        // the app itself also sends when the token isn't resolved yet), address = "".
        safeCall("login") {
            api.login(
                grantType = "password",
                username = cpr,
                password = pin,
                clientId = clientId,
                clientSecret = clientSecret,
                scope = scope,
                deviceToken = "",
                deviceType = "ANDROID",
                address = ""
            )
        }.map { dto ->
            NanoLoanToken(
                accessToken = dto.accessToken.orEmpty(),
                refreshToken = dto.refreshToken,
                expiresIn = dto.expiresIn ?: 3600
            )
        }

    override suspend fun saveEmploymentDetails(
        bearerToken: String,
        details: com.flooss.nanoloan.model.EmploymentDetails
    ): NanoLoanResult<Unit> =
        safeCall("saveEmploymentDetails") {
            api.saveEmploymentDetails(
                bearerToken,
                EmploymentDetailRequestDto(
                    employerName = details.companyName,
                    occupation = details.jobTitle,
                    educationLevel = details.educationLevelId,
                    workExperience = details.workExperienceId,
                    yearsInCurrentJob = details.yearsInCurrentJobId
                )
            )
        }.map { }

    override suspend fun getEmploymentOptions(
        bearerToken: String
    ): NanoLoanResult<com.flooss.nanoloan.model.EmploymentOptions> {
        fun list(type: String): suspend () -> NanoLoanResult<List<com.flooss.nanoloan.model.EmploymentOption>> = {
            safeCall("getProfileAttributes:$type") { api.getProfileAttributes(bearerToken, type) }.map { dto ->
                dto.target.orEmpty()
                    .filter { it.active != false && it.id != null && !it.description.isNullOrBlank() }
                    .map { com.flooss.nanoloan.model.EmploymentOption(it.id!!, it.description!!) }
            }
        }
        val education = list("EducationLevel")()
        if (education is NanoLoanResult.Failure) return education
        val experience = list("WorkExperience")()
        if (experience is NanoLoanResult.Failure) return experience
        val years = list("YearsInCurrentJob")()
        if (years is NanoLoanResult.Failure) return years
        // Suggestions only: the field stays free text, so a failed list is not a failed step.
        val employers = (safeCall("getPrivateCompanies") { api.getPrivateCompanies(bearerToken) } as? NanoLoanResult.Success)
            ?.value?.privateCompanies.orEmpty().mapNotNull { it.employerName?.trim()?.ifBlank { null } }.distinct()
        return NanoLoanResult.Success(
            com.flooss.nanoloan.model.EmploymentOptions(
                educationLevels = (education as NanoLoanResult.Success).value,
                workExperience = (experience as NanoLoanResult.Success).value,
                yearsInCurrentJob = (years as NanoLoanResult.Success).value,
                employers = employers
            )
        )
    }

    override suspend fun getBankDetailForIban(
        bearerToken: String,
        iban: String
    ): NanoLoanResult<com.flooss.nanoloan.model.BankIbanDetail> =
        safeCall("getBankDetailForIban") { api.getBankDetailForIban(bearerToken, iban) }.map { dto ->
            com.flooss.nanoloan.model.BankIbanDetail(
                bankName = dto.name,
                bic = dto.bic,
                iban = dto.iban ?: iban
            )
        }

    override suspend fun setDisbursementMethod(
        bearerToken: String,
        accountNumber: String,
        disbursementMethod: String
    ): NanoLoanResult<Unit> =
        safeCall("setDisbursementMethod") {
            api.setDisbursementMethod(bearerToken, accountNumber, disbursementMethod)
        }.map { }

    override suspend fun checkEligibility(bearerToken: String, cpr: String): NanoLoanResult<EligibilityResult> =
        // `cpr` is not sent on the wire — the real endpoint identifies the caller from
        // the bearer token (see NanoLoanSDK.checkLoanEligibility doc).
        safeCall("checkEligibility") { api.checkEligibility(bearerToken) }.map {
            EligibilityResult(
                restricted = it.restricted,
                restrictedReason = it.restrictedReason,
                remainingDays = it.remainingDays,
                remainingHours = it.remainingHours,
                remainingMinutes = it.remainingMinutes,
                restrictedUntil = it.restrictedUntil
            )
        }

    override suspend fun getProducts(bearerToken: String): NanoLoanResult<LoanProductInfo> =
        safeCall("getProducts") { api.getProducts(bearerToken) }.map { dto ->
            val product = dto.products?.shariyah
            LoanProductInfo(
                id = product?.id ?: 0L,
                guid = product?.guid,
                displayName = product?.displayName,
                minLoanAmount = product?.minLoanAmount,
                maxLoanAmount = product?.maxLoanAmount,
                minLoanPeriod = product?.minLoanPeriod,
                maxLoanPeriod = product?.maxLoanPeriod,
                periodType = product?.periodType
            )
        }

    override suspend fun getActiveLoan(bearerToken: String): NanoLoanResult<ActiveLoanInfo> =
        safeCall("getActiveLoan") { api.getActiveLoan(bearerToken) }.map { dto ->
            ActiveLoanInfo(
                hasActiveLoan = dto.id != null,
                loanId = dto.id,
                status = dto.status?.let { parseStatus(it) },
                outstandingBalance = dto.outstandingBalance,
                nextInstalmentAmount = dto.comingPaymentDetails?.amount ?: dto.installmentAmount,
                nextInstalmentDate = dto.comingPaymentDetails?.dueDate
            )
        }

    override suspend fun getBankProviders(bearerToken: String): NanoLoanResult<List<BankProvider>> =
        safeCall("getBankProviders") { api.getTarabutProviders(bearerToken) }.map { dto ->
            dto.data.map {
                BankProvider(
                    providerId = it.providerId,
                    name = it.name,
                    displayName = it.displayName,
                    logoUrl = it.logoUrl,
                    countryCode = it.countryCode,
                    status = it.status
                )
            }
        }

    override suspend fun linkBankAccount(bearerToken: String, providerId: String): NanoLoanResult<BankLinkResult> {
        val intent = safeCall("createTarabutIntent") {
            api.createTarabutIntent(bearerToken, TarabutTokenRequestDto(providerId = providerId))
        }
        val intentId = when (intent) {
            is NanoLoanResult.Failure -> return NanoLoanResult.Failure(intent.error)
            is NanoLoanResult.Success -> intent.value.data?.intentId.orEmpty()
        }
        // NOTE: the real journey opens TarabutTokenResponse.data.connectUrl in a web
        // flow where the customer authorizes the bank connection before the app calls
        // accounts/sync. The SDK does not embed that web flow yet (see backlog).
        return safeCall("tarabutSync") { api.tarabutSync(bearerToken) }.map {
            BankLinkResult(intentId = intentId, synced = it.status, message = it.message)
        }
    }

    override suspend fun uploadSalaryDocuments(
        bearerToken: String,
        documents: List<com.flooss.nanoloan.model.SalaryDocument>
    ): NanoLoanResult<List<com.flooss.nanoloan.model.UploadedDocument>> {
        val parts = documents.take(3).mapIndexed { index, doc ->
            MultipartBody.Part.createFormData(
                "file${index + 1}", doc.fileName, doc.bytes.toRequestBody(doc.mimeType.toMediaType())
            )
        }
        return safeCall("uploadSalaryDocuments") {
            api.uploadSalaryDocuments(bearerToken, "EMPLOYMENT_BANK_STATEMENT", parts)
        }.map { dto ->
            dto.data.mapNotNull { d -> d.id?.let { com.flooss.nanoloan.model.UploadedDocument(it, d.displayName) } }
        }
    }

    override suspend fun getCustomerProfile(
        bearerToken: String
    ): NanoLoanResult<com.flooss.nanoloan.model.CustomerProfile> =
        safeCall("getCustomerProfile") { api.getClientProfile(bearerToken) }.map { dto ->
            com.flooss.nanoloan.model.CustomerProfile(
                fullName = dto.personalDetails?.name?.trim()?.ifBlank { null },
                monthlySalary = dto.employmentDetails?.monthlySalary,
                employerName = dto.employmentDetails?.employerName,
                occupation = dto.employmentDetails?.occupation
            )
        }

    override suspend fun submitLoanApplication(
        bearerToken: String,
        request: LoanApplicationRequest,
        floossToken: String?
    ): NanoLoanResult<LoanApplicationResult> {
        val dto = CreateLoanRequestDto(
            employment = LoanEmploymentDto(
                employmentType = request.employment.employmentType.name,
                employerName = request.employment.employerName,
                occupation = request.employment.occupation,
                monthlySalary = request.employment.monthlySalary,
                workStartDate = request.employment.workStartDate,
                // Positional ids with the stored guid, as the app's ReferenceId(index, item.id).
                bankStatement = request.employment.bankStatements.mapIndexed { index, doc ->
                    com.flooss.nanoloan.network.dto.ReferenceIdDto(index.toLong(), doc.guid)
                }
            ),
            loanAmount = request.loanAmount,
            loanPeriod = request.loanPeriod,
            loanPeriodType = request.loanPeriodType.name,
            productId = request.productId,
            loanPurposeId = request.loanPurposeId,
            loanName = request.loanName,
            selectedRepaymentDate = request.selectedRepaymentDate,
            floossToken = floossToken
        )
        return safeCall("submitLoanApplication") { api.createLoan(bearerToken, dto) }.map { toApplicationResult(it) }
    }

    private var walletPem: String? = null

    private suspend fun encryptForWallet(device: WalletDevice, value: String): NanoLoanResult<String> {
        val pem = walletPem ?: when (val key = safeCall("walletPublicKey") { api.walletPublicKey(device.baseUrl + "api/v1/public/rsa-public-key") }) {
            is NanoLoanResult.Success -> key.value.data
                ?.let { String(android.util.Base64.decode(it, android.util.Base64.DEFAULT), Charsets.UTF_8) }
                ?.also { walletPem = it }
                ?: return NanoLoanResult.Failure(com.flooss.nanoloan.result.NanoLoanError.Unknown("Wallet key unavailable"))
            is NanoLoanResult.Failure -> return key
        }
        return NanoLoanResult.Success(com.flooss.nanoloan.network.NanoWalletCrypto.encrypt(pem, value))
    }

    private suspend fun walletPasswordGrant(device: WalletDevice, mobileNumber: String, pin: String): NanoLoanResult<WalletSignIn.Signed> {
        val encrypted = when (val e = encryptForWallet(device, pin)) {
            is NanoLoanResult.Success -> e.value
            is NanoLoanResult.Failure -> return e
        }
        return safeCall("walletToken") {
            api.walletToken(device.baseUrl + "oauth/token", WALLET_CLIENT, "password", mobileNumber, encrypted, device.udid, device.make, device.model)
        }.map { WalletSignIn.Signed(it.access_token.orEmpty(), it.expires_in ?: 0L, it.customerId) }
    }

    override suspend fun walletCustomerCpr(device: WalletDevice, walletToken: String): NanoLoanResult<String?> =
        safeCall("walletCustomerInfo") {
            api.walletCustomerInfo(device.baseUrl + "api/v1/customer/info", "Bearer $walletToken", device.udid)
        }.map { dto ->
            dto.data?.identifications.orEmpty()
                .firstOrNull { it.identificationType.equals("CPR", ignoreCase = true) }
                ?.identificationValue?.trim()?.ifBlank { null }
        }

    override suspend fun walletSignIn(device: WalletDevice, mobileNumber: String, pin: String): NanoLoanResult<WalletSignIn> {
        val encrypted = when (val e = encryptForWallet(device, pin)) {
            is NanoLoanResult.Success -> e.value
            is NanoLoanResult.Failure -> return e
        }
        val r = safeCall("walletValidate") {
            api.walletValidate(
                device.baseUrl + "api/v1/customer/validate",
                WALLET_CLIENT,
                com.flooss.nanoloan.network.dto.WalletValidateRequestDto(mobileNumber, encrypted, device.udid)
            )
        }
        val check = when (r) {
            is NanoLoanResult.Success -> r.value.data
            is NanoLoanResult.Failure -> return r
        }
        if (check?.valid != true) return NanoLoanResult.Success(WalletSignIn.WrongPin(check?.failedCount ?: 0))
        // Not trusted: the wallet already sent an SMS code for this actionUuid.
        if (check.trustedDevice != true && !check.actionUuid.isNullOrBlank()) {
            return NanoLoanResult.Success(WalletSignIn.OtpRequired(check.actionUuid, check.phoneNumber ?: mobileNumber))
        }
        return walletPasswordGrant(device, mobileNumber, pin)
    }

    override suspend fun walletVerifyDevice(
        device: WalletDevice,
        actionUuid: String,
        otp: String,
        mobileNumber: String,
        pin: String
    ): NanoLoanResult<WalletSignIn.Signed> {
        val encryptedOtp = when (val e = encryptForWallet(device, otp)) {
            is NanoLoanResult.Success -> e.value
            is NanoLoanResult.Failure -> return e
        }
        // udid + origin make the wallet link this device to the customer as trusted.
        val verified = safeCall("walletVerifyOtp") {
            api.walletVerifyOtp(
                device.baseUrl + "api/v1/system/verify-otp",
                WALLET_CLIENT,
                device.udid,
                "ANDROID",
                com.flooss.nanoloan.network.dto.WalletVerifyOtpRequestDto(actionUuid, encryptedOtp, mobileNumber)
            )
        }
        if (verified is NanoLoanResult.Failure) return verified
        return walletPasswordGrant(device, mobileNumber, pin)
    }

    override suspend fun getActiveOffer(bearerToken: String): NanoLoanResult<LoanOffer> =
        safeCall("getActiveOffer") { api.getActiveOffer(bearerToken) }.map { toOffer(it) }

    override suspend fun getOfferInstallments(bearerToken: String): NanoLoanResult<OfferInstallmentsPreview> =
        safeCall("getOfferInstallments") { api.getOfferInstallments(bearerToken) }.map { dto ->
            val first = dto.pending.firstOrNull()
            OfferInstallmentsPreview(
                pendingCount = dto.pending.size,
                firstDueDate = first?.installmentDueDate,
                installmentAmount = first?.totalInstallmentAmount
            )
        }

    override suspend fun getLoanAgreement(bearerToken: String, loanAppId: Long): NanoLoanResult<Unit> =
        safeCall("getLoanAgreement") { api.getLoanAgreement(bearerToken, loanAppId) }.map { }

    override suspend fun requestAcceptanceOtp(bearerToken: String): NanoLoanResult<AcceptanceOtpSession> {
        val email = safeCall("sendEmailOtp") {
            // The real call carries the customer's registered email from the profile;
            // profile APIs are not part of this SDK slice yet.
            api.sendEmailOtp(bearerToken, EmailVerificationRequestDto(email = ""))
        }
        val emailUuid = when (email) {
            is NanoLoanResult.Failure -> return NanoLoanResult.Failure(email.error)
            is NanoLoanResult.Success -> email.value.verificationUUID
        }
        return safeCall("sendSms") { api.sendSms(PhoneVerificationRequestDto()) }.map {
            AcceptanceOtpSession(
                emailVerificationUUID = emailUuid,
                phoneVerificationUUID = it.verificationUUID,
                maskedPhone = null
            )
        }
    }

    override suspend fun acceptOffer(
        bearerToken: String,
        applicationId: Long,
        offerGuid: String
    ): NanoLoanResult<Unit> {
        val dto = AcceptOfferRequestDto(
            id = applicationId,
            offerGuid = offerGuid,
            termsAndConditionsAccepted = true,
            acceptedAt = isoNow()
        )
        return safeCall("acceptOffer") {
            api.acceptOfferNormal(bearerToken, applicationId, offerGuid, dto)
        }.map { }
    }

    override suspend fun verifyAcceptanceOtp(
        bearerToken: String,
        applicationId: Long,
        offerGuid: String,
        otp: String,
        phoneVerificationUUID: String?
    ): NanoLoanResult<Unit> {
        val dto = AcceptOfferRequestDto(
            id = applicationId,
            offerGuid = offerGuid,
            termsAndConditionsAccepted = true,
            acceptedAt = isoNow(),
            phoneVerificationActionUUID = phoneVerificationUUID,
            phoneVerificationCode = otp
        )
        return safeCall("verifyAcceptanceOtp") {
            api.verifyAcceptOtp(bearerToken, applicationId, offerGuid, dto)
        }.map { }
    }

    override suspend fun declineOffer(
        bearerToken: String,
        applicationId: Long,
        offerGuid: String,
        reason: String?
    ): NanoLoanResult<Unit> {
        val dto = DeclineOfferRequestDto(reason = reason, rejectedAt = isoNow())
        return safeCall("declineOffer") {
            api.declineOffer(bearerToken, applicationId, offerGuid, dto)
        }.map { }
    }

    private fun toApplicationResult(dto: LoanResponseDto) = LoanApplicationResult(
        id = dto.id ?: 0L,
        guid = dto.guid,
        status = parseStatus(dto.status),
        loanAmount = dto.loanAmount,
        period = dto.period,
        periodType = parsePeriodType(dto.periodType),
        anyActiveOfferExists = dto.anyActiveOfferExists
    )

    private fun toOffer(dto: LoanResponseDto) = LoanOffer(
        id = dto.id ?: 0L,
        offerGuid = dto.guid ?: "",
        status = parseStatus(dto.status),
        productName = dto.product?.name,
        loanAmount = dto.loanAmount,
        principalAmount = dto.principalAmount,
        installmentAmount = dto.installmentAmount,
        totalAmount = dto.totalAmount,
        interestRate = dto.interestRate,
        period = dto.period,
        periodType = parsePeriodType(dto.periodType),
        offerExpiryDate = dto.offerExpiryDate
    )

    private fun parseStatus(raw: String?): LoanStatus =
        raw?.let { runCatching { LoanStatus.valueOf(it) }.getOrNull() } ?: LoanStatus.UNKNOWN

    private fun parsePeriodType(raw: String?): PeriodType? =
        raw?.let { runCatching { PeriodType.valueOf(it) }.getOrNull() }

    private fun isoNow(): String {
        val format = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        format.timeZone = TimeZone.getTimeZone("UTC")
        return format.format(Date())
    }

    private suspend fun <T> safeCall(
        endpoint: String,
        call: suspend () -> Response<T>
    ): NanoLoanResult<T> {
        return try {
            val response = call.invoke()
            val body = response.body()
            if (response.isSuccessful && body != null) {
                NanoLoanResult.Success(body)
            } else {
                NanoLoanResult.Failure(parseErrorBody(endpoint, response))
            }
        } catch (e: IOException) {
            logger.e("NanoLoanRealDataSource", "$endpoint: no internet / IO failure", e)
            NanoLoanResult.Failure(NanoLoanError.NoInternet(message = e.message ?: "No internet connection"))
        } catch (e: Exception) {
            logger.e("NanoLoanRealDataSource", "$endpoint: unexpected failure", e)
            NanoLoanResult.Failure(NanoLoanError.Unknown(message = e.message ?: "Unknown error"))
        }
    }

    private fun parseErrorBody(endpoint: String, response: Response<*>): NanoLoanError {
        val errorBody = response.errorBody()?.string()
        var message = ""
        var title = ""
        var errorClassification = ""
        var enableFeedback = false
        var enableTryAgain = true
        var txnId = ""
        var errorCode = 0

        errorBody?.let { raw ->
            try {
                val json = JSONObject(raw)
                message = json.optString("message", "")
                title = json.optString("title", "")
                errorClassification = json.optString("errorClassification", "")
                enableFeedback = json.optString("enableFeedback", "false").equals("true", true)
                enableTryAgain = json.optString("enableTryAgain", "true").equals("true", true)
                txnId = json.optString("txnId", "")
                errorCode = try {
                    json.getInt("errorCode")
                } catch (e: JSONException) {
                    0
                }
            } catch (e: JSONException) {
                // Not JSON, or a shape SafeApiRequest.kt's own try/catch also swallows.
            }
        }

        if (message.isBlank()) {
            message = errorBody?.let {
                try {
                    val json = JSONObject(it)
                    json.optString("detail").ifEmpty { json.optString("title") }
                } catch (e: JSONException) {
                    null
                }
            }.orEmpty()
        }
        if (message.isBlank()) {
            message = "Something went wrong, please try again later."
        }

        logger.w("NanoLoanRealDataSource", "$endpoint failed: httpCode=${response.code()} errorCode=$errorCode title=$title")

        // 401/403 = expired/invalid bearer — surfaced typed so NanoLoanRepository can run
        // its single re-auth-with-held-credentials retry (AuthInterceptor's 401 branch,
        // relocated out of the interceptor into the repository for the SDK).
        if (response.code() == 401 || response.code() == 403) {
            return NanoLoanError.NotAuthenticated(
                message = message.ifBlank { "Session expired (HTTP ${response.code()})" }
            )
        }

        return when (errorCode) {
            USER_BLOCKED_CODE, USER_BLOCKED_SCREENA_REJECTION ->
                NanoLoanError.UserBlocked(message = message, errorCode = errorCode, txnId = txnId)
            SHOW_CAPTCHA ->
                NanoLoanError.Captcha(message = message, errorCode = errorCode, txnId = txnId)
            else -> NanoLoanError.Api(
                message = message,
                errorCode = errorCode,
                txnId = txnId,
                enableFeedback = enableFeedback,
                enableTryAgain = enableTryAgain
            )
        }
    }

    private companion object {
        // The wallet app's public OAuth client (BasicAuthUtil: "flooss:flooss").
        private val WALLET_CLIENT =
            "Basic " + android.util.Base64.encodeToString("flooss:flooss".toByteArray(), android.util.Base64.NO_WRAP)

        // Ported from app/constants/AppConstants.kt — real error-code values the
        // backend uses, not invented ones.
        const val USER_BLOCKED_CODE = 30002
        const val USER_BLOCKED_SCREENA_REJECTION = 90040
        const val SHOW_CAPTCHA = 31012
    }
}

private inline fun <T, R> NanoLoanResult<T>.map(transform: (T) -> R): NanoLoanResult<R> = when (this) {
    is NanoLoanResult.Success -> NanoLoanResult.Success(transform(value))
    is NanoLoanResult.Failure -> NanoLoanResult.Failure(error)
}
