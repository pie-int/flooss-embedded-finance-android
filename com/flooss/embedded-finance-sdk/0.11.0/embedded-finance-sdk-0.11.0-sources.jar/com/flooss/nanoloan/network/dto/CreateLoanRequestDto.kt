package com.flooss.nanoloan.network.dto

import java.math.BigDecimal

/**
 * Wire shape of the body `POST api/v1/fo/loans` expects — a trimmed mirror of the app's
 * `CreateLoanReq`/`LoanEmployment` (`data/model/api/request/CreateLoanReq.kt`), same
 * field names for the subset this POC sends.
 */
data class CreateLoanRequestDto(
    val employment: LoanEmploymentDto,
    val loanAmount: BigDecimal,
    val loanPeriod: Long,
    val loanPeriodType: String,
    val productId: Long?,
    val loanPurposeId: Long?,
    val loanName: String? = null,
    val selectedRepaymentDate: Int? = null,
    /** The customer's wallet access token; the backend refreshes eKYC with it (else 503/10006). */
    val floossToken: String? = null
)

/**
 * The front-office `LoanEmploymentRequest`. For an employed customer the backend's
 * `@Employment` rule requires employer, occupation, salary, `workStartDate` (yyyy-MM-dd)
 * and at least one document reference (bank statement, payslip or salary certificate).
 */
data class LoanEmploymentDto(
    val employmentType: String,
    val employerName: String?,
    val occupation: String?,
    val monthlySalary: BigDecimal,
    val workStartDate: String? = null,
    val bankStatement: List<ReferenceIdDto> = emptyList()
)

/** `{id, guid}` reference to an uploaded document, as the app's `ReferenceId`. */
data class ReferenceIdDto(val id: Long?, val guid: String?)
