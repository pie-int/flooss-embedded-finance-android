package com.flooss.nanoloan.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.model.JourneyStatus

/**
 * financing_split step: the amount asked for, the part Flooss finances and the remainder
 * the customer pays themselves. The split is worked out before this screen shows; the
 * customer confirms it or leaves.
 */
internal class NanoLoanFinancingSplitFragment : NanoLoanJourneyFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_financing_split, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme
        setUpHeader(
            headerRoot = view.findViewById(R.id.header),
            title = getString(R.string.nanoloan_split_title),
            dotCount = 1,
            dotIndex = 1,
            screenNumber = "",
            stepName = STEP_NAME
        ) { journeyHost.completeStep() }
        NanoLoanThemeApplier.applyChromeBackground(view, theme)

        val context = NanoLoanSDK.activeJourneyBridge()?.context
        val split = context?.split ?: run {
            journeyHost.completeStep()
            return
        }
        val currency = context.plan.currency
        fun money(amount: java.math.BigDecimal) = NanoLoanMath.formatDouble(amount.toDouble()) + " " + currency
        view.findViewById<TextView>(R.id.split_requested).text =
            getString(R.string.nanoloan_split_requested, money(split.requested))
        view.findViewById<TextView>(R.id.split_financed).text =
            getString(R.string.nanoloan_split_financed, money(split.financed))
        view.findViewById<TextView>(R.id.split_remainder).text =
            getString(R.string.nanoloan_split_remainder, money(split.remainder))

        val confirm = view.findViewById<View>(R.id.split_confirm_btn)
        NanoLoanThemeApplier.applyPrimaryButton(confirm, theme)
        confirm.setOnClickListener { journeyHost.completeStep() }
        view.findViewById<View>(R.id.split_cancel).setOnClickListener {
            journeyHost.finishJourney(JourneyStatus.ABANDONED)
        }
    }

    companion object {
        const val STEP_NAME = "financing_split"
    }
}
