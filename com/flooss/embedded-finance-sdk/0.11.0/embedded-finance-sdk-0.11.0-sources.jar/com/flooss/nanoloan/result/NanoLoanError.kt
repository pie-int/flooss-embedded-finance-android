package com.flooss.nanoloan.result

/**
 * Target `NanoLoanError` shape (design doc §9.1, §11) — a near-direct wrap of the app's
 * existing `exceptions/Exceptions.kt` hierarchy (`BaseClass`/`ApiException`/
 * `NoInternetException`/`UserBlockedException`/`CaptchaException`/`WrongPinOtpException`),
 * re-declared here rather than depended on so this module never depends on `:app`.
 * Every case carries the same fields the as-is hierarchy carries: [errorCode], [txnId],
 * [enableFeedback] (show a feedback affordance), [enableTryAgain] (show a retry action).
 */
sealed class NanoLoanError(
    open val message: String,
    open val errorCode: Int = 0,
    open val txnId: String = "",
    open val enableFeedback: Boolean = false,
    open val enableTryAgain: Boolean = true
) {
    data class Api(
        override val message: String,
        override val errorCode: Int = 0,
        override val txnId: String = "",
        override val enableFeedback: Boolean = false,
        override val enableTryAgain: Boolean = true
    ) : NanoLoanError(message, errorCode, txnId, enableFeedback, enableTryAgain)

    data class NoInternet(
        override val message: String = "No internet connection",
        override val errorCode: Int = 0,
        override val txnId: String = ""
    ) : NanoLoanError(message, errorCode, txnId, enableFeedback = false, enableTryAgain = true)

    data class UserBlocked(
        override val message: String,
        override val errorCode: Int = 0,
        override val txnId: String = ""
    ) : NanoLoanError(message, errorCode, txnId, enableFeedback = true, enableTryAgain = false)

    data class Captcha(
        override val message: String,
        override val errorCode: Int = 0,
        override val txnId: String = ""
    ) : NanoLoanError(message, errorCode, txnId, enableFeedback = false, enableTryAgain = true)

    data class WrongPinOtp(
        override val message: String,
        override val errorCode: Int = 0,
        override val txnId: String = ""
    ) : NanoLoanError(message, errorCode, txnId, enableFeedback = false, enableTryAgain = true)

    /** Not authenticated yet — [com.flooss.nanoloan.NanoLoanSDK.authenticate] was never called or its token expired. */
    /**
     * This device is new to the customer's Flooss wallet: Flooss sent an SMS code to
     * [maskedPhone]. Pass it to `NanoLoanSDK.verifyDevice(otp)` to finish sign-in; the
     * device is trusted from then on.
     */
    data class DeviceVerificationRequired(
        val maskedPhone: String,
        override val message: String = "Enter the code Flooss sent by SMS to verify this device"
    ) : NanoLoanError(message, enableFeedback = false, enableTryAgain = true)

    data class NotAuthenticated(
        override val message: String = "No active NanoLoan session — call authenticate() first"
    ) : NanoLoanError(message, enableFeedback = false, enableTryAgain = false)

    /**
     * Flooss does not allow [journey] right now. [reason] is one of the constants on the
     * companion, or a newer reason a later back office sends:
     *
     * - [DISABLED_BY_PARTNER_SETTINGS] / [JOURNEYS_DISABLED] / [MODE_DISABLED]: the
     *   partner's settings have the journey off (or the partner is paused).
     * - [AMOUNT_REQUIRED]: a merchant checkout needs an amount.
     * - [AMOUNT_BELOW_MIN] / [AMOUNT_ABOVE_MAX]: the amount is outside the partner's
     *   limits ([reasonParams] carries `min` or `max`).
     * - [JOURNEY_DENIED]: a refusal this SDK does not know (`reasonParams["code"]` names it).
     * - [SDK_UPGRADE_REQUIRED]: this SDK is older than the partner's minimum, or does not
     *   implement steps the journey needs ([missingCapabilities] names them).
     * - [SETTINGS_UNAVAILABLE]: Flooss could not be asked and nothing was cached, or the
     *   configured environment is not enabled for this key.
     * - [PARTNER_KEY_REJECTED]: the back office refused the partner key.
     * - [INVALID_REQUEST]: the request was refused as invalid (a currency other than BHD,
     *   a PII-shaped `orderRef`, an unknown environment); `reasonParams["error"]` carries
     *   the back office's error code. Not retryable: fix the request.
     *
     * The SDK fails closed: no answer from Flooss, no journey.
     */
    data class JourneyNotEnabled(
        val journey: String,
        val reason: String,
        val missingCapabilities: List<String> = emptyList(),
        val reasonParams: Map<String, String> = emptyMap(),
        override val message: String = "The $journey journey is not enabled ($reason)"
    ) : NanoLoanError(message, enableFeedback = false, enableTryAgain = reason == SETTINGS_UNAVAILABLE) {
        companion object {
            const val DISABLED_BY_PARTNER_SETTINGS = "DISABLED_BY_PARTNER_SETTINGS"
            const val JOURNEYS_DISABLED = "JOURNEYS_DISABLED"
            const val MODE_DISABLED = "MODE_DISABLED"
            const val AMOUNT_REQUIRED = "AMOUNT_REQUIRED"
            const val AMOUNT_BELOW_MIN = "AMOUNT_BELOW_MIN"
            const val AMOUNT_ABOVE_MAX = "AMOUNT_ABOVE_MAX"
            const val JOURNEY_DENIED = "JOURNEY_DENIED"
            const val SETTINGS_UNAVAILABLE = "SETTINGS_UNAVAILABLE"
            const val SDK_UPGRADE_REQUIRED = "SDK_UPGRADE_REQUIRED"
            const val PARTNER_KEY_REJECTED = "PARTNER_KEY_REJECTED"
            const val INVALID_REQUEST = "INVALID_REQUEST"

            /** [reasonParams] key of the back office's error code on [INVALID_REQUEST]. */
            const val ERROR_PARAM = "error"
            const val UNSUPPORTED_CURRENCY = "unsupported_currency"
            internal const val SUPPORTED_CURRENCY = "BHD"

            internal fun invalidRequest(journey: String, code: String?) = JourneyNotEnabled(
                journey,
                INVALID_REQUEST,
                reasonParams = code?.let { mapOf(ERROR_PARAM to it) }.orEmpty()
            )

            const val CASH_LOAN = "cashLoan"
            const val MERCHANT_CHECKOUT = "merchantCheckout"
            const val AUTO = "auto"
            const val FINANCING_OPTIONS = "financingOptions"
        }
    }

    data class Unknown(
        override val message: String,
        override val errorCode: Int = 0,
        override val txnId: String = ""
    ) : NanoLoanError(message, errorCode, txnId, enableFeedback = true, enableTryAgain = true)
}
