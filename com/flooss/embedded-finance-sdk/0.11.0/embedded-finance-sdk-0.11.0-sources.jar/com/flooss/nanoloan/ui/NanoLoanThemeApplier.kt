package com.flooss.nanoloan.ui

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.View
import android.widget.ImageView
import com.flooss.nanoloan.R
import com.flooss.nanoloan.config.NanoLoanTheme

/**
 * Programmatic NanoLoanTheme application on top of the ported REAL Flooss screens
 * (task step 5): the XMLs stay verbatim Flooss; after inflate we retint the cheap,
 * high-visibility surfaces —
 *  - toolbar/header + sheet chrome background               <- theme.secondaryColor
 *  - primary action buttons (Next/Confirm/Accept/Done)      <- theme.primaryColor,
 *    corner radius from theme.cornerRadiusDp
 *  - header logo slot                                       <- theme.logoRes
 * Deep Flooss branding (slider oranges, congratulations palette, summary-chip navy,
 * celebration artwork) intentionally stays hardcoded for now.
 */
internal object NanoLoanThemeApplier {

    /** Header include + the navy chrome view the header sits on. */
    fun applyHeader(headerRoot: View, theme: NanoLoanTheme) {
        headerRoot.setBackgroundColor(theme.secondaryColor)
        val logo = headerRoot.findViewById<ImageView>(R.id.logo_iv)
        val logoRes = theme.logoRes
        if (logo != null && logoRes != null) {
            logo.setImageResource(logoRes)
            logo.visibility = View.VISIBLE
        }
    }

    /** The screen's own navy background surfaces (rootLayout etc.). */
    fun applyChromeBackground(view: View, theme: NanoLoanTheme) {
        view.setBackgroundColor(theme.secondaryColor)
    }

    /**
     * Primary action button — keeps ripple + rounded shape, swaps the fill color.
     *
     * The fill is a state list, not a flat colour: several v3 screens gate their action
     * behind a consent or a required field, and a themed button that looked identical
     * enabled and disabled would invite taps that do nothing.
     */
    fun applyPrimaryButton(button: View, theme: NanoLoanTheme) {
        val density = button.resources.displayMetrics.density
        val enabledFill = ColorStateList(
            arrayOf(intArrayOf(-android.R.attr.state_enabled), intArrayOf()),
            intArrayOf(withAlpha(theme.primaryColor, DISABLED_FILL_ALPHA), theme.primaryColor)
        )
        val shape = GradientDrawable().apply {
            cornerRadius = theme.cornerRadiusDp * density
            color = enabledFill
        }
        val mask = GradientDrawable().apply {
            cornerRadius = theme.cornerRadiusDp * density
            setColor(Color.BLACK)
        }
        button.background = RippleDrawable(
            ColorStateList.valueOf(withAlpha(Color.WHITE, 0x40)),
            shape,
            mask
        )
    }

    /** Roughly 40% — visibly inert without disappearing against the sheet. */
    private const val DISABLED_FILL_ALPHA = 0x66

    private fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
}
