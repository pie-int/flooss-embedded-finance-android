package com.flooss.nanoloan.model

/**
 * Loan-domain OAuth token, handed to the SDK by the host (design doc §7.2 Model A —
 * token handoff, the only handoff model this POC implements; Model B, credential/PIN
 * handoff, is deferred/backlog).
 */
data class NanoLoanToken(
    val accessToken: String,
    val refreshToken: String? = null,
    val expiresIn: Long = 3600
)
