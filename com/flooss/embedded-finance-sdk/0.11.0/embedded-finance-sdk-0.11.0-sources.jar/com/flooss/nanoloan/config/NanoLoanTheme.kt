package com.flooss.nanoloan.config

import androidx.annotation.ColorInt
import androidx.annotation.DrawableRes

/**
 * Injectable look & feel for the journey UI (design doc §12.1). Trimmed from the doc's
 * full token list (primary/secondary/base/error/cornerRadius/logo/font, per the task's
 * POC-speed allowance) but every field here is actually read by
 * [com.flooss.nanoloan.ui.NanoLoanJourneyScreen] at render time — this is the SDK's
 * theme-injection proof point, not a data class nobody consumes.
 */
data class NanoLoanTheme(
    @ColorInt val primaryColor: Int,
    @ColorInt val secondaryColor: Int,
    @ColorInt val baseColor: Int,
    @ColorInt val errorColor: Int,
    val cornerRadiusDp: Float = 12f,
    @DrawableRes val logoRes: Int? = null,
    val brandName: String = "Embedded Finance"
)
