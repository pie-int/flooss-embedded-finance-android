package com.flooss.nanoloan.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R

/**
 * SDK_V3_PRODUCT_GAPS §2.5 — the direct-debit mandate, the last step before the journey
 * ends. Confirms the account instalments are collected from (prefilled from the
 * disbursement step where one was given, editable because the two need not be the same
 * account), shows the mandate terms, and requires an explicit authorisation.
 *
 * Who EXECUTES the collection is an open business question between the host and Flooss.
 * This screen captures the customer's authorisation only, and the terms text says exactly
 * that rather than implying an operator the commercials have not yet named.
 */
internal class NanoLoanDirectDebitFragment : NanoLoanJourneyFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_direct_debit, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme

        setUpHeader(
            headerRoot = view.findViewById(R.id.header),
            title = getString(R.string.nanoloan_mandate_title),
            dotCount = 3,
            dotIndex = 3,
            screenNumber = "12/12",
            stepName = STEP_NAME
        ) {
            authorise(view)
        }
        NanoLoanThemeApplier.applyChromeBackground(view.findViewById(R.id.rootLayout), theme)
        NanoLoanSDK.notifyDirectDebitSetup()

        val account = view.findViewById<EditText>(R.id.mandate_account)
        journeyData.disbursementIban?.let { account.setText(it) }
        journeyData.disbursementBankName?.let { bank ->
            view.findViewById<TextView>(R.id.mandate_bank).apply {
                text = getString(R.string.nanoloan_mandate_bank, bank)
                visibility = View.VISIBLE
            }
        }

        // Instalment and term come from the SAME source: the underwritten offer when
        // there is one, the customer's own selection otherwise. Mixing them would print
        // a 12-month instalment beside a 4-month term.
        val offer = journeyData.offer
        view.findViewById<TextView>(R.id.mandate_terms).text = getString(
            R.string.nanoloan_mandate_terms,
            instalmentText(),
            ordinalDay(journeyData.selectedRepaymentDate),
            offer?.period?.toInt() ?: journeyData.loanDurationMonths
        )

        val consent = view.findViewById<CheckBox>(R.id.mandate_consent)
        val button = view.findViewById<View>(R.id.mandate_btn)

        fun refresh() {
            button.isEnabled = consent.isChecked && account.text.toString().isNotBlank()
        }
        consent.setOnCheckedChangeListener { _, _ -> refresh() }
        view.findViewById<View>(R.id.mandate_consent_row).setOnClickListener {
            consent.isChecked = !consent.isChecked
        }
        account.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = Unit
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = refresh()
            override fun afterTextChanged(s: Editable?) = Unit
        })
        button.setOnClickListener { authorise(view) }
        refresh()
    }

    private fun authorise(view: View) {
        val account = view.findViewById<EditText>(R.id.mandate_account).text.toString().trim()
        val masked = mask(account)
        journeyData.mandateMaskedAccount = masked
        // Masked here, at the source: the raw account never reaches an event or a log.
        NanoLoanSDK.notifyMandateAuthorised(masked)
        journeyHost.goToConfirmation()
    }

    /** Last four characters only; everything before them is dotted out. */
    private fun mask(account: String): String {
        val compact = account.replace(" ", "")
        if (compact.length <= MASK_VISIBLE_CHARS) return "••••"
        return "•••• " + compact.takeLast(MASK_VISIBLE_CHARS)
    }

    private fun instalmentText(): String {
        val offer = journeyData.offer
        val instalment = offer?.installmentAmount?.toDouble()
            ?: NanoLoanMath.getInstallmentToPay(
                journeyData.loanAmount.toFloat(),
                journeyData.loanDurationMonths
            ).toDouble()
        return NanoLoanMath.formatDouble(instalment) + " " + getString(R.string.bhd_app_text)
    }

    private fun ordinalDay(day: Int): String {
        // Arabic reads "اليوم 27", with no ordinal suffix on the number.
        if (com.flooss.nanoloan.ui.widget.NanoLoanFontResolver.isArabic()) return day.toString()
        val suffix = when {
            day % 100 in 11..13 -> "th"
            day % 10 == 1 -> "st"
            day % 10 == 2 -> "nd"
            day % 10 == 3 -> "rd"
            else -> "th"
        }
        return "$day$suffix"
    }

    companion object {
        const val STEP_NAME = "direct_debit_mandate"
        private const val MASK_VISIBLE_CHARS = 4
    }
}
