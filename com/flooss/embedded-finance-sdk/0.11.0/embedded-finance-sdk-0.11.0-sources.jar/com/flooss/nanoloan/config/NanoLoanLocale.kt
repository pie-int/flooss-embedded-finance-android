package com.flooss.nanoloan.config

/**
 * Drives resource/layout-direction selection for the journey UI (design doc §6.1, §12.2).
 * The Android-specific RTL open decision (§12.2/§17 item 18 — system RTL mirroring vs.
 * manual `-ar` resource swap) is out of scope for this POC slice: [ARABIC] here only
 * flips a handful of hardcoded strings and `LayoutDirection.Rtl` on the Compose journey,
 * it does not stand up a parallel `-ar` resource set.
 */
enum class NanoLoanLocale {
    ENGLISH,
    ARABIC
}
