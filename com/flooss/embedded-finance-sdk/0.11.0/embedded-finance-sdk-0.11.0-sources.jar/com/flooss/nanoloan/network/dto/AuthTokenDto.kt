package com.flooss.nanoloan.network.dto

import com.google.gson.annotations.SerializedName

/**
 * `POST api/v1/oauth/token` response — same field set as the app's
 * `data/model/api/response/SalafAuthTokenRes` / `data/db/entities/AuthToken`.
 */
internal data class AuthTokenDto(
    @SerializedName("access_token") val accessToken: String?,
    @SerializedName("token_type") val tokenType: String?,
    @SerializedName("refresh_token") val refreshToken: String?,
    @SerializedName("expires_in") val expiresIn: Long?,
    @SerializedName("scope") val scope: String?
)
