package com.flooss.nanoloan.result

/** Design doc §9.1. */
sealed class NanoLoanResult<out T> {
    data class Success<T>(val value: T) : NanoLoanResult<T>()
    data class Failure(val error: NanoLoanError) : NanoLoanResult<Nothing>()
}
