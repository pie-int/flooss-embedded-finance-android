package com.flooss.nanoloan.network.dto

import com.google.gson.annotations.SerializedName

/**
 * `GET api/v1/fo/loans/disbursement/bank-detail/{iban}` response — mirrors the app's
 * `BankDetailResponse` (id/name/bic/accountId/bankLogo/iban).
 */
internal data class BankDetailResponseDto(
    @SerializedName("id") val id: Int?,
    @SerializedName("name") val name: String?,
    @SerializedName("bic") val bic: String?,
    @SerializedName("accountId") val accountId: String?,
    @SerializedName("bankLogo") val bankLogo: String?,
    @SerializedName("iban") val iban: String?
)
