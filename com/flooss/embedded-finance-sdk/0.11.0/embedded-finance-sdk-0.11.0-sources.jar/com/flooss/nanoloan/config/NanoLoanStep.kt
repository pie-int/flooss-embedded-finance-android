package com.flooss.nanoloan.config

/**
 * Journey steps whose ownership is configurable per §3.5's integration options —
 * Option A (SDK-presented UI) vs Option B (host-collected input, §9.5). The step list
 * mirrors the input-heavy screens of the real Apply Loan flow.
 */
enum class NanoLoanStep {
    EMPLOYMENT_DETAILS,
    EMAIL_VERIFICATION,
    SALARY_VERIFICATION,

    // v3 (SDK_V3_PRODUCT_GAPS §2). Each is SDK-presented by default and can be handed to
    // the host exactly like the three above.

    /** §2.3 — additional KYC details after the offer. */
    KYC_DETAILS,

    /** §2.4 — the final financial check against host-supplied bureau data. */
    FINAL_CHECK,

    /** §2.6 — digital signature on the agreements. */
    DIGITAL_SIGNATURE,

    /** §2.5 — direct-debit mandate authorisation. */
    DIRECT_DEBIT_MANDATE
}

/** Who renders/collects a given [NanoLoanStep]. Default everywhere is [SDK] (Option A). */
enum class NanoStepOwner {
    /** Option A — the SDK presents its own (Flooss-styled) screen for the step. */
    SDK,

    /**
     * Option B — the SDK pauses, emits
     * [com.flooss.nanoloan.listener.NanoLoanEvent.InputRequired] and waits for the host
     * to collect the values in its own UI and call
     * [com.flooss.nanoloan.NanoLoanSDK.submitStepInput].
     */
    HOST
}
