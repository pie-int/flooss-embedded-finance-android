package com.flooss.nanoloan.ui

import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.model.KycField
import com.flooss.nanoloan.model.KycKeyboard

/**
 * SDK_V3_PRODUCT_GAPS §2.3 — the customer details eKYC did not provide, collected after
 * the offer is chosen.
 *
 * The form is BUILT from [com.flooss.nanoloan.config.NanoLoanConfiguration.kycFields], not
 * hardcoded: a host that needs another field adds a descriptor rather than waiting for an
 * SDK release. Labels come from the host too, so it localises them on its own terms.
 *
 * Only field KEYS ever leave this screen as telemetry. The answers go to the host's
 * listener and nowhere else.
 */
internal class NanoLoanKycDetailsFragment : NanoLoanJourneyFragment() {

    private val inputs = LinkedHashMap<KycField, EditText>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_kyc_details, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme

        setUpHeader(
            headerRoot = view.findViewById(R.id.header),
            title = getString(R.string.nanoloan_kyc_title),
            dotCount = 4,
            dotIndex = 2,
            screenNumber = "7/12",
            stepName = STEP_NAME
        ) {
            submit()
        }
        NanoLoanThemeApplier.applyChromeBackground(view.findViewById(R.id.rootLayout), theme)

        val container = view.findViewById<LinearLayout>(R.id.kyc_fields)
        val button = view.findViewById<View>(R.id.kyc_next_btn)

        fun refresh() {
            button.isEnabled = inputs.none { (field, input) ->
                field.required && input.text.toString().isBlank()
            }
        }

        NanoLoanSDK.currentConfiguration().resolvedKycFields(resources).forEach { field ->
            val row = layoutInflater.inflate(R.layout.nanoloan_item_kyc_field, container, false)
            row.findViewById<TextView>(R.id.kyc_label).text = field.label
            val input = row.findViewById<EditText>(R.id.kyc_input)
            input.inputType = inputTypeFor(field.keyboard)
            journeyData.kycDetails[field.key]?.let { input.setText(it) }
            input.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = Unit
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) = refresh()
                override fun afterTextChanged(s: Editable?) = Unit
            })
            inputs[field] = input
            container.addView(row)
        }

        NanoLoanThemeApplier.applyPrimaryButton(button, theme)
        button.setOnClickListener { submit() }
        refresh()
    }

    private fun submit() {
        val values = inputs.entries.associate { (field, input) ->
            field.key to input.text.toString().trim()
        }.filterValues { it.isNotEmpty() }
        journeyData.kycDetails = values
        // KEYS only leave here as telemetry; the answers go to the host's listener.
        NanoLoanSDK.notifyKycDetailsSubmitted(values.keys.toList())
        journeyHost.goToDisbursementChannel()
    }

    private fun inputTypeFor(keyboard: KycKeyboard): Int = when (keyboard) {
        KycKeyboard.TEXT -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        KycKeyboard.NUMBER -> InputType.TYPE_CLASS_NUMBER
        KycKeyboard.EMAIL -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        KycKeyboard.PHONE -> InputType.TYPE_CLASS_PHONE
    }

    companion object {
        const val STEP_NAME = "kyc_details"
    }
}
