package com.flooss.nanoloan.telemetry

import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

/** Contract §2 `device` block. Supplied by the platform layer so this class stays JVM-testable. */
internal data class NanoTelemetryDevice(
    val osVersion: String,
    val model: String,
    val locale: String,
    val timezone: String
)

/**
 * The telemetry sink itself: session envelope, monotonic `seq`, redaction gate, bounded
 * buffer, periodic + on-demand flush, batched POST with retry.
 *
 * ## Fire-and-forget guarantee (contract §1.5)
 * Every public entry point is wrapped so that **no throwable and no failure status ever
 * reaches the caller**. [record] returns Unit and swallows everything; [flush] hands the
 * work to a dedicated single-thread executor and never blocks the journey; the sender
 * classifies a transport failure as a result value rather than an exception. A host that
 * misconfigures the endpoint, revokes the key, or points the SDK at a dead box sees
 * exactly the same journey behaviour as one with telemetry switched off.
 *
 * ## Threading
 * [record] is called from the journey's thread (Main on Android) and does only a
 * synchronized array-deque push. All I/O happens on [worker], a single thread, so batches
 * are serialised and `seq` order is preserved across retries.
 */
internal class NanoTelemetryClient(
    private val config: NanoTelemetryConfiguration,
    private val environment: String,
    private val platform: String,
    private val sdkVersion: String,
    /**
     * Back-office v2 spec §2. Host-supplied, opaque, already PII-gated by
     * [NanoTelemetryRedactor.sanitizeExternalUserRef] before it reaches this type — null
     * when absent or refused. Constant for the session, sent in every batch's `session`
     * block.
     */
    private val externalUserRef: String? = null,
    private val device: NanoTelemetryDevice,
    private val sender: NanoTelemetrySender,
    private val debugLog: (String) -> Unit = {},
    private val clock: () -> Long = System::currentTimeMillis,
    private val worker: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "nanoloan-telemetry").apply { isDaemon = true }
    }
) {

    val sessionId: String = UUID.randomUUID().toString()
    private val startedAt: String = NanoTelemetryClock.iso(clock())
    private val seq = AtomicLong(0)
    private val buffer = NanoTelemetryBuffer(config.maxBufferedEvents.coerceAtLeast(1))

    @Volatile private var journeyId: String? = null
    @Volatile private var cprHash: String? = null
    @Volatile private var stopped = false
    @Volatile private var retryNotBeforeMs = 0L
    private var consecutiveFailures = 0

    /** Events refused by the redaction gate. Reported on the next batch, never silent. */
    private val redactionDrops = AtomicLong(0)

    init {
        worker.scheduleWithFixedDelay(
            { safely { flushOnce() } },
            config.effectiveFlushIntervalSeconds,
            config.effectiveFlushIntervalSeconds,
            TimeUnit.SECONDS
        )
    }

    // ── Session correlators ──────────────────────────────────────────────────────────

    /** Stores the contract §1.1 `cprHash` only. The raw CPR is never retained. */
    fun setCpr(rawCpr: String?) = safely {
        cprHash = NanoTelemetryRedactor.cprHash(rawCpr, config.apiKey.get())
    }

    fun startJourney(): String? = safelyReturning {
        val id = UUID.randomUUID().toString()
        journeyId = id
        id
    }

    fun endJourney() = safely {
        journeyId = null
    }

    // ── Emission ─────────────────────────────────────────────────────────────────────

    /**
     * Buffers one contract §3 event. Silently no-ops when the event would violate the
     * closed vocabularies or when redaction refuses its payload — an invalid event is a
     * bug in the mapper, and shipping it would earn a 422 that poisons the whole batch.
     */
    /**
     * The server's `attrs.step` is optional but NOT nullable: `"step": null` rejects the whole
     * batch (422). A step with no contract member (the v3 KYC / final-check / mandate steps,
     * e.g. in a HOST-owned `step_ownership`) is therefore omitted, not nulled.
     */
    internal fun withoutNullStep(attrs: Map<String, Any?>): Map<String, Any?> =
        if (attrs.containsKey("step") && attrs["step"] == null) attrs - "step" else attrs

    fun record(kind: String, name: String, step: String?, attrs: Map<String, Any?> = emptyMap()) = safely {
        if (stopped) return@safely
        val safeAttrs = NanoTelemetryRedactor.redactAttrs(withoutNullStep(attrs))
        val event = NanoTelemetryEvent(
            eventId = NanoTelemetryEvent.newEventId(),
            seq = seq.incrementAndGet(),
            ts = NanoTelemetryClock.iso(clock()),
            kind = kind,
            name = name,
            step = step?.takeIf { NanoTelemetryContract.isValidStep(it) },
            attrs = safeAttrs
        )
        if (!event.isContractValid()) {
            redactionDrops.incrementAndGet()
            debug("dropped out-of-vocabulary event kind=$kind name=$name")
            return@safely
        }
        // Belt and braces: the serialized event must not contain anything PII-shaped even
        // after per-value redaction (a value could be assembled from two safe halves).
        val json = event.toJson()
        if (NanoTelemetryRedactor.containsLikelyPii(json)) {
            redactionDrops.incrementAndGet()
            debug("dropped event kind=$kind name=$name — failed the post-serialization PII gate")
            return@safely
        }
        buffer.offer(event)
        if (buffer.size >= config.effectiveMaxBatchSize) flush()
    }

    // ── Flushing ─────────────────────────────────────────────────────────────────────

    /** Asks for a flush. Returns immediately; the POST happens on [worker]. */
    fun flush() = safely {
        if (stopped) return@safely
        worker.execute { safely { flushOnce() } }
    }

    /** Journey end / app backgrounding: flush what is buffered and stop the timer. */
    fun shutdown() = safely {
        if (stopped) return@safely
        stopped = true
        worker.execute { safely { flushOnce(force = true) } }
        worker.shutdown()
    }

    private fun flushOnce(force: Boolean = false) {
        if (!force && clock() < retryNotBeforeMs) return
        // Resolved BEFORE draining: a host whose secret store is momentarily locked keeps
        // its buffered events for the next flush instead of losing them.
        val key = runCatching { config.apiKey.get() }.getOrNull().orEmpty()
        if (key.isBlank()) {
            debug("no API key available — nothing sent, buffer left intact")
            return
        }
        val batch = buffer.drain(config.effectiveMaxBatchSize)
        if (batch.isEmpty()) return

        val batchId = UUID.randomUUID().toString()
        val body = buildBatchJson(batchId, batch)

        when (val result = sender.send(config.ingestUrl(), key, batchId, body)) {
            is TelemetrySendResult.Accepted -> {
                consecutiveFailures = 0
                retryNotBeforeMs = 0
                debug("batch $batchId accepted (${batch.size} events, http ${result.status})")
            }
            is TelemetrySendResult.Rejected -> {
                // 4xx other than 429: retrying an unauthorised key or a malformed batch
                // just burns battery. Drop it and say so.
                consecutiveFailures = 0
                debug("batch $batchId rejected http ${result.status} — ${batch.size} events discarded")
            }
            is TelemetrySendResult.RateLimited -> scheduleRetry(batch, result.retryAfterMillis, "429")
            is TelemetrySendResult.Retryable -> scheduleRetry(batch, null, "http ${result.status} ${result.reason}")
        }
    }

    private fun scheduleRetry(batch: List<NanoTelemetryEvent>, retryAfterMs: Long?, why: String) {
        consecutiveFailures++
        if (consecutiveFailures > NanoTelemetryBackoff.MAX_ATTEMPTS) {
            debug("giving up on ${batch.size} events after $consecutiveFailures attempts ($why)")
            consecutiveFailures = 0
            retryNotBeforeMs = 0
            return
        }
        buffer.requeue(batch)
        val delay = NanoTelemetryBackoff.retryDelayMillis(consecutiveFailures - 1, retryAfterMs)
        retryNotBeforeMs = clock() + delay
        debug("retry ${batch.size} events in ${delay}ms (attempt $consecutiveFailures, $why)")
        if (!stopped) {
            runCatching { worker.schedule({ safely { flushOnce() } }, delay, TimeUnit.MILLISECONDS) }
        }
    }

    /** Contract §2 batch envelope. */
    internal fun buildBatchJson(batchId: String, events: List<NanoTelemetryEvent>): String {
        val dropped = buffer.droppedCount + redactionDrops.get()
        return buildString {
            append('{')
            append("\"contractVersion\":").append(NanoTelemetryContract.CONTRACT_VERSION).append(',')
            append("\"batchId\":").append(NanoJson.quote(batchId)).append(',')
            append("\"sdk\":").append(
                NanoJson.obj(mapOf("platform" to platform, "version" to sdkVersion))
            ).append(',')
            append("\"device\":").append(
                NanoJson.obj(
                    mapOf(
                        "osVersion" to device.osVersion,
                        "model" to device.model,
                        "locale" to device.locale,
                        "timezone" to device.timezone
                    )
                )
            ).append(',')
            val session = linkedMapOf<String, Any?>(
                "sessionId" to sessionId,
                "journeyId" to journeyId,
                "environment" to environment,
                "startedAt" to startedAt,
                "cprHash" to cprHash
            )
            // v2 §2. Added only when the host supplied one that survived the PII gate, so
            // a host that does not use the field sees the byte-identical v1 envelope.
            if (externalUserRef != null) session["externalUserRef"] = externalUserRef
            append("\"session\":").append(NanoJson.obj(session)).append(',')
            if (dropped > 0) {
                // Not in the §2 shape, but a gap in `seq` with no explanation reads as a
                // transport bug. Additive and ignorable by a strict consumer.
                append("\"droppedEvents\":").append(dropped).append(',')
            }
            append("\"events\":").append(NanoJson.array(events.map { it.toJson() }))
            append('}')
        }
    }

    // ── Diagnostics / test seams ─────────────────────────────────────────────────────

    internal val bufferedCount: Int get() = buffer.size
    internal val droppedCount: Long get() = buffer.droppedCount
    internal fun currentSeq(): Long = seq.get()
    internal fun drainForTest(max: Int) = buffer.drain(max)
    internal fun flushBlockingForTest() = safely { flushOnce() }

    private fun debug(message: String) {
        if (config.debugLogging) debugLog(message)
    }

    private inline fun safely(block: () -> Unit) {
        try {
            block()
        } catch (t: Throwable) {
            // Contract §1.5. Nothing from the telemetry pipeline may surface to the host.
            try {
                if (config.debugLogging) debugLog("telemetry suppressed ${t.javaClass.simpleName}: ${t.message}")
            } catch (_: Throwable) {
            }
        }
    }

    private inline fun <T> safelyReturning(block: () -> T): T? = try {
        block()
    } catch (_: Throwable) {
        null
    }
}
