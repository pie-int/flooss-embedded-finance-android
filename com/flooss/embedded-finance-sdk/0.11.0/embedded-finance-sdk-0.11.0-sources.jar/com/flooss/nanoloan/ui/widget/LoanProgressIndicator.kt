package com.flooss.nanoloan.ui.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import com.flooss.nanoloan.R

/**
 * Ported from :app `com.pie.flooss.util.LoanProgressIndicator` (the white step dots in
 * the loan header). `setBlueDots`/the blue variant layout are not used by the ported
 * journey and were left behind.
 */
class LoanProgressIndicator : LinearLayout {

    constructor(context: Context?, attrs: AttributeSet?, defStyle: Int) : super(
        context!!,
        attrs,
        defStyle
    )

    constructor(context: Context?, attrs: AttributeSet?) : super(context!!, attrs)

    constructor(context: Context?) : super(context!!)

    fun setDots(count: Int, screenNumber: Int) {
        this.removeAllViews()
        val layoutInflater: LayoutInflater = LayoutInflater.from(context)
        for (i in 1..count) {
            val view: View = layoutInflater.inflate(
                R.layout.loan_progress_indicator_view,
                this,
                false
            )
            val unselectedIv = view.findViewById<ImageView>(R.id.unselectedIv)
            val selectedIv = view.findViewById<ImageView>(R.id.selectedIv)
            if (i == screenNumber) {
                unselectedIv.visibility = View.GONE
                selectedIv.visibility = View.VISIBLE
            } else {
                unselectedIv.visibility = View.VISIBLE
                selectedIv.visibility = View.GONE
            }
            this.addView(view, (i - 1))
        }
    }
}
