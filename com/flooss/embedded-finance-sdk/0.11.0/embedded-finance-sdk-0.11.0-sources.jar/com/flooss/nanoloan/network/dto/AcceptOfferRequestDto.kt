package com.flooss.nanoloan.network.dto

/**
 * Wire shape of the body `POST api/v1/fo/loans/normal/{id}/offers/{offerGuid}/accept`
 * expects — a trimmed mirror of the app's `LoanOfferNormalAcceptRequest`
 * (`data/model/api/request/LoanOfferNormalAcceptRequest.kt`). The full request also
 * carries `disbursementMethod`/`inspectionMetadata`/phone-OTP fields tied to the
 * disbursement-method-selection and secondary-ID-verification steps (F7/F3), which are
 * out of scope for this POC's core accept action — this POC accepts with terms-accepted
 * only, no disbursement-method selection.
 */
data class AcceptOfferRequestDto(
    val id: Long,
    val offerGuid: String,
    val termsAndConditionsAccepted: Boolean = true,
    val acceptedAt: String,
    // Phone-OTP fields from the real LoanOfferNormalAcceptRequest — set on the
    // `.../verify-otp` call of the acceptance chain (LoanApi.acceptOfferOtpVerify).
    val phoneVerificationActionUUID: String? = null,
    val phoneVerificationCode: String? = null
)

/** Wire shape of the body `POST api/v1/fo/loans/{id}/offers/{offerGuid}/decline` expects. */
data class DeclineOfferRequestDto(
    val reason: String?,
    val rejectedAt: String
)
