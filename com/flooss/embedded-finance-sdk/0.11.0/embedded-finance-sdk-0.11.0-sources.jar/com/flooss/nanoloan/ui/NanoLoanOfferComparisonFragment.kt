package com.flooss.nanoloan.ui

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.model.HostOffer
import com.flooss.nanoloan.model.OfferSource
import java.util.Locale

/**
 * SDK_V3_PRODUCT_GAPS §2.2 — the host's offer and the Flooss offer side by side, each with
 * amount, tenor, monthly instalment, APR and total payable, each brand-marked, each with
 * its own selection action.
 *
 * **The SDK never fabricates the host's offer.** This screen is only reached when the host
 * passed one through [NanoLoanSDK.presentOfferComparison] (or the journey entry point);
 * with none, [NanoLoanJourneySheetFragment] skips straight to the single-offer screen that
 * already existed.
 *
 * The Flooss column is the SDK's own indicative quote for the amount and tenor the
 * customer just chose — the same [NanoLoanMath] figures the amount screen displayed a
 * moment ago, not a second set of numbers invented here. Once the real offer has been
 * fetched ([JourneyData.offer]) that is used instead. Either way the screen says which it
 * is, because an indicative figure and an underwritten one must not look equally firm.
 *
 * Selecting the HOST's offer ends the SDK journey: from that point the customer is the
 * host's, and the SDK has nothing further to do. Selecting Flooss continues the journey.
 */
internal class NanoLoanOfferComparisonFragment : NanoLoanJourneyFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_offer_comparison, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme

        setUpHeader(
            headerRoot = view.findViewById(R.id.header),
            title = getString(R.string.nanoloan_compare_offers_title),
            dotCount = 4,
            dotIndex = 2,
            screenNumber = "5/12",
            stepName = STEP_NAME
        ) {
            selectOffer(OfferSource.FLOOSS)
        }
        NanoLoanThemeApplier.applyChromeBackground(view.findViewById(R.id.rootLayout), theme)

        val hostOffer = NanoLoanSDK.currentHostOffer()
        NanoLoanSDK.notifyOfferComparisonShown(hostOfferPresent = hostOffer != null)

        bindHostColumn(view.findViewById(R.id.host_offer), hostOffer)
        bindFloossColumn(view.findViewById(R.id.flooss_offer))
    }

    private fun bindHostColumn(column: View, hostOffer: HostOffer?) {
        // Unreachable in the journey (the sheet skips this screen without a host offer),
        // but a host calling presentOfferComparison directly could still get here.
        if (hostOffer == null) {
            column.visibility = View.GONE
            return
        }
        bindColumn(
            column = column,
            brand = hostOffer.providerName,
            brandColor = HOST_BRAND_COLOR,
            amountFils = hostOffer.amountFils,
            tenorMonths = hostOffer.tenorMonths,
            instalmentFils = hostOffer.monthlyInstalmentFils,
            aprPercent = hostOffer.aprPercent,
            totalFils = hostOffer.totalPayableFils
        ) { selectOffer(OfferSource.HOST) }
    }

    private fun bindFloossColumn(column: View) {
        val offer = journeyData.offer
        // The offer's own term when there is one: its instalment and total were priced
        // for that term, not for whatever the amount screen last selected.
        val tenor = offer?.period?.toInt() ?: journeyData.loanDurationMonths
        val amountFils: Long
        val instalmentFils: Long
        val totalFils: Long
        val apr: Double?

        if (offer != null) {
            amountFils = toFils(offer.loanAmount ?: offer.principalAmount)
            instalmentFils = toFils(offer.installmentAmount)
            totalFils = toFils(offer.totalAmount)
            apr = offer.interestRate?.removeSuffix("%")?.trim()?.toDoubleOrNull()
        } else {
            // The SDK's own indicative quote — the exact figures the amount screen just
            // showed, via the same ported AppUtil formula. Not a second estimate.
            val amount = journeyData.loanAmount.toFloat()
            amountFils = journeyData.loanAmount.toLong() * FILS_PER_DINAR
            instalmentFils = NanoLoanMath.getInstallmentToPay(amount, tenor).toLong() * FILS_PER_DINAR
            totalFils = NanoLoanMath.getTotalToPay(amount, tenor).toLong() * FILS_PER_DINAR
            apr = null
        }

        bindColumn(
            column = column,
            brand = getString(R.string.nanoloan_flooss_brand),
            brandColor = NanoLoanSDK.currentConfiguration().theme.primaryColor,
            amountFils = amountFils,
            tenorMonths = tenor,
            instalmentFils = instalmentFils,
            aprPercent = apr,
            totalFils = totalFils
        ) { selectOffer(OfferSource.FLOOSS) }
    }

    private fun bindColumn(
        column: View,
        brand: String,
        brandColor: Int,
        amountFils: Long,
        tenorMonths: Int,
        instalmentFils: Long,
        aprPercent: Double?,
        totalFils: Long,
        onSelect: () -> Unit
    ) {
        column.findViewById<TextView>(R.id.offer_brand).apply {
            text = brand
            setBackgroundColor(brandColor)
        }
        column.findViewById<TextView>(R.id.offer_amount).text = formatBhd(amountFils)
        row(
            column, R.id.row_tenor, getString(R.string.nanoloan_offer_tenor),
            resources.getString(
                if (tenorMonths == 1) R.string.nanoloan_offer_month
                else R.string.nanoloan_offer_months,
                tenorMonths
            )
        )
        row(
            column, R.id.row_instalment, getString(R.string.nanoloan_offer_monthly),
            formatBhd(instalmentFils)
        )
        row(
            column, R.id.row_apr, getString(R.string.nanoloan_offer_apr),
            // A missing APR reads as missing; it must never render as 0%.
            aprPercent?.let { String.format(Locale.ENGLISH, "%.2f%%", it) }
                ?: getString(R.string.nanoloan_not_quoted)
        )
        row(
            column, R.id.row_total, getString(R.string.nanoloan_offer_total),
            formatBhd(totalFils)
        )

        val button = column.findViewById<View>(R.id.offer_select_btn)
        NanoLoanThemeApplier.applyPrimaryButton(button, NanoLoanSDK.currentConfiguration().theme)
        button.setOnClickListener { onSelect() }
    }

    private fun row(column: View, rowId: Int, label: String, value: String) {
        val row = column.findViewById<View>(rowId)
        row.findViewById<TextView>(R.id.compare_label).text = label
        row.findViewById<TextView>(R.id.compare_value).text = value
    }

    private fun selectOffer(source: OfferSource) {
        NanoLoanSDK.notifyOfferSelected(source)
        when (source) {
            // The host's offer is the host's business from here; the SDK gets out of
            // the way rather than carrying a competitor's application.
            OfferSource.HOST -> journeyHost.finishJourney(com.flooss.nanoloan.model.JourneyStatus.HOST_OFFER_SELECTED)
            OfferSource.FLOOSS -> journeyHost.goToOffer()
        }
    }

    /** Fils -> the app's own three-decimal money format ("1500.000 BHD"). */
    private fun formatBhd(fils: Long): String =
        NanoLoanMath.formatDouble(fils.toDouble() / FILS_PER_DINAR) +
            " " + getString(R.string.bhd_app_text)

    private fun toFils(amount: java.math.BigDecimal?): Long =
        amount?.movePointRight(3)?.setScale(0, java.math.RoundingMode.HALF_UP)?.toLong() ?: 0L

    companion object {
        const val STEP_NAME = "offer_comparison"

        /** BHD has three minor units. */
        private const val FILS_PER_DINAR = 1000L

        /** Neutral slate for the host's strip — never a Flooss colour. */
        private val HOST_BRAND_COLOR = Color.parseColor("#3D4B5C")
    }
}
