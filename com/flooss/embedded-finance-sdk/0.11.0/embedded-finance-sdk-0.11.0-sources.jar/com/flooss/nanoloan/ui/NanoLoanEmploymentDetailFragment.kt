package com.flooss.nanoloan.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.appcompat.widget.AppCompatTextView
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.model.EmploymentDetails
import com.flooss.nanoloan.model.EmploymentOption
import com.flooss.nanoloan.result.NanoLoanResult
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputEditText
import android.widget.TextView
import android.app.DatePickerDialog
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Step 2 — REAL screen port of :app `EmploymentDetailFragment` +
 * `fragment_employment_details.xml` ("fill the missing details", real Apply Loan screen
 * 2/4): employer/company autocomplete, job title, and the education-level, work-experience
 * and years-in-job choices the backend requires, loaded from `GET fo/profile/attributes`. This is also the SDK-owned (Option A) implementation of the
 * [com.flooss.nanoloan.config.NanoLoanStep.EMPLOYMENT_DETAILS] step — when the host
 * configures HOST ownership the sheet never shows this screen and pauses for
 * `submitStepInput` instead.
 *
 * Save = the real `POST api/v1/fo/client-profile/employment-details`
 * (`UserProfileApi.saveEmploymentDetailsApi`); the employer autocomplete is the private
 * companies list (`GET api/v1/fo/companies/private`), as in the app.
 */
internal class NanoLoanEmploymentDetailFragment : NanoLoanJourneyFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_employment_details, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme

        setUpHeader(
            headerRoot = view.findViewById(R.id.header_layout),
            title = getString(R.string.employment_details),
            dotCount = 4,
            dotIndex = 2,
            screenNumber = "2/12",
            stepName = STEP_NAME
        ) {
            journeyHost.goToSalaryVerification()
        }
        NanoLoanThemeApplier.applyChromeBackground(view.findViewById(R.id.rootLayout), theme)

        val companyName = view.findViewById<MaterialAutoCompleteTextView>(R.id.company_name)
        val jobTitle = view.findViewById<TextInputEditText>(R.id.job_title)
        val startDate = view.findViewById<TextInputEditText>(R.id.start_date)
        val dateError = view.findViewById<View>(R.id.start_date_error)
        val education = view.findViewById<MaterialAutoCompleteTextView>(R.id.education_level)
        val experience = view.findViewById<MaterialAutoCompleteTextView>(R.id.work_experience)
        val yearsInJob = view.findViewById<MaterialAutoCompleteTextView>(R.id.years_in_job)
        val companyError = view.findViewById<View>(R.id.comapny_name_error)
        val jobError = view.findViewById<View>(R.id.job_title_error)
        val employmentError = view.findViewById<TextView>(R.id.employment_error)
        val progress = view.findViewById<View>(R.id.progress_bar)
        val chosen = arrayOfNulls<EmploymentOption>(3)

        fun showError(message: Int?) {
            employmentError.visibility = if (message == null) View.GONE else View.VISIBLE
            message?.let { employmentError.setText(it) }
        }

        fun bind(field: MaterialAutoCompleteTextView, slot: Int, options: List<EmploymentOption>, preselect: Long?) {
            field.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, options.map { it.label }))
            field.setOnItemClickListener { _, _, position, _ -> chosen[slot] = options[position] }
            options.firstOrNull { it.id == preselect }?.let {
                chosen[slot] = it
                field.setText(it.label, false)
            }
        }

        val previous = journeyData.employmentDetails
        previous?.let {
            companyName.setText(it.companyName)
            jobTitle.setText(it.jobTitle)
            startDate.setText(it.startDate)
        }
        // Same picker rules as the app: min 1980-01-01, max today, yyyy-MM-dd.
        startDate.setOnClickListener { showStartDatePicker(startDate) }

        progress.visibility = View.VISIBLE
        NanoLoanSDK.loadEmploymentOptions { result ->
            if (!isAdded) return@loadEmploymentOptions
            progress.visibility = View.GONE
            when (result) {
                is NanoLoanResult.Success -> {
                    // GET fo/companies/private, as the app's autocomplete; the field stays free text.
                    companyName.setAdapter(
                        ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, result.value.employers)
                    )
                    bind(education, 0, result.value.educationLevels, previous?.educationLevelId)
                    bind(experience, 1, result.value.workExperience, previous?.workExperienceId)
                    bind(yearsInJob, 2, result.value.yearsInCurrentJob, previous?.yearsInCurrentJobId)
                }
                is NanoLoanResult.Failure -> showError(R.string.nanoloan_employment_options_failed)
            }
        }

        val nextBtn = view.findViewById<View>(R.id.next_btn)
        NanoLoanThemeApplier.applyPrimaryButton(nextBtn, theme)
        nextBtn.setOnClickListener {
            val company = companyName.text?.toString()?.trim().orEmpty()
            val job = jobTitle.text?.toString()?.trim().orEmpty()
            companyError.visibility = if (company.isEmpty()) View.VISIBLE else View.INVISIBLE
            jobError.visibility = if (job.isEmpty()) View.VISIBLE else View.INVISIBLE
            val date = startDate.text?.toString()?.trim().orEmpty()
            dateError.visibility = if (date.isEmpty()) View.VISIBLE else View.INVISIBLE
            val (edu, exp, years) = chosen
            showError(if (edu == null || exp == null || years == null) R.string.nanoloan_employment_options_required else null)
            if (company.isEmpty() || job.isEmpty() || date.isEmpty() || edu == null || exp == null || years == null) return@setOnClickListener

            val details = EmploymentDetails(
                companyName = company,
                jobTitle = job,
                startDate = date,
                educationLevelId = edu.id,
                workExperienceId = exp.id,
                yearsInCurrentJobId = years.id
            )
            journeyData.employmentDetails = details
            progress.visibility = View.VISIBLE
            NanoLoanSDK.saveEmploymentDetails(details) { result ->
                if (!isAdded) return@saveEmploymentDetails
                progress.visibility = View.GONE
                when (result) {
                    is NanoLoanResult.Success -> journeyHost.goToSalaryVerification()
                    is NanoLoanResult.Failure -> showError(R.string.nanoloan_employment_save_failed)
                }
            }
        }
        view.findViewById<AppCompatTextView>(R.id.tv_cancel).setOnClickListener {
            journeyHost.finishJourney()
        }
    }

    private fun showStartDatePicker(target: TextInputEditText) {
        val now = Calendar.getInstance(Locale.ENGLISH)
        val dialog = DatePickerDialog(
            requireContext(),
            { _, year, month, day ->
                val selected = Calendar.getInstance(Locale.ENGLISH)
                selected.set(year, month, day)
                target.setText(SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(selected.time))
            },
            now.get(Calendar.YEAR),
            now.get(Calendar.MONTH),
            now.get(Calendar.DAY_OF_MONTH)
        )
        val min = Calendar.getInstance(Locale.ENGLISH)
        min.set(1980, 0, 1)
        dialog.datePicker.minDate = min.timeInMillis
        dialog.datePicker.maxDate = now.timeInMillis
        dialog.show()
    }

    companion object {
        const val STEP_NAME = "employment_details"
    }
}
