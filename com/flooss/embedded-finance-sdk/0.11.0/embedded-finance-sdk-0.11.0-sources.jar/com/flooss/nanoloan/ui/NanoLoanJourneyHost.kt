package com.flooss.nanoloan.ui

/**
 * Navigation + shared-state contract the journey step fragments talk to. Implemented by
 * [NanoLoanJourneySheetFragment] (the journey now presents as a bottom sheet over the
 * host app — standard embedded-finance SDK pattern — instead of a full activity).
 *
 * Step-ownership note (design doc §3.5 Options A/B, §9.5): the `goTo*` calls for the
 * ownership-configurable steps (employment details, salary verification, the email leg
 * before OTP) are where the HOST-vs-SDK switch happens — the sheet checks
 * [com.flooss.nanoloan.NanoLoanSDK.ownerOf] and either shows the SDK screen (Option A)
 * or pauses for host-collected input (Option B).
 */
internal interface NanoLoanJourneyHost {
    val journeyData: JourneyData
    fun isMockMode(): Boolean
    /** §2.2 — two-offer comparison; skipped outright when the host supplied no offer. */
    fun goToOfferComparison()

    /** §2.3 — additional KYC details, between the comparison and employment. */
    fun goToKycDetails()

    /** §2.4 — the second-phase decision against host-supplied bureau data. */
    fun goToFinalCheck()

    /** §2.6 — scroll-to-end document signature, after the acceptance OTP. */
    fun goToSignature()

    /** §2.5 — direct-debit mandate authorisation, the last step before confirmation. */
    fun goToDirectDebitMandate()

    fun goToEmploymentDetails()
    fun goToSalaryVerification()
    fun goToApplyDetail()
    fun goToOffer()
    fun goToDisbursementChannel()
    fun goToDisbursementIban()
    fun goToRejectReason()
    fun goToOtp()
    fun goToConfirmation()
    fun navigateBack()

    /** Close the journey: completed on the confirmation screen, abandoned anywhere else. */
    fun finishJourney()

    /** Close the journey with an explicit outcome. */
    fun finishJourney(status: com.flooss.nanoloan.model.JourneyStatus)

    /** The current plan step is done (a screen with no next screen of its own, e.g. the split). */
    fun completeStep()

    /** sign_in: from the mobile number to the Flooss PIN. */
    fun goToSignInPin()

    /**
     * sign_in: act on what the wallet answered. Navigates (signed in, code needed, not a
     * customer, locked) and returns null, or returns the message the current screen shows
     * inline for the customer to try again.
     */
    fun onSignInOutcome(outcome: com.flooss.nanoloan.repo.SignInOutcome): String?
}

/** Journey-scoped shared state (the real app passes CreateLoanReq/Loan around). */
internal class JourneyData {
    var loanName: String = "My Finance"
    var loanAmount: Int = DEFAULT_AMOUNT
    var loanDurationMonths: Int = DEFAULT_DURATION
    var selectedRepaymentDate: Int = 27
    var offer: com.flooss.nanoloan.model.LoanOffer? = null

    /** Products + active-loan prerequisites fired once at journey entry (§4.1 steps 2–3). */
    var prerequisitesLoaded: Boolean = false

    /** The product the amount screen loaded; the loan application requires its id. */
    var productId: Long? = null

    /** Statements stored at salary verification, referenced by the loan application. */
    var salaryDocuments: List<com.flooss.nanoloan.model.UploadedDocument> = emptyList()

    /** Screen 2/4's collected employment details (SDK- or HOST-collected). */
    var employmentDetails: com.flooss.nanoloan.model.EmploymentDetails? = null

    /** §2.2 — which side the customer picked, null until the comparison screen runs. */
    var selectedOfferSource: com.flooss.nanoloan.model.OfferSource? = null

    /** §2.3 — the additional-KYC answers (field key -> value), SDK- or HOST-collected. */
    var kycDetails: Map<String, String> = emptyMap()

    /** §2.4 — the final decision, null until the final check has run. */
    var finalDecisionApproved: Boolean? = null
    var finalDecisionReason: String? = null

    /** §2.5 — the account the mandate was authorised against, already masked. */
    var mandateMaskedAccount: String? = null

    /** §2.6 — ISO-8601 instant the agreement was signed, null until it is. */
    var agreementSignedAt: String? = null

    /** "BANK_SYNC" (Tarabut) / "DOCUMENT_UPLOAD" / "HOST_PROVIDED" / null if skipped. */
    var salaryVerificationMethod: String? = null
    var selectedBankName: String? = null
    var maskedOtpPhone: String? = null

    /** The application the offer step submitted. */
    var applicationId: Long? = null

    /** Disbursement selection (bank-IBAN path) — set by the disbursement step. */
    var disbursementIban: String? = null
    var disbursementBankName: String? = null

    companion object {
        // Canned defaults matching MockNanoLoanDataSource's nano product (300 BHD / 3 months).
        const val DEFAULT_AMOUNT = com.flooss.nanoloan.repo.MockNanoLoanDataSource.MOCK_DEFAULT_AMOUNT
        const val DEFAULT_DURATION = com.flooss.nanoloan.repo.MockNanoLoanDataSource.MOCK_DEFAULT_MONTHS
    }
}
