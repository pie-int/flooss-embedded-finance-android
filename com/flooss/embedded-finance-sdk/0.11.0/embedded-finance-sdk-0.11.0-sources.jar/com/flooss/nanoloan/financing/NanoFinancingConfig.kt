package com.flooss.nanoloan.financing

import com.flooss.nanoloan.model.DisbursementTarget
import com.flooss.nanoloan.model.FinancingOptions
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName

/**
 * `GET /v1/sdk/config` as the back office sends it. Every field is nullable because Gson
 * fills Kotlin classes without running constructors; [NanoFinancingConfig.parse] turns it
 * into the non-null model. Unknown fields are ignored, so a newer back office can add
 * settings without breaking a fielded SDK.
 */
internal data class NanoFinancingConfigDto(
    @SerializedName("schema") val schema: Int? = null,
    @SerializedName("version") val version: Int? = null,
    @SerializedName("environment") val environment: String? = null,
    @SerializedName("journeysEnabled") val journeysEnabled: Boolean? = null,
    @SerializedName("merchantCheckout") val merchantCheckout: MerchantCheckoutDto? = null,
    @SerializedName("cashLoan") val cashLoan: CashLoanDto? = null,
    @SerializedName("minSdkVersion") val minSdkVersion: String? = null,
    @SerializedName("updatedAt") val updatedAt: String? = null
) {
    data class MerchantCheckoutDto(
        @SerializedName("enabled") val enabled: Boolean? = null,
        @SerializedName("salafMerchantId") val salafMerchantId: Long? = null,
        @SerializedName("partialFinancing") val partialFinancing: Boolean? = null,
        @SerializedName("minFinancedAmount") val minFinancedAmount: Double? = null,
        @SerializedName("maxFinancedAmount") val maxFinancedAmount: Double? = null,
        @SerializedName("currency") val currency: String? = null
    )

    data class CashLoanDto(
        @SerializedName("enabled") val enabled: Boolean? = null,
        @SerializedName("disbursementTargets") val disbursementTargets: List<String>? = null
    )
}

/**
 * The partner's financing settings, normalised. A missing switch reads as OFF (fail
 * closed); a missing `disbursementTargets` list reads as both targets, because every
 * SDK before the setting existed offered both; an unknown target name is dropped.
 */
internal data class NanoFinancingConfig(
    val version: Int,
    val journeysEnabled: Boolean,
    val merchantCheckout: MerchantCheckout,
    val cashLoan: CashLoan,
    val minSdkVersion: String?,
    val updatedAt: String?
) {
    data class MerchantCheckout(
        val enabled: Boolean,
        val salafMerchantId: Long?,
        val partialFinancing: Boolean,
        val minFinancedAmount: Double?,
        val maxFinancedAmount: Double?,
        val currency: String?
    )

    data class CashLoan(
        val enabled: Boolean,
        val disbursementTargets: List<DisbursementTarget>
    )

    fun sdkUpgradeRequired(sdkVersion: String): Boolean =
        minSdkVersion?.let { NanoSdkVersion.compare(sdkVersion, it) < 0 } ?: false

    fun toOptions(sdkVersion: String): FinancingOptions = FinancingOptions(
        version = version,
        journeysEnabled = journeysEnabled,
        merchantCheckoutEnabled = merchantCheckout.enabled,
        partialFinancing = merchantCheckout.partialFinancing,
        minFinancedAmount = merchantCheckout.minFinancedAmount,
        maxFinancedAmount = merchantCheckout.maxFinancedAmount,
        currency = merchantCheckout.currency,
        cashLoanEnabled = cashLoan.enabled,
        disbursementTargets = cashLoan.disbursementTargets,
        sdkUpgradeRequired = sdkUpgradeRequired(sdkVersion)
    )

    companion object {
        private val gson = Gson()

        /** Null when [json] is not a settings object at all. */
        fun parse(json: String): NanoFinancingConfig? {
            val dto = runCatching { gson.fromJson(json, NanoFinancingConfigDto::class.java) }.getOrNull()
                ?: return null
            val checkout = dto.merchantCheckout
            val cash = dto.cashLoan
            return NanoFinancingConfig(
                version = dto.version ?: 0,
                journeysEnabled = dto.journeysEnabled ?: false,
                merchantCheckout = MerchantCheckout(
                    enabled = checkout?.enabled ?: false,
                    salafMerchantId = checkout?.salafMerchantId,
                    partialFinancing = checkout?.partialFinancing ?: false,
                    minFinancedAmount = checkout?.minFinancedAmount,
                    maxFinancedAmount = checkout?.maxFinancedAmount,
                    currency = checkout?.currency
                ),
                cashLoan = CashLoan(
                    enabled = cash?.enabled ?: false,
                    disbursementTargets = cash?.disbursementTargets
                        ?.mapNotNull { name -> DisbursementTarget.values().firstOrNull { it.name == name } }
                        ?.distinct()
                        ?: DisbursementTarget.values().toList()
                ),
                minSdkVersion = dto.minSdkVersion?.takeIf { it.isNotBlank() },
                updatedAt = dto.updatedAt
            )
        }

        /** MOCK makes no network call: every journey is open so a host can build against it. */
        val mockAllEnabled = NanoFinancingConfig(
            version = 0,
            journeysEnabled = true,
            merchantCheckout = MerchantCheckout(
                enabled = true,
                salafMerchantId = null,
                partialFinancing = true,
                minFinancedAmount = null,
                maxFinancedAmount = null,
                currency = "BHD"
            ),
            cashLoan = CashLoan(enabled = true, disbursementTargets = DisbursementTarget.values().toList()),
            minSdkVersion = null,
            updatedAt = null
        )
    }
}

/** Dotted numeric versions: `0.10.0` < `0.11.0`; a missing part is 0; a `-suffix` is ignored. */
internal object NanoSdkVersion {
    fun compare(a: String, b: String): Int {
        val left = parts(a)
        val right = parts(b)
        for (i in 0 until maxOf(left.size, right.size)) {
            val diff = left.getOrElse(i) { 0 }.compareTo(right.getOrElse(i) { 0 })
            if (diff != 0) return diff
        }
        return 0
    }

    private fun parts(version: String): List<Int> =
        version.trim().removePrefix("v").substringBefore('-').substringBefore('+')
            .split('.')
            .map { part -> part.takeWhile { it.isDigit() }.toIntOrNull() ?: 0 }
}
