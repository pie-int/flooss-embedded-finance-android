package com.flooss.nanoloan.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.model.BureauInput
import com.flooss.nanoloan.model.FinalCheckResult
import com.flooss.nanoloan.result.NanoLoanResult

/**
 * SDK_V3_PRODUCT_GAPS §2.4 — phase two of the two-phase decision. Runs
 * [NanoLoanSDK.submitFinalCheck] against the bureau material the HOST supplied, shows a
 * "running final check" state while it does, then the outcome: approved with the amount
 * and terms actually approved, or declined with a coded reason.
 *
 * The BCRB notice is on screen in every state. Final approval sits with the host's latest
 * BCRB document, not with this SDK, and the screen says so rather than presenting the
 * decision as the SDK's own.
 */
internal class NanoLoanFinalCheckFragment : NanoLoanJourneyFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_final_check, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme

        setUpHeader(
            headerRoot = view.findViewById(R.id.header),
            title = getString(R.string.nanoloan_final_check_running),
            dotCount = 4,
            dotIndex = 4,
            screenNumber = "10/12",
            // MOCK-only Skip, like every other step.
            stepName = STEP_NAME
        ) {
            journeyHost.goToSignature()
        }
        NanoLoanThemeApplier.applyChromeBackground(view.findViewById(R.id.rootLayout), theme)

        if (journeyData.finalDecisionApproved != null) {
            // Returning to the screen (back stack) — do not re-run a credit decision.
            render(view, cachedResult())
            return
        }
        NanoLoanSDK.submitFinalCheck(NanoLoanSDK.currentBureauInput()) { result ->
            if (!isAdded) return@submitFinalCheck
            when (result) {
                is NanoLoanResult.Success -> {
                    journeyData.finalDecisionApproved = result.value.approved
                    journeyData.finalDecisionReason = result.value.reasonCode
                    render(view, result.value)
                }
                // A failed call is NOT a decline: the decision simply did not happen.
                // Saying "not approved" here would report a credit decision that was
                // never made.
                is NanoLoanResult.Failure -> renderUnavailable(view, result.error.message)
            }
        }
    }

    private fun cachedResult(): FinalCheckResult = FinalCheckResult(
        approved = journeyData.finalDecisionApproved == true,
        reasonCode = journeyData.finalDecisionReason
    )

    private fun render(view: View, result: FinalCheckResult) {
        val theme = NanoLoanSDK.currentConfiguration().theme
        // The header carried the running state; once the decision is in it must say so.
        view.findViewById<View>(R.id.header).findViewById<TextView>(R.id.header_name).text =
            getString(
                if (result.approved) R.string.nanoloan_final_check_approved
                else R.string.nanoloan_final_check_declined
            )
        view.findViewById<View>(R.id.state_running).visibility = View.GONE
        view.findViewById<View>(R.id.state_outcome).visibility = View.VISIBLE

        val title = view.findViewById<TextView>(R.id.outcome_title)
        val message = view.findViewById<TextView>(R.id.outcome_message)
        val amount = view.findViewById<TextView>(R.id.outcome_amount)
        val reason = view.findViewById<TextView>(R.id.outcome_reason)
        val terms = view.findViewById<RecyclerView>(R.id.outcome_terms_rv)
        val button = view.findViewById<View>(R.id.final_check_btn)

        if (result.approved) {
            title.text = getString(R.string.nanoloan_final_check_approved)
            message.text = getString(R.string.nanoloan_final_check_approved_detail)
            amount.visibility = View.VISIBLE
            amount.text = formatBhd(result.approvedAmountFils)
            reason.visibility = View.GONE
            terms.visibility = View.VISIBLE
            terms.adapter = LoanDetailRowsAdapter(approvedTermRows(result))
            terms.layoutManager = LinearLayoutManager(requireContext())
            (button as TextView).text = getString(R.string.next)
            button.setOnClickListener { journeyHost.goToSignature() }
        } else {
            title.text = getString(R.string.nanoloan_final_check_declined)
            message.text = getString(R.string.nanoloan_final_check_declined_detail)
            amount.visibility = View.GONE
            terms.visibility = View.GONE
            reason.visibility = View.VISIBLE
            reason.text = getString(
                R.string.nanoloan_final_check_reason,
                result.reasonMessage.orEmpty(),
                result.reasonCode.orEmpty()
            )
            (button as TextView).text = getString(R.string.nanoloan_close)
            button.setOnClickListener { journeyHost.finishJourney(com.flooss.nanoloan.model.JourneyStatus.NOT_APPROVED) }
        }
        button.visibility = View.VISIBLE
        NanoLoanThemeApplier.applyPrimaryButton(button, theme)
    }

    /**
     * The check could not run at all (no backend endpoint outside MOCK). Reported as
     * unavailable, never as a decline.
     */
    private fun renderUnavailable(view: View, detail: String?) {
        view.findViewById<View>(R.id.state_running).visibility = View.GONE
        view.findViewById<View>(R.id.state_outcome).visibility = View.VISIBLE
        view.findViewById<TextView>(R.id.outcome_title).text =
            getString(R.string.nanoloan_final_check_running)
        view.findViewById<TextView>(R.id.outcome_message).text = detail.orEmpty()
        view.findViewById<View>(R.id.outcome_amount).visibility = View.GONE
        view.findViewById<View>(R.id.outcome_terms_rv).visibility = View.GONE
        val button = view.findViewById<TextView>(R.id.final_check_btn)
        button.text = getString(R.string.nanoloan_close)
        button.visibility = View.VISIBLE
        button.setOnClickListener { journeyHost.finishJourney() }
        NanoLoanThemeApplier.applyPrimaryButton(button, NanoLoanSDK.currentConfiguration().theme)
    }

    private fun approvedTermRows(result: FinalCheckResult): List<KeyValueRow> = buildList {
        result.tenorMonths?.let {
            add(KeyValueRow(getString(R.string.duration), "$it ${getString(R.string.nanoloan_month_plural)}"))
        }
        result.monthlyInstalmentFils?.let {
            add(KeyValueRow(getString(R.string.monthly_installment), formatBhd(it)))
        }
        result.totalPayableFils?.let {
            add(KeyValueRow(getString(R.string.total_amount_to_pay), formatBhd(it)))
        }
    }

    private fun formatBhd(fils: Long?): String =
        if (fils == null) " "
        else NanoLoanMath.formatDouble(fils.toDouble() / FILS_PER_DINAR) +
            " " + getString(R.string.bhd_app_text)

    companion object {
        const val STEP_NAME = "final_check"
        private const val FILS_PER_DINAR = 1000L
    }
}
