package com.flooss.nanoloan.journey

import com.flooss.nanoloan.telemetry.NanoTelemetryBackoff
import com.google.gson.JsonObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.math.BigDecimal

/** The back office's PATCH `status` values. */
internal enum class JourneyPatchStatus { STEP_COMPLETED, COMPLETED, FAILED, ABANDONED }

internal data class JourneyPatchResult(
    val financedAmount: BigDecimal? = null,
    val remainderAmount: BigDecimal? = null,
    val applicationId: Long? = null,
    val merchantTransactionRef: String? = null,
    val salafStatus: String? = null,
    val errorCode: String? = null
)

/** Progress reports to the back office. Fire-and-forget: nothing here may stop a journey. */
internal interface JourneyReporter {
    fun report(step: String, status: JourneyPatchStatus, result: JourneyPatchResult? = null)
}

internal object NoopJourneyReporter : JourneyReporter {
    override fun report(step: String, status: JourneyPatchStatus, result: JourneyPatchResult?) = Unit
}

/**
 * Sends the PATCHes in order on [scope], retrying a transport failure, 429 or 5xx with
 * the telemetry backoff, and dropping one the server rejects (4xx) or that still fails
 * after [MAX_ATTEMPTS]. [report] only enqueues, so the customer never waits on it.
 */
internal class QueuedJourneyReporter(
    private val api: NanoJourneyApi,
    private val journeyId: String,
    scope: CoroutineScope,
    private val sleep: suspend (Long) -> Unit = { delay(it) },
    private val log: (String) -> Unit = {}
) : JourneyReporter {

    private val queue = Channel<String>(Channel.UNLIMITED)

    /** Set once the back office says the journey is closed, unknown or the step is not in it. */
    @Volatile private var closed = false

    init {
        scope.launch {
            for (body in queue) send(body)
        }
    }

    override fun report(step: String, status: JourneyPatchStatus, result: JourneyPatchResult?) {
        queue.trySend(body(step, status, result))
    }

    private suspend fun send(body: String) {
        if (closed) return
        for (attempt in 0 until MAX_ATTEMPTS) {
            val outcome = try {
                api.patch(journeyId, body)
            } catch (t: Throwable) {
                PatchSendResult.RETRYABLE
            }
            when (outcome) {
                PatchSendResult.SENT -> return
                PatchSendResult.REJECTED -> {
                    log("journey $journeyId progress rejected by the back office; dropped")
                    return
                }
                PatchSendResult.JOURNEY_CLOSED -> {
                    closed = true
                    log("journey $journeyId is closed or unknown to the back office; no more progress is sent")
                    return
                }
                PatchSendResult.RETRYABLE ->
                    if (attempt < MAX_ATTEMPTS - 1) sleep(NanoTelemetryBackoff.retryDelayMillis(attempt, null))
            }
        }
        log("journey $journeyId progress not delivered after $MAX_ATTEMPTS attempts; dropped")
    }

    companion object {
        const val MAX_ATTEMPTS = 5

        fun body(step: String, status: JourneyPatchStatus, result: JourneyPatchResult?): String =
            JsonObject().apply {
                addProperty("step", step)
                addProperty("status", status.name)
                result?.let { r ->
                    add("result", JsonObject().apply {
                        r.financedAmount?.let { addProperty("financedAmount", it) }
                        r.remainderAmount?.let { addProperty("remainderAmount", it) }
                        // The contract takes the application id as an opaque string.
                        r.applicationId?.let { addProperty("applicationId", it.toString()) }
                        r.merchantTransactionRef?.let { addProperty("merchantTransactionRef", it) }
                        r.salafStatus?.let { addProperty("salafStatus", it) }
                        r.errorCode?.let { addProperty("errorCode", it) }
                    })
                }
            }.toString()
    }
}
