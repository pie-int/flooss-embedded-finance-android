package com.flooss.nanoloan.journey

import com.flooss.nanoloan.model.DisbursementTarget
import com.flooss.nanoloan.model.JourneyIntent
import com.flooss.nanoloan.model.JourneyMode
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.math.BigDecimal
import java.util.UUID

/** Step types of the back office's journey plan, and the ones this build can run. */
internal object JourneySteps {
    const val SIGN_IN = "sign_in"
    const val ELIGIBILITY = "eligibility"
    const val AMOUNT_DURATION = "amount_duration"
    const val EMPLOYMENT = "employment"
    const val SALARY = "salary"
    const val DISBURSEMENT = "disbursement"
    const val OFFER = "offer"
    const val ACCEPT = "accept"
    const val DONE = "done"
    const val FINANCING_SPLIT = "financing_split"
    const val MERCHANT_OFFER = "merchant_offer"
    const val MERCHANT_AGREEMENT = "merchant_agreement"
    const val CHECKOUT_CODE = "checkout_code"

    /**
     * Sent as `capabilities`, so the back office denies a journey this build cannot run.
     * The merchant offer, agreement and checkout-code steps are not built yet.
     */
    val CAPABILITIES: List<String> = listOf(
        SIGN_IN, ELIGIBILITY, FINANCING_SPLIT, AMOUNT_DURATION, EMPLOYMENT, SALARY,
        OFFER, DISBURSEMENT, ACCEPT, DONE
    )

    /** Steps that run without a screen. */
    val HEADLESS: Set<String> = setOf(SIGN_IN, ELIGIBILITY)
}

/** Rev 1.7 §V: a step param with this value means "the amount the SDK financed". */
internal const val FINANCED_AMOUNT_PLACEHOLDER = "{{financedAmount}}"

internal data class PlanStep(val type: String, val params: JsonObject = JsonObject()) {

    /** This step with every [FINANCED_AMOUNT_PLACEHOLDER] param replaced by [financedAmount]. */
    fun resolved(financedAmount: BigDecimal?): PlanStep {
        val placeholders = params.entrySet().filter { (_, v) -> v.stringOrNull() == FINANCED_AMOUNT_PLACEHOLDER }
        if (placeholders.isEmpty() || financedAmount == null) return this
        val copy = params.deepCopy()
        placeholders.forEach { (key, _) -> copy.addProperty(key, financedAmount) }
        return copy(params = copy)
    }

    fun long(name: String): Long? =
        params.get(name)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asLong

    fun targets(): List<DisbursementTarget>? = params.array("targets")?.mapNotNull { element ->
        element.stringOrNull()?.let { name -> DisbursementTarget.values().firstOrNull { it.name == name } }
    }

    fun decimal(name: String): BigDecimal? = params.decimal(name)
    fun bool(name: String): Boolean? = params.get(name)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean }?.asBoolean
}

internal data class JourneyLimits(val min: BigDecimal?, val max: BigDecimal?, val partialFinancing: Boolean)

/**
 * `POST /v1/sdk/journeys` 201, normalised. Unknown fields are ignored. A plan that is
 * ALLOWED but names a step type or mode this build does not know is refused locally as
 * [missingCapabilities], exactly as the back office would have refused it.
 */
internal data class JourneyPlan(
    val journeyId: String,
    val allowed: Boolean,
    /** The back office allowed it, but this build cannot run it. */
    val refusedLocally: Boolean,
    /** A known deny code, or [com.flooss.nanoloan.result.NanoLoanError.JourneyNotEnabled.JOURNEY_DENIED]. */
    val reason: String?,
    val missingCapabilities: List<String>,
    /** The reason's other params (`minSdkVersion`, `min`, `max`; `code` when the code was unknown). */
    val reasonParams: Map<String, String>,
    val mode: JourneyMode?,
    val amount: BigDecimal?,
    val currency: String,
    val limits: JourneyLimits,
    val steps: List<PlanStep>,
    val texts: Map<String, String>,
    val configVersion: Int?,
    val expiresAt: String?
) {
    companion object {
        fun parse(json: String): JourneyPlan? {
            val root = runCatching { JsonParser.parseString(json) }.getOrNull()
                ?.takeIf { it.isJsonObject }?.asJsonObject ?: return null
            val journeyId = root.string("journeyId") ?: return null
            val allowed = root.string("decision") == "ALLOWED"
            val rawMode = root.string("mode")
            val mode = rawMode?.let { name -> JourneyMode.values().firstOrNull { it.name == name } }
            val steps = root.array("steps")?.mapNotNull { element ->
                val obj = element.takeIf { it.isJsonObject }?.asJsonObject ?: return@mapNotNull null
                val type = obj.string("type") ?: return@mapNotNull null
                PlanStep(type, obj.get("params")?.takeIf { it.isJsonObject }?.asJsonObject ?: JsonObject())
            }.orEmpty()
            val limitsObj = root.get("limits")?.takeIf { it.isJsonObject }?.asJsonObject
            val serverReason = parseReason(root.get("reason"), denied = !allowed)

            var missing = serverReason.missing
            var reason = serverReason.code
            var isAllowed = allowed
            if (allowed) {
                val unknown = steps.map { it.type }.filter { it !in JourneySteps.CAPABILITIES }.distinct()
                val misordered = disbursementBeforeOffer(steps)
                if (unknown.isNotEmpty() || mode == null || misordered) {
                    isAllowed = false
                    reason = com.flooss.nanoloan.result.NanoLoanError.JourneyNotEnabled.SDK_UPGRADE_REQUIRED
                    missing = unknown +
                        listOfNotNull(rawMode?.takeIf { mode == null }?.let { "mode:$it" }) +
                        listOfNotNull(DISBURSEMENT_BEFORE_OFFER.takeIf { misordered })
                }
            }
            return JourneyPlan(
                journeyId = journeyId,
                allowed = isAllowed,
                refusedLocally = allowed && !isAllowed,
                reason = reason,
                missingCapabilities = missing,
                reasonParams = serverReason.params,
                mode = mode,
                amount = root.decimal("amount"),
                currency = root.string("currency") ?: "BHD",
                limits = JourneyLimits(
                    min = limitsObj?.decimal("min"),
                    max = limitsObj?.decimal("max"),
                    partialFinancing = limitsObj?.get("partialFinancing")
                        ?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isBoolean }?.asBoolean ?: false
                ),
                steps = steps,
                texts = root.get("texts")?.takeIf { it.isJsonObject }?.asJsonObject?.entrySet()
                    ?.mapNotNull { (k, v) -> v.stringOrNull()?.let { k to it } }?.toMap().orEmpty(),
                configVersion = root.get("configVersion")?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isNumber }?.asInt,
                expiresAt = root.string("expiresAt")
            )
        }

        private class Reason(val code: String?, val missing: List<String>, val params: Map<String, String>)

        /**
         * Rev 1.7 §V: `reason` is `{code, params}` or null. A code this build does not know
         * reads as [JOURNEY_DENIED][com.flooss.nanoloan.result.NanoLoanError.JourneyNotEnabled.JOURNEY_DENIED]
         * with the original under `params["code"]`; a bare string is accepted the same way.
         */
        private fun parseReason(element: JsonElement?, denied: Boolean): Reason {
            val obj = element?.takeIf { it.isJsonObject }?.asJsonObject
            val rawCode = obj?.string("code") ?: element?.stringOrNull()
            val params = obj?.get("params")?.takeIf { it.isJsonObject }?.asJsonObject
            val missing = params?.array("missing")?.mapNotNull { it.stringOrNull() }.orEmpty()
            val other = params?.entrySet()
                ?.filter { (key, value) -> key != "missing" && value.isJsonPrimitive }
                ?.associate { (key, value) -> key to value.asString }
                .orEmpty()
            val known = rawCode?.takeIf { it in KNOWN_DENY_CODES }
            return when {
                known != null -> Reason(known, missing, other)
                !denied -> Reason(null, missing, other)
                else -> Reason(
                    com.flooss.nanoloan.result.NanoLoanError.JourneyNotEnabled.JOURNEY_DENIED,
                    missing,
                    other + listOfNotNull(rawCode?.let { "code" to it })
                )
            }
        }

        private val KNOWN_DENY_CODES = with(com.flooss.nanoloan.result.NanoLoanError.JourneyNotEnabled) {
            setOf(JOURNEYS_DISABLED, SDK_UPGRADE_REQUIRED, MODE_DISABLED, AMOUNT_REQUIRED, AMOUNT_BELOW_MIN, AMOUNT_ABOVE_MAX)
        }

        /**
         * Named in `missingCapabilities` for a plan whose disbursement comes before its
         * offer: the disbursement screens confirm the payout against the application the
         * offer step creates, so this build cannot run that order. Refused, never reordered.
         */
        const val DISBURSEMENT_BEFORE_OFFER = "order:disbursement_before_offer"

        fun disbursementBeforeOffer(steps: List<PlanStep>): Boolean {
            val disbursement = steps.indexOfFirst { it.type == JourneySteps.DISBURSEMENT }
            val offer = steps.indexOfFirst { it.type == JourneySteps.OFFER }
            return disbursement >= 0 && offer >= 0 && disbursement < offer
        }

        /**
         * MOCK: no network, so the plan is made here from the intent, the way the back
         * office would for a partner with everything enabled. AUTO resolves to a cash
         * loan. A merchant checkout gets the merchant steps, which this build cannot run,
         * so it is refused with SDK_UPGRADE_REQUIRED exactly as the back office would.
         */
        fun mock(intent: JourneyIntent, amount: BigDecimal?, currency: String): JourneyPlan {
            val merchant = intent == JourneyIntent.MERCHANT_CHECKOUT
            val steps = if (merchant) {
                listOf(
                    PlanStep(JourneySteps.SIGN_IN),
                    PlanStep(JourneySteps.ELIGIBILITY),
                    PlanStep(JourneySteps.FINANCING_SPLIT),
                    PlanStep(JourneySteps.EMPLOYMENT),
                    PlanStep(JourneySteps.SALARY),
                    PlanStep(JourneySteps.MERCHANT_OFFER),
                    PlanStep(JourneySteps.MERCHANT_AGREEMENT),
                    PlanStep(JourneySteps.CHECKOUT_CODE, JsonObject().apply { addProperty("amount", FINANCED_AMOUNT_PLACEHOLDER) }),
                    PlanStep(JourneySteps.DONE)
                )
            } else {
                listOf(
                    PlanStep(JourneySteps.SIGN_IN),
                    PlanStep(JourneySteps.ELIGIBILITY),
                    PlanStep(JourneySteps.AMOUNT_DURATION),
                    PlanStep(JourneySteps.EMPLOYMENT),
                    PlanStep(JourneySteps.SALARY),
                    PlanStep(JourneySteps.OFFER),
                    PlanStep(JourneySteps.DISBURSEMENT, JsonObject().apply {
                        add("targets", JsonArray().apply { DisbursementTarget.values().forEach { add(it.name) } })
                    }),
                    PlanStep(JourneySteps.ACCEPT),
                    PlanStep(JourneySteps.DONE)
                )
            }
            val json = JsonObject().apply {
                addProperty("schema", 1)
                addProperty("journeyId", "mock-" + UUID.randomUUID())
                addProperty("decision", "ALLOWED")
                addProperty("mode", if (merchant) JourneyMode.MERCHANT_CHECKOUT.name else JourneyMode.CASH_LOAN.name)
                amount?.let { addProperty("amount", it) }
                addProperty("currency", currency)
                add("limits", JsonObject().apply {
                    addProperty("min", 50)
                    addProperty("max", 3000)
                    addProperty("partialFinancing", true)
                })
                add("steps", JsonArray().apply {
                    steps.forEach { step ->
                        add(JsonObject().apply { addProperty("type", step.type); add("params", step.params) })
                    }
                })
                addProperty("configVersion", 0)
            }
            return requireNotNull(parse(json.toString()))
        }
    }
}

private fun JsonObject.string(name: String): String? = get(name)?.stringOrNull()

private fun JsonObject.array(name: String): JsonArray? = get(name)?.takeIf { it.isJsonArray }?.asJsonArray

private fun JsonObject.decimal(name: String): BigDecimal? =
    get(name)?.takeIf { it.isJsonPrimitive }?.let { runCatching { it.asBigDecimal }.getOrNull() }

private fun JsonElement.stringOrNull(): String? =
    takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }?.asString
