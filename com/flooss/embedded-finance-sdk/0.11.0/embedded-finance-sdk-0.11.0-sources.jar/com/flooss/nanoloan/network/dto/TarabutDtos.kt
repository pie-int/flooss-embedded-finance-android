package com.flooss.nanoloan.network.dto

/**
 * Wire shapes of the Tarabut (open banking) trio, field-for-field mirrors of the app's
 * DTOs:
 * - `GET api/v1/fo/tarabut/providers` -> `BanksListRes` (`data: [BankModel]`)
 * - `POST api/v1/fo/tarabut/intent`   -> req `TarabutTokenRequest`, res `TarabutTokenResponse`
 * - `POST api/v1/fo/tarabut/accounts/sync` -> `TarabutSyncResponse`
 * (`data/model/api/response/BanksListRes.kt`, `TarabutTokenResponse.kt`,
 * `TarabutSyncResponse.kt`, `data/model/api/request/TarabutTokenRequest.kt`)
 */
data class BanksListResponseDto(
    val data: List<BankProviderDto> = emptyList()
)

data class BankProviderDto(
    val providerId: String = "",
    val name: String = "",
    val displayName: String = "",
    val logoUrl: String = "",
    val countryCode: String = "",
    val status: String = ""
)

data class TarabutTokenRequestDto(
    val providerId: String? = null,
    val mobileType: String = "ANDROID"
)

data class TarabutTokenResponseDto(
    val data: TarabutTokenDataDto? = null
)

data class TarabutTokenDataDto(
    val connectUrl: String = "",
    val intentId: String = "",
    val expiry: String = ""
)

data class TarabutSyncResponseDto(
    val message: String?,
    val status: Boolean
)
