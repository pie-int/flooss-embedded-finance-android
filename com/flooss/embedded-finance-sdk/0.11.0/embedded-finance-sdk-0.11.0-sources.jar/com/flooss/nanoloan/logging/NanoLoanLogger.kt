package com.flooss.nanoloan.logging

/**
 * Internal multicast logger. Fans a log line out to every configured [NanoLogSink],
 * gated by the configured minimum [NanoLogLevel] (default WARNING per design doc §11).
 * Ships with zero sinks by default — silence, not a bundled vendor logger.
 */
internal class NanoLoanLogger(
    private var minLevel: NanoLogLevel,
    private var sinks: List<NanoLogSink>
) {
    fun update(minLevel: NanoLogLevel, sinks: List<NanoLogSink>) {
        this.minLevel = minLevel
        this.sinks = sinks
    }

    fun log(level: NanoLogLevel, tag: String, message: String, throwable: Throwable? = null) {
        if (level == NanoLogLevel.NONE) return
        if (level.ordinal > minLevel.ordinal) return
        sinks.forEach { it.onLog(level, tag, message, throwable) }
    }

    fun e(tag: String, message: String, throwable: Throwable? = null) = log(NanoLogLevel.ERROR, tag, message, throwable)
    fun w(tag: String, message: String) = log(NanoLogLevel.WARNING, tag, message)
    fun i(tag: String, message: String) = log(NanoLogLevel.INFO, tag, message)
    fun d(tag: String, message: String) = log(NanoLogLevel.DEBUG, tag, message)
}
