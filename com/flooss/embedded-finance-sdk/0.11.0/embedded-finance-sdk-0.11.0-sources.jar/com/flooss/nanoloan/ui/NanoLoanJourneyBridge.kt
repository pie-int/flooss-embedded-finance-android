package com.flooss.nanoloan.ui

import androidx.fragment.app.FragmentActivity
import com.flooss.nanoloan.journey.CustomerStatusScreen
import com.flooss.nanoloan.journey.JourneyContext
import com.flooss.nanoloan.journey.JourneyScreens
import com.flooss.nanoloan.journey.JourneySteps
import com.flooss.nanoloan.journey.PlanStep
import com.flooss.nanoloan.journey.StepOutcome
import com.flooss.nanoloan.model.JourneyStatus
import kotlinx.coroutines.CompletableDeferred
import java.lang.ref.WeakReference
import java.math.RoundingMode

/**
 * Connects the journey engine to the bottom sheet. The engine asks for a step; the
 * bridge shows its first screen and suspends until the sheet reports that the customer
 * left the step (moved on, went back, or ended the journey).
 *
 * Owned by the running journey, not by the sheet, so a recreated sheet (rotation)
 * re-attaches and the journey's data survives it.
 */
internal class NanoLoanJourneyBridge(activity: FragmentActivity?) : JourneyScreens {

    private val activityRef = WeakReference(activity)
    val journeyData = JourneyData()

    var context: JourneyContext? = null
        private set
    var currentStep: PlanStep? = null
        private set

    private var pending: CompletableDeferred<StepOutcome>? = null
    private var sheet: NanoLoanJourneySheetFragment? = null
    private var sheetRequested = false

    /** The SDK's own sign-in while it runs: the mobile number and, between screens, the PIN. */
    var signIn: SignInSession? = null
        private set

    /** The customer-status screen the sign_in step is showing, or null for its sign-in screens. */
    var statusScreen: CustomerStatusScreen? = null
        private set

    override suspend fun run(step: PlanStep, context: JourneyContext, resume: Boolean): StepOutcome {
        statusScreen = null
        if (!resume) prefill(step, context)
        return show(step, context, resume)
    }

    override suspend fun signIn(step: PlanStep, context: JourneyContext): StepOutcome {
        val session = SignInSession(NanoLoanSignInMobileFragment.normalizeMobile(context.request.mobileNumber))
        signIn = session
        statusScreen = null
        return try {
            show(step, context, resume = false)
        } finally {
            session.clearPin()
        }
    }

    override suspend fun customerStatus(step: PlanStep, context: JourneyContext, screen: CustomerStatusScreen): StepOutcome {
        statusScreen = screen
        return show(step, context, resume = false)
    }

    private suspend fun show(step: PlanStep, context: JourneyContext, resume: Boolean): StepOutcome {
        this.context = context
        currentStep = step
        val deferred = CompletableDeferred<StepOutcome>()
        pending = deferred
        if (!resume) {
            val attached = sheet
            when {
                attached != null && attached.view != null -> attached.showStep(step)
                // Requested, view not created yet: the sheet shows currentStep when it is.
                sheetRequested -> Unit
                !presentSheet() -> return StepOutcome.Ended(JourneyStatus.ABANDONED)
            }
        }
        return deferred.await()
    }

    private fun prefill(step: PlanStep, context: JourneyContext) {
        if (step.type == JourneySteps.OFFER) {
            // Sign-in found an offer already waiting: the offer step starts from it.
            context.resumedOffer?.takeIf { journeyData.offer == null }?.let { offer ->
                journeyData.offer = offer
                journeyData.applicationId = offer.id
            }
        }
        if (step.type != JourneySteps.AMOUNT_DURATION) return
        (context.financedAmount ?: context.requestedAmount)
            ?.setScale(0, RoundingMode.DOWN)?.toInt()?.takeIf { it > 0 }
            ?.let { journeyData.loanAmount = it }
    }

    private fun presentSheet(): Boolean {
        val activity = activityRef.get() ?: return false
        if (activity.isFinishing || activity.isDestroyed || activity.supportFragmentManager.isStateSaved) return false
        sheetRequested = true
        NanoLoanJourneySheetFragment().show(activity.supportFragmentManager, NanoLoanJourneySheetFragment.TAG)
        return true
    }

    /** @param fresh a new sheet, not one restored after rotation: show the current step. */
    fun attach(sheet: NanoLoanJourneySheetFragment, fresh: Boolean) {
        this.sheet = sheet
        if (fresh) currentStep?.let { sheet.showStep(it) }
    }

    fun detach(sheet: NanoLoanJourneySheetFragment) {
        if (this.sheet === sheet) this.sheet = null
    }

    /** The customer finished the current step. */
    fun stepLeft() {
        sync(acceptPassed = currentStep?.type == JourneySteps.ACCEPT || currentStep?.type == JourneySteps.DONE)
        pending?.complete(StepOutcome.Completed)
    }

    /** Back navigation revealed a screen of an earlier step of type [type]. */
    fun backTo(type: String) {
        pending?.complete(StepOutcome.Back(type))
    }

    fun end(status: JourneyStatus) {
        sync(acceptPassed = status == JourneyStatus.COMPLETED)
        pending?.complete(StepOutcome.Ended(status))
    }

    fun sheetDismissed() {
        sheet = null
        sheetRequested = false
        signIn?.clearPin()
        pending?.complete(StepOutcome.Ended(JourneyStatus.ABANDONED))
    }

    /** The engine is done: take the sheet down if it is still up. */
    fun close() {
        sheet?.dismissForEngine()
        sheet = null
    }

    private fun sync(acceptPassed: Boolean) {
        val context = context ?: return
        journeyData.applicationId?.let { context.applicationId = it }
        if (acceptPassed) {
            journeyData.offer?.let { offer ->
                offer.loanAmount?.let { if (context.split == null) context.financedAmount = it }
                context.salafStatus = offer.status.name
            }
        }
    }
}

/**
 * One run of the SDK's sign-in. The PIN is held only between the PIN screen and the end of
 * the sign-in (the wallet asks for it again after a new device's SMS code), as a CharArray
 * that [clearPin] wipes. It is never logged and never leaves the SDK.
 */
internal class SignInSession(var mobileNumber: String) {
    var pin: CharArray? = null
        private set

    /** Where the wallet sent the code, already masked. */
    var maskedPhone: String? = null

    fun holdPin(value: CharArray) {
        if (pin !== value) clearPin()
        pin = value
    }

    fun clearPin() {
        pin?.fill('\u0000')
        pin = null
    }

    override fun toString(): String = "SignInSession(mobileNumber=•••, pin=•••)"
}
