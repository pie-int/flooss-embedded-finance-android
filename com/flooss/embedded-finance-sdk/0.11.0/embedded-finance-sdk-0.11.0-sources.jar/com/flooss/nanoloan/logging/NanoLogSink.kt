package com.flooss.nanoloan.logging

/**
 * Host-implemented log sink (design doc §11 — multicast `NanoLogSink`, no bundled
 * analytics/monitoring vendor). The SDK never logs directly to `android.util.Log` or a
 * vendor SDK; it only ever calls into sinks the host supplied via
 * [com.flooss.nanoloan.config.NanoLoanConfiguration.logSinks].
 */
fun interface NanoLogSink {
    fun onLog(level: NanoLogLevel, tag: String, message: String, throwable: Throwable?)
}
