package com.flooss.nanoloan.model

import java.math.BigDecimal

/**
 * Public response model for [com.flooss.nanoloan.NanoLoanSDK.submitLoanApplication].
 * A trimmed subset of the app's ~100-field `Loan` DTO
 * (`data/model/api/response/Loan.kt`) — real field names kept for every field this POC
 * surfaces. Backed by the real `POST api/v1/fo/loans` endpoint
 * (`WebServiceConstants.CREATE_LOAN`, `LoanApi.create`).
 */
data class LoanApplicationResult(
    val id: Long,
    val guid: String?,
    val status: LoanStatus,
    val loanAmount: BigDecimal?,
    val period: Long?,
    val periodType: PeriodType?,
    val anyActiveOfferExists: Boolean
)
