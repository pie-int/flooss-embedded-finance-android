package com.flooss.nanoloan.ui

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.ui.widget.LoanProgressIndicator

/**
 * Shared plumbing for the ported real-screen fragments: header wiring (title, step
 * dots, back button) exactly as the real fragments do it, plus the SDK-only demo-mode
 * Skip affordance (task step 4) and NanoLoanTheme application (task step 5).
 *
 * The steps now run inside [NanoLoanJourneySheetFragment]'s child fragment manager
 * (bottom-sheet presentation), so navigation goes through [NanoLoanJourneyHost].
 */
internal abstract class NanoLoanJourneyFragment : Fragment() {

    protected val journeyHost: NanoLoanJourneyHost
        get() = requireParentFragment() as NanoLoanJourneyHost

    protected val journeyData: JourneyData
        get() = journeyHost.journeyData

    /**
     * The sheet dialog's context carries the NanoLoanLocale resource configuration; the
     * fragment's own context is the host ACTIVITY, so every getString()/resources lookup
     * in code (header titles, row labels) resolved in the host's language while the
     * inflated layouts were Arabic. Resolving through the sheet's context fixes both.
     */
    override fun getContext(): Context? {
        val base = super.getContext() ?: return null
        val sheet = parentFragment as? NanoLoanJourneySheetFragment
        return sheet?.dialog?.context ?: base
    }

    /**
     * The host app's theme is unknown (it may not even be a MaterialComponents theme),
     * so the step fragments must inflate with the sheet dialog's own context — it
     * carries Theme.NanoLoanSheet plus the NanoLoanLocale-driven resource configuration.
     */
    override fun onGetLayoutInflater(savedInstanceState: Bundle?): LayoutInflater {
        val inflater = super.onGetLayoutInflater(savedInstanceState)
        val sheet = parentFragment
        return if (sheet is NanoLoanJourneySheetFragment) {
            inflater.cloneInContext(sheet.requireDialog().context)
        } else {
            inflater
        }
    }

    /**
     * A code field: the keyboard's action key presses [submit], and the keyboard goes away
     * once [length] characters are in, so the button under it can be reached.
     */
    protected fun submitOnDone(field: android.widget.EditText, length: Int, submit: View) {
        field.setOnEditorActionListener { _, _, _ ->
            if (submit.isEnabled) submit.performClick()
            true
        }
        field.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if ((s?.length ?: 0) >= length) {
                    val imm = field.context.getSystemService(Context.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
                    imm?.hideSoftInputFromWindow(field.windowToken, 0)
                }
            }
        })
    }

    /**
     * @param stepName name emitted in [com.flooss.nanoloan.listener.NanoLoanEvent.StepSkipped]
     * @param onSkip demo-mode Skip action; null hides Skip even in MOCK mode
     */
    protected fun setUpHeader(
        headerRoot: View,
        title: String,
        dotCount: Int,
        dotIndex: Int,
        screenNumber: String,
        stepName: String,
        onSkip: (() -> Unit)?
    ) {
        // Single funnel for the contract's `step_entered`/`step_completed` telemetry —
        // every ported screen already routes its header through here with its step name.
        NanoLoanSDK.notifyStepEntered(stepName)

        val headerName = headerRoot.findViewById<TextView>(R.id.header_name)
        headerName.text = title
        headerName.setTextAppearance(R.style.CustomHeaderTextStyle)
        headerRoot.findViewById<LoanProgressIndicator>(R.id.screen_indicator)
            .setDots(dotCount, dotIndex)
        headerRoot.findViewById<TextView>(R.id.screen_number).text = screenNumber
        headerRoot.findViewById<View>(R.id.back_img).setOnClickListener {
            journeyHost.navigateBack()
        }

        // Demo-mode Skip — MUST NOT render outside MOCK mode (task step 4).
        val skip = headerRoot.findViewById<TextView>(R.id.tv_skip)
        if (onSkip != null && journeyHost.isMockMode()) {
            skip.visibility = View.VISIBLE
            skip.setOnClickListener {
                NanoLoanSDK.notifyStepSkipped(stepName)
                onSkip()
            }
        } else {
            skip.visibility = View.GONE
        }

        NanoLoanThemeApplier.applyHeader(headerRoot, NanoLoanSDK.currentConfiguration().theme)
    }
}
