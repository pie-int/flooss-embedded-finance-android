package com.flooss.nanoloan.listener

import com.flooss.nanoloan.result.NanoLoanError

/**
 * Host-implemented callback contract (design doc §9.1). Registered via
 * [com.flooss.nanoloan.NanoLoanSDK.addListener]; every facade call and the presented
 * journey UI emit through it.
 *
 * Deferred from the design doc for this POC slice: `onInputRequired(request:
 * NanoInputRequest)` (§9.5 "Option B" interaction model) — this POC only implements the
 * straightforward eligibility -> apply -> offer -> accept/decline path, which never needs
 * mid-flow host-supplied input. Backlog item, not implemented.
 */
interface NanoLoanListener {
    fun onStateUpdate(state: NanoLoanState)
    fun onEvent(event: NanoLoanEvent)
    fun onFailure(error: NanoLoanError)
}
