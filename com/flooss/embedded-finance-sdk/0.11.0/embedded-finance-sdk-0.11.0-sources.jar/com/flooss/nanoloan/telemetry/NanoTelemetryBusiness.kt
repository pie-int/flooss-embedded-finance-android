package com.flooss.nanoloan.telemetry

import com.flooss.nanoloan.model.PeriodType
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale

/**
 * Back-office v2 spec §3.2 value conversions for the opt-in business attributes.
 *
 * ## Money is an integer number of fils, never a float
 * Spec §3.2 and §10.4: "amounts are integers in fils (no floats for money, ever)",
 * currency is BHD and implicit. The Bahraini dinar has three minor units, so
 * 1 BHD = 1000 fils. This side converts from [BigDecimal], which is exact; the iOS twin
 * scales then rounds half-up from a `Double`, which is the closest it can get. The
 * conversion lives here, once, at the telemetry boundary, so the rounding decision is
 * made in one place on each platform.
 */
internal object NanoTelemetryBusiness {

    /**
     * BHD → fils. Returns null for a missing or negative amount rather than sending a
     * zero, which would read as a real BD 0.000 offer in the amount-band analytics.
     */
    fun fils(amount: BigDecimal?): Long? {
        if (amount == null || amount.signum() < 0) return null
        return amount.movePointRight(3).setScale(0, RoundingMode.HALF_UP).toLong()
    }

    /**
     * Loan period → `tenorMonths`. A WEEKS-denominated product is NOT converted: 6 weeks
     * is not "1 month", and a fabricated month count would corrupt the §3.2 tenor
     * distribution. Such an offer simply omits the key.
     */
    fun tenorMonths(period: Long?, periodType: PeriodType?): Int? {
        if (period == null || period <= 0L || periodType != PeriodType.MONTHS) return null
        return period.toInt()
    }

    /**
     * Annual percentage rate as a number (12.5 = 12.5%).
     *
     * On this platform the offer's APR arrives as [com.flooss.nanoloan.model.LoanOffer
     * .interestRate], a DISPLAY string — the offer screen renders it straight into the
     * "APR" row. It is parsed strictly and dropped when it does not parse to a plain
     * number, because a half-parsed rate is worse than an absent one. (The iOS twin has a
     * real `annualPercentageRate: Double` on its model and needs no parsing; that
     * difference is a model gap on this side, not a contract difference.)
     */
    fun aprPct(rate: String?): Double? {
        val cleaned = rate?.trim()?.removeSuffix("%")?.trim() ?: return null
        if (cleaned.isEmpty()) return null
        val parsed = cleaned.toDoubleOrNull() ?: return null
        if (!parsed.isFinite() || parsed < 0) return null
        return parsed
    }

    /**
     * Contract-facing `disbursement_set.attrs.method`.
     *
     * The two SDKs send DIFFERENT values to Salaf for the same customer choice — Android
     * `?disbursementMethod=BANK_ACCOUNT`, iOS `?disbursementMethod=IBAN` — because each
     * mirrors its own host app's constant. Reporting each platform's raw value would
     * split one bar of the §3.2 "disbursement method mix" chart in two, so the telemetry
     * attr is normalised to the app's own `DisbursementType` name and the raw value stays
     * where it belongs, on the Salaf request.
     */
    fun disbursementMethod(raw: String): String = when (raw.uppercase(Locale.US)) {
        "IBAN", "BANK_ACCOUNT", "DISBURSEMENT_METHOD_BANK_IBAN" -> "BANK_ACCOUNT"
        "STC_PAY", "STC" -> "STC_PAY"
        "FLOOSS_CARD", "CARD" -> "FLOOSS_CARD"
        else -> raw.uppercase(Locale.US)
    }
}
