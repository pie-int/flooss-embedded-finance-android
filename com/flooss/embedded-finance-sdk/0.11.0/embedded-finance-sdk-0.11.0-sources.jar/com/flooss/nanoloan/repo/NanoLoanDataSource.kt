package com.flooss.nanoloan.repo

import com.flooss.nanoloan.model.AcceptanceOtpSession
import com.flooss.nanoloan.model.ActiveLoanInfo
import com.flooss.nanoloan.model.BankLinkResult
import com.flooss.nanoloan.model.BankProvider
import com.flooss.nanoloan.model.EligibilityResult
import com.flooss.nanoloan.model.LoanApplicationRequest
import com.flooss.nanoloan.model.LoanApplicationResult
import com.flooss.nanoloan.model.LoanOffer
import com.flooss.nanoloan.model.LoanProductInfo
import com.flooss.nanoloan.model.OfferInstallmentsPreview
import com.flooss.nanoloan.result.NanoLoanResult

/**
 * Data-source seam between [NanoLoanRepository] and the two implementations:
 * [RealNanoLoanDataSource] (real Retrofit network calls) and [MockNanoLoanDataSource]
 * (canned responses, no network, for [com.flooss.nanoloan.config.NanoLoanEnvironment.MOCK]).
 * Method set mirrors the real Apply Loan flow's API sequence
 * (API_SEQUENCE_FLOWS.md §4.1–§4.4).
 */
internal interface NanoLoanDataSource {
    /**
     * Salaf OAuth2 password grant (design doc §7.2 Model B) — `POST api/v1/oauth/token`.
     * Client id/secret/scope come from [com.flooss.nanoloan.config.NanoLoanConfiguration].
     */
    suspend fun login(
        cpr: String,
        pin: String,
        clientId: String,
        clientSecret: String,
        scope: String
    ): NanoLoanResult<com.flooss.nanoloan.model.NanoLoanToken>

    suspend fun checkEligibility(bearerToken: String, cpr: String): NanoLoanResult<EligibilityResult>

    /** The three `GET api/v1/fo/profile/attributes/{type}` lists the employment step needs. */
    suspend fun getEmploymentOptions(bearerToken: String): NanoLoanResult<com.flooss.nanoloan.model.EmploymentOptions>

    /** `POST api/v1/fo/client-profile/employment-details` (real screen 2/4's save). */
    suspend fun saveEmploymentDetails(
        bearerToken: String,
        details: com.flooss.nanoloan.model.EmploymentDetails
    ): NanoLoanResult<Unit>

    /** `GET api/v1/fo/loans/disbursement/bank-detail/{iban}`. */
    suspend fun getBankDetailForIban(
        bearerToken: String,
        iban: String
    ): NanoLoanResult<com.flooss.nanoloan.model.BankIbanDetail>

    /** `PUT api/v1/fo/applications/disburse-detail/{accountNumber}?disbursementMethod=...`. */
    suspend fun setDisbursementMethod(
        bearerToken: String,
        accountNumber: String,
        disbursementMethod: String
    ): NanoLoanResult<Unit>

    suspend fun getProducts(bearerToken: String): NanoLoanResult<LoanProductInfo>

    suspend fun getActiveLoan(bearerToken: String): NanoLoanResult<ActiveLoanInfo>

    suspend fun getBankProviders(bearerToken: String): NanoLoanResult<List<BankProvider>>

    /** Tarabut intent + accounts/sync — two wire calls, one logical bank-link action. */
    suspend fun linkBankAccount(bearerToken: String, providerId: String): NanoLoanResult<BankLinkResult>

    suspend fun uploadSalaryDocuments(
        bearerToken: String,
        documents: List<com.flooss.nanoloan.model.SalaryDocument>
    ): NanoLoanResult<List<com.flooss.nanoloan.model.UploadedDocument>>

    /** `GET api/v1/fo/client-profile` — the customer's name and declared monthly salary. */
    suspend fun getCustomerProfile(bearerToken: String): NanoLoanResult<com.flooss.nanoloan.model.CustomerProfile>

    suspend fun submitLoanApplication(
        bearerToken: String,
        request: LoanApplicationRequest,
        floossToken: String? = null
    ): NanoLoanResult<LoanApplicationResult>

    /** Wallet device check, then the wallet password grant when the device is trusted. */
    suspend fun walletSignIn(device: WalletDevice, mobileNumber: String, pin: String): NanoLoanResult<WalletSignIn>

    /** Verify the SMS code for a new device (which trusts it), then sign in. */
    suspend fun walletVerifyDevice(
        device: WalletDevice,
        actionUuid: String,
        otp: String,
        mobileNumber: String,
        pin: String
    ): NanoLoanResult<WalletSignIn.Signed>

    /**
     * The signed-in customer's CPR from the wallet (`GET {wallet}api/v1/customer/info`,
     * identification type "CPR"), which the Salaf password grant takes as the username.
     * Success(null) when the wallet holds no CPR for the customer.
     */
    suspend fun walletCustomerCpr(device: WalletDevice, walletToken: String): NanoLoanResult<String?>

    suspend fun getActiveOffer(bearerToken: String): NanoLoanResult<LoanOffer>

    suspend fun getOfferInstallments(bearerToken: String): NanoLoanResult<OfferInstallmentsPreview>

    suspend fun getLoanAgreement(bearerToken: String, loanAppId: Long): NanoLoanResult<Unit>

    /** sendEmailOtp + sendSms — the two OTP dispatches of the acceptance chain (§4.4 steps 1–2). */
    suspend fun requestAcceptanceOtp(bearerToken: String): NanoLoanResult<AcceptanceOtpSession>

    suspend fun acceptOffer(
        bearerToken: String,
        applicationId: Long,
        offerGuid: String
    ): NanoLoanResult<Unit>

    suspend fun verifyAcceptanceOtp(
        bearerToken: String,
        applicationId: Long,
        offerGuid: String,
        otp: String,
        phoneVerificationUUID: String?
    ): NanoLoanResult<Unit>

    suspend fun declineOffer(
        bearerToken: String,
        applicationId: Long,
        offerGuid: String,
        reason: String?
    ): NanoLoanResult<Unit>
}
