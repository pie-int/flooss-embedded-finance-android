package com.flooss.nanoloan.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.model.PeriodType
import com.flooss.nanoloan.model.LoanOffer
import com.flooss.nanoloan.result.NanoLoanResult

/**
 * Step 3 — REAL screen port of :app `LoanDetailFragment` + `fragment_loan_detail.xml`
 * (the "CONGRATULATIONS — you have been approved for" offer screen, dots 1/3).
 * Amount/installment/total binding mirrors the real fragment (AppUtil.formatDouble +
 * " BHD"); the detail rows mirror AppUtil.getLoanDetailFromLoanList with fee fields the
 * SDK's LoanOffer model does not carry (APR/fees/first-installment-date) derived from
 * the mock offer's own numbers.
 */
internal class NanoLoanOfferFragment : NanoLoanJourneyFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.fragment_loan_detail, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme
        val offer = journeyData.offer ?: run {
            journeyHost.finishJourney()
            return
        }

        setUpHeader(
            headerRoot = view.findViewById(R.id.header),
            title = getString(R.string.loan_offer),
            dotCount = 3,
            dotIndex = 1,
            screenNumber = "6/12",
            stepName = STEP_NAME
        ) {
            acceptOffer(view, offer)
        }

        // The real Loan Offer screen loads its three data sources together (§4.3):
        // offers/active (already fetched to get here) + installments + loan-agreement.
        if (savedInstanceState == null) {
            NanoLoanSDK.getOfferInstallments { }
            NanoLoanSDK.getLoanAgreement(offer.offerGuid) { }
        }

        val bhd = getString(R.string.bhd_app_text)
        view.findViewById<TextView>(R.id.loan_amount).text =
            NanoLoanMath.formatDouble((offer.loanAmount ?: offer.principalAmount)?.toDouble() ?: 0.0)
                .plus(" $bhd")
        view.findViewById<TextView>(R.id.monthly_installment).text =
            offer.installmentAmount?.let { NanoLoanMath.formatDouble(it.toDouble()) + " $bhd" } ?: " "
        view.findViewById<TextView>(R.id.total_amount_to_pay).text =
            offer.totalAmount?.let { NanoLoanMath.formatDouble(it.toDouble()) + " $bhd" } ?: " "

        val rows = listOf(
            KeyValueRow(
                getString(R.string.duration),
                "${offer.period} " + when (offer.periodType) {
                    PeriodType.MONTHS, null -> getString(
                        if (offer.period == 1L) R.string.nanoloan_month_singular else R.string.nanoloan_month_plural
                    )
                    else -> offer.periodType.name.lowercase()
                }
            ),
            KeyValueRow(getString(R.string.apr), offer.interestRate ?: ""),
            KeyValueRow(getString(R.string.processing_fee), "${NanoLoanMath.adminFeeText()} $bhd"),
            KeyValueRow(getString(R.string.vat), "${NanoLoanMath.adminFeeVatText()} $bhd"),
            KeyValueRow(
                getString(R.string.first_installment_date),
                NanoLoanMath.expectedFirstPaymentDate(journeyData.selectedRepaymentDate)
            ),
            KeyValueRow(getString(R.string.offer_expiry_date), offer.offerExpiryDate ?: "")
        )
        view.findViewById<RecyclerView>(R.id.loan_detail_rv).apply {
            adapter = LoanDetailRowsAdapter(rows)
            layoutManager = LinearLayoutManager(requireContext())
        }

        val acceptBtn = view.findViewById<View>(R.id.accept_btn)
        NanoLoanThemeApplier.applyPrimaryButton(acceptBtn, theme)
        acceptBtn.setOnClickListener { acceptOffer(view, offer) }
        view.findViewById<View>(R.id.reject_btn).setOnClickListener { rejectOffer(view, offer) }
    }

    /**
     * Accepting now follows the real post-accept order: disbursement channel selection
     * (LoanDisbursementChannelSelectionFragment) first — the acceptance-OTP chain
     * (sendEmailOtp + sendSms -> OTP entry -> accept + verify-otp) fires from the
     * disbursement step once the channel is confirmed, exactly like the app.
     */
    private fun acceptOffer(view: View, offer: LoanOffer) {
        journeyHost.goToKycDetails()
    }

    /**
     * Reject = the real app's two-step flow: the ported reject-confirmation bottom sheet
     * (app_loan_reject_confirmation_bottom_sheet) then the Reject Reason screen, which
     * fires the decline call with the typed reason.
     */
    private fun rejectOffer(view: View, offer: LoanOffer) {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(requireContext())
        val sheet = layoutInflater.inflate(R.layout.nanoloan_reject_confirmation_sheet, null)
        dialog.setContentView(sheet)
        sheet.findViewById<View>(R.id.btn_yes).setOnClickListener {
            dialog.dismiss()
            journeyHost.goToRejectReason()
        }
        sheet.findViewById<View>(R.id.btn_cancel).setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    companion object {
        const val STEP_NAME = "offer_review"

        // The SDK's public LoanOffer model doesn't carry fee fields yet (backlog); the fee
        // rows show NanoLoanMath's admin fee, the one already priced into the total.
    }
}
