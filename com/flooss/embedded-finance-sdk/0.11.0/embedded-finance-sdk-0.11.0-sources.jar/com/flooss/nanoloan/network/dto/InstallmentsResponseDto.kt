package com.flooss.nanoloan.network.dto

import com.google.gson.annotations.SerializedName
import java.math.BigDecimal

/**
 * Wire shape of `GET api/v2/fo/loans/installments`
 * (`WebServiceConstants.GET_ACTIVE_OFFER_INSTALLMENT_V2`,
 * `LoanApi.getActiveOfferInstallments` -> `Response<Installments>`). Trimmed mirror of
 * the app's `Installments` (`data/model/api/response/Installments.kt`) — this journey
 * only reads the pending groups' due dates and amounts.
 */
data class InstallmentsResponseDto(
    @SerializedName("pending") val pending: List<PendingInstallmentGroupDto> = emptyList()
)

data class PendingInstallmentGroupDto(
    @SerializedName("installmentDueDate") val installmentDueDate: String = "",
    @SerializedName("totalInstallmentAmount") val totalInstallmentAmount: BigDecimal?,
    @SerializedName("totalVat") val totalVat: Double = 0.0
)
