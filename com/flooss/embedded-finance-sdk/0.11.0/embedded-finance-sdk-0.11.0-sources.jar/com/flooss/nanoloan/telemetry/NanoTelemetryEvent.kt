package com.flooss.nanoloan.telemetry

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

/**
 * One contract §3 event object. Immutable, primitives only in [attrs] (the contract
 * requires a flat attrs map), already redacted by the time an instance exists — the
 * constructor is the wrong place to redact, so [NanoTelemetryClient] redacts on the way in.
 */
internal data class NanoTelemetryEvent(
    val eventId: String,
    val seq: Long,
    val ts: String,
    val kind: String,
    val name: String,
    val step: String?,
    val attrs: Map<String, Any?>
) {
    /** Contract-shape self-check. An event that fails this is dropped, never sent. */
    fun isContractValid(): Boolean =
        kind in NanoTelemetryContract.Kind.ALL &&
            NanoTelemetryContract.isValidName(kind, name) &&
            NanoTelemetryContract.isValidStep(step)

    fun toJson(): String = buildString {
        append('{')
        appendJsonField("eventId", eventId); append(',')
        append("\"seq\":").append(seq); append(',')
        appendJsonField("ts", ts); append(',')
        appendJsonField("kind", kind); append(',')
        appendJsonField("name", name); append(',')
        append("\"step\":").append(NanoJson.value(step)); append(',')
        append("\"attrs\":").append(NanoJson.obj(attrs))
        append('}')
    }

    private fun StringBuilder.appendJsonField(key: String, value: String) {
        append('"').append(key).append("\":").append(NanoJson.value(value))
    }

    companion object {
        fun newEventId(): String = UUID.randomUUID().toString()
    }
}

/**
 * Minimal JSON writer. Hand-rolled on purpose: `org.json` is a stubbed no-op in JVM unit
 * tests unless `returnDefaultValues` is set (which silently turns assertions green), and
 * pulling Gson into the telemetry path would make the wire format depend on reflection
 * over classes ProGuard may rename in a host app. Twenty lines we control beats either.
 */
internal object NanoJson {

    fun value(v: Any?): String = when (v) {
        null -> "null"
        is Boolean -> v.toString()
        is Int, is Long, is Short, is Byte -> v.toString()
        is Float, is Double -> if (v.toDouble().isFinite()) v.toString() else "null"
        else -> quote(v.toString())
    }

    fun obj(map: Map<String, Any?>): String =
        map.entries.joinToString(",", "{", "}") { (k, v) -> "${quote(k)}:${value(v)}" }

    fun array(items: List<String>): String = items.joinToString(",", "[", "]")

    fun quote(s: String): String = buildString(s.length + 2) {
        append('"')
        for (c in s) {
            when (c) {
                '"' -> append("\\\"")
                '\\' -> append("\\\\")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                '\b' -> append("\\b")
                '\u000C' -> append("\\f")
                else -> if (c < ' ') append(String.format(Locale.US, "\\u%04x", c.code)) else append(c)
            }
        }
        append('"')
    }
}

/** ISO-8601 UTC with milliseconds, exactly the contract §2/§3 `ts` shape. */
internal object NanoTelemetryClock {
    private val formatter = object : ThreadLocal<SimpleDateFormat>() {
        override fun initialValue(): SimpleDateFormat =
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
    }

    fun nowIso(): String = iso(System.currentTimeMillis())

    fun iso(epochMillis: Long): String = formatter.get()!!.format(Date(epochMillis))
}
