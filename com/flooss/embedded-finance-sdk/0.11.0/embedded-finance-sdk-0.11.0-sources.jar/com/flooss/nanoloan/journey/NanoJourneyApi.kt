package com.flooss.nanoloan.journey

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

internal sealed class PlanCreateResult {
    data class Created(val plan: JourneyPlan) : PlanCreateResult()

    /** 401/403 with the back office's `error` code (`invalid_api_key`, `environment_mismatch`, …). */
    data class Refused(val status: Int, val code: String? = null) : PlanCreateResult()

    /** 400: the request itself was refused (`validation_failed`, `invalid_environment`, …); retrying cannot help. */
    data class Invalid(val code: String?) : PlanCreateResult()

    data class Failed(val reason: String) : PlanCreateResult()
}

internal enum class PatchSendResult {
    SENT,

    /** Transport failure, 429, 5xx or 409 journey_conflict: try again. */
    RETRYABLE,

    /** Refused for this report only (401/403/422…): drop it. */
    REJECTED,

    /** 400 step_not_in_plan, 404, 409 journey_closed / journey_denied: stop reporting this journey. */
    JOURNEY_CLOSED
}

/** Seam so the engine and the PATCH queue are unit-testable with no socket. */
internal interface NanoJourneyApi {
    fun create(body: String): PlanCreateResult
    fun patch(journeyId: String, body: String): PatchSendResult
}

/**
 * `POST /v1/sdk/journeys` and `PATCH /v1/sdk/journeys/{id}` on the back office, with
 * the partner key, the telemetry timeouts and its own client (never in the journey's
 * `ApiCallExecuted` stream).
 */
internal class OkHttpJourneyApi(
    private val baseUrl: String,
    private val apiKey: () -> String,
    /** Sent as `?environment=`: a test key covers several environments. */
    private val environment: String,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .build()
) : NanoJourneyApi {

    private val json = "application/json; charset=utf-8".toMediaType()

    override fun create(body: String): PlanCreateResult = try {
        val request = Request.Builder()
            .url(baseUrl.trimEnd('/') + JOURNEYS_PATH + "?environment=" + environment)
            .addHeader("Authorization", "Bearer ${apiKey()}")
            .post(body.toRequestBody(json))
            .build()
        client.newCall(request).execute().use { response ->
            when {
                response.code == 401 || response.code == 403 ->
                    PlanCreateResult.Refused(response.code, errorCode(response.body?.string()))
                response.code == 400 -> PlanCreateResult.Invalid(errorCode(response.body?.string()))
                response.isSuccessful -> JourneyPlan.parse(response.body?.string().orEmpty())
                    ?.let { PlanCreateResult.Created(it) }
                    ?: PlanCreateResult.Failed("unreadable plan")
                else -> PlanCreateResult.Failed("HTTP ${response.code}")
            }
        }
    } catch (t: Throwable) {
        PlanCreateResult.Failed(t.javaClass.simpleName)
    }

    override fun patch(journeyId: String, body: String): PatchSendResult = try {
        val request = Request.Builder()
            .url(baseUrl.trimEnd('/') + JOURNEYS_PATH + "/" + journeyId + "?environment=" + environment)
            .addHeader("Authorization", "Bearer ${apiKey()}")
            .patch(body.toRequestBody(json))
            .build()
        client.newCall(request).execute().use { response ->
            when {
                response.isSuccessful -> PatchSendResult.SENT
                response.code == 429 || response.code in 500..599 -> PatchSendResult.RETRYABLE
                response.code == 409 && errorCode(response.body?.string()) == "journey_conflict" ->
                    PatchSendResult.RETRYABLE
                response.code == 400 || response.code == 404 || response.code == 409 -> PatchSendResult.JOURNEY_CLOSED
                else -> PatchSendResult.REJECTED
            }
        }
    } catch (t: Throwable) {
        PatchSendResult.RETRYABLE
    }

    companion object {
        const val JOURNEYS_PATH = "/v1/sdk/journeys"

        /** The back office's error body is `{"error": "<code>", …}`. */
        fun errorCode(body: String?): String? = runCatching {
            com.google.gson.JsonParser.parseString(body.orEmpty()).asJsonObject.get("error")?.asString
        }.getOrNull()

        /** 403 for an environment the key may not use: the service is unavailable, not the key bad. */
        val ENVIRONMENT_REFUSALS = setOf("environment_mismatch", "environment_disabled")
    }
}
