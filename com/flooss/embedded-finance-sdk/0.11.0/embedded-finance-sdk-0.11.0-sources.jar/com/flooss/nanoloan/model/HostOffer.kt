package com.flooss.nanoloan.model

/**
 * The HOST's own financing offer, supplied to
 * [com.flooss.nanoloan.NanoLoanSDK.presentOfferComparison] so the SDK can render it beside
 * the Flooss offer (SDK_V3_PRODUCT_GAPS §2.2).
 *
 * The SDK **never fabricates one of these**. No host offer means no comparison screen —
 * the journey falls back to the single-offer screen it already had. Everything here comes
 * from the host and is displayed as given; the SDK does not recompute, validate or
 * "correct" a competitor's numbers.
 *
 * ## Money is integer fils
 * Bahraini dinar has three minor units, so 1 BHD = 1000 fils. Every amount on this model
 * is fils, matching the telemetry contract's "amounts are integers in fils (no floats for
 * money, ever)". A host that holds BHD decimals multiplies by 1000 before it gets here,
 * once, at its own boundary.
 *
 * @param providerName what to print above the host's column ("BenefitPay"), never a
 *   Flooss brand. Shown verbatim.
 * @param amountFils the principal the host would advance.
 * @param tenorMonths repayment term in months.
 * @param monthlyInstalmentFils the host's monthly instalment.
 * @param totalPayableFils everything the customer repays in total.
 * @param aprPercent annual percentage rate as a number (4.99 = 4.99%), or null when the
 *   host does not quote one — the row then reads as unavailable rather than as 0%.
 * @param logoRes optional drawable in the HOST's resources for its column's brand mark.
 */
data class HostOffer(
    val providerName: String,
    val amountFils: Long,
    val tenorMonths: Int,
    val monthlyInstalmentFils: Long,
    val totalPayableFils: Long,
    val aprPercent: Double? = null,
    val logoRes: Int? = null
)

/** Which side of the §2.2 comparison the customer chose. */
enum class OfferSource {
    /** The host's own offer. The SDK journey ends and the host takes it from there. */
    HOST,

    /** The Flooss offer. The SDK journey continues. */
    FLOOSS
}
