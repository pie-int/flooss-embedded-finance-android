package com.flooss.nanoloan.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R

/**
 * sign_in step, screen 1: the customer's Flooss mobile number, prefilled from
 * [com.flooss.nanoloan.model.JourneyRequest.mobileNumber] and editable. Eight digits, the
 * Flooss app's own login rule; the wallet decides whether the number is a Flooss customer.
 */
internal class NanoLoanSignInMobileFragment : NanoLoanJourneyFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_sign_in_mobile, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme
        setUpHeader(
            headerRoot = view.findViewById(R.id.header),
            title = getString(R.string.nanoloan_sign_in_title),
            dotCount = 2,
            dotIndex = 1,
            screenNumber = "",
            stepName = STEP_NAME,
            onSkip = null
        )
        NanoLoanThemeApplier.applyChromeBackground(view, theme)

        val signIn = NanoLoanSDK.activeJourneyBridge()?.signIn
        val field = view.findViewById<EditText>(R.id.et_mobile)
        val error = view.findViewById<View>(R.id.tv_mobile_error)
        val next = view.findViewById<View>(R.id.btn_mobile_next)
        NanoLoanThemeApplier.applyPrimaryButton(next, theme)
        if (savedInstanceState == null) field.setText(signIn?.mobileNumber.orEmpty())

        fun refresh() {
            val valid = isValidMobile(field.text?.toString().orEmpty())
            next.isEnabled = valid
            next.alpha = if (valid) 1f else 0.5f
        }
        field.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                error.visibility = View.GONE
                refresh()
            }
        })
        refresh()
        submitOnDone(field, 8, next)

        next.setOnClickListener {
            val mobile = field.text?.toString().orEmpty()
            if (!isValidMobile(mobile)) {
                error.visibility = View.VISIBLE
                return@setOnClickListener
            }
            signIn?.mobileNumber = mobile
            journeyHost.goToSignInPin()
        }
    }

    companion object {
        const val STEP_NAME = "sign_in_mobile"

        /** The Flooss app's login rule: an 8-digit Bahrain number, without the +973. */
        fun isValidMobile(value: String): Boolean = value.length == 8 && value.all { it.isDigit() }

        /** A host's prefill as the 8-digit local number: digits only, +973 / 00973 dropped. */
        fun normalizeMobile(value: String?): String {
            val digits = value.orEmpty().filter { it.isDigit() }
            return when {
                digits.length == 13 && digits.startsWith("00973") -> digits.substring(5)
                digits.length == 11 && digits.startsWith("973") -> digits.substring(3)
                else -> digits.take(8)
            }
        }
    }
}
