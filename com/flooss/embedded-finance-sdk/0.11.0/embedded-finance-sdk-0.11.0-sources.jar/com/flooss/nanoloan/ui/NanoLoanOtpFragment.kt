package com.flooss.nanoloan.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import com.flooss.nanoloan.repo.MockNanoLoanDataSource
import com.flooss.nanoloan.result.NanoLoanResult
import com.flooss.nanoloan.ui.widget.CustomFontTextView

/**
 * Step 5 — SMS-OTP acceptance entry (API_SEQUENCE_FLOWS §4.4 steps 3–4). Derived from
 * :app `LoanAcceptanceOTPFragment` + `fragment_otp.xml` in its finance-acceptance skin
 * (see the layout header comment; the app's bundled PinView widget is recreated as six
 * mirrored digit boxes).
 *
 * Next fires the real acceptance pair, in the real order:
 *  1. `POST fo/loans/normal/{id}/offers/{offerGuid}/accept`
 *  2. `POST fo/loans/normal/{id}/offers/{offerGuid}/verify-otp` (with the keyed OTP)
 * MOCK mode accepts any 4–6 digit OTP.
 *
 * The same screen collects the wallet's SMS code when sign-in meets a new device
 * ([forSignIn]): the code goes to `POST {wallet}api/v1/system/verify-otp`, which trusts
 * the device, and Resend runs the wallet check again, which sends a new code.
 */
internal class NanoLoanOtpFragment : NanoLoanJourneyFragment() {

    private val signInMode: Boolean get() = arguments?.getBoolean(ARG_SIGN_IN) == true

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_otp, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme
        if (signInMode) {
            setUpSignIn(view)
            return
        }

        setUpHeader(
            headerRoot = view.findViewById(R.id.headerLayout),
            title = getString(R.string.nanoloan_title_verification_code),
            dotCount = 3,
            dotIndex = 2,
            screenNumber = "9/12",
            stepName = STEP_NAME
        ) {
            submitOtp(view, DEMO_SKIP_OTP)
        }

        view.findViewById<TextView>(R.id.tv_otp_description).text = getString(
            R.string.otp_sent_to_number,
            journeyData.maskedOtpPhone ?: MockNanoLoanDataSource.MOCK_MASKED_PHONE
        )

        val boxes = buildPinBoxes(view.findViewById(R.id.pin_boxes))
        val etOtp = view.findViewById<EditText>(R.id.et_otp)
        val nextBtn = view.findViewById<View>(R.id.btn_opt_next)
        NanoLoanThemeApplier.applyPrimaryButton(nextBtn, theme)
        nextBtn.isEnabled = false
        nextBtn.alpha = 0.5f

        etOtp.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val digits = s?.toString().orEmpty()
                boxes.forEachIndexed { index, box ->
                    box.text = digits.getOrNull(index)?.toString().orEmpty()
                }
                val valid = digits.length in 4..6
                nextBtn.isEnabled = valid
                nextBtn.alpha = if (valid) 1f else 0.5f
            }
        })
        etOtp.requestFocus()

        nextBtn.setOnClickListener {
            val otp = etOtp.text?.toString().orEmpty()
            if (otp.length in 4..6) submitOtp(view, otp)
        }

        // Resend = re-fires the real `POST security/verifyPhone/sendSms` leg.
        view.findViewById<View>(R.id.resend_sms_btn).setOnClickListener {
            NanoLoanSDK.requestAcceptanceOtp { }
        }
    }

    private fun setUpSignIn(view: View) {
        val theme = NanoLoanSDK.currentConfiguration().theme
        setUpHeader(
            headerRoot = view.findViewById(R.id.headerLayout),
            title = getString(R.string.nanoloan_sign_in_otp_title),
            dotCount = 2,
            dotIndex = 2,
            screenNumber = "",
            stepName = SIGN_IN_STEP_NAME,
            onSkip = null
        )
        val signIn = NanoLoanSDK.activeJourneyBridge()?.signIn
        view.findViewById<TextView>(R.id.tv_opt_enter).text = getString(R.string.nanoloan_sign_in_otp_heading)
        view.findViewById<TextView>(R.id.tv_otp_description).text =
            getString(R.string.otp_sent_to_number, signIn?.maskedPhone.orEmpty())
        val boxes = buildPinBoxes(view.findViewById(R.id.pin_boxes))
        val etOtp = view.findViewById<EditText>(R.id.et_otp)
        val error = view.findViewById<TextView>(R.id.tv_otp_error)
        val nextBtn = view.findViewById<View>(R.id.btn_opt_next)
        val progress = view.findViewById<View>(R.id.progress_bar)
        NanoLoanThemeApplier.applyPrimaryButton(nextBtn, theme)
        nextBtn.isEnabled = false
        nextBtn.alpha = 0.5f
        etOtp.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val digits = s?.toString().orEmpty()
                boxes.forEachIndexed { index, box -> box.text = digits.getOrNull(index)?.toString().orEmpty() }
                if (digits.isNotEmpty()) error.visibility = View.GONE
                val valid = digits.length in 4..6
                nextBtn.isEnabled = valid
                nextBtn.alpha = if (valid) 1f else 0.5f
            }
        })
        etOtp.requestFocus()
        submitOnDone(etOtp, 6, nextBtn)

        fun handle(outcome: com.flooss.nanoloan.repo.SignInOutcome) {
            if (!isAdded) return
            progress.visibility = View.GONE
            journeyHost.onSignInOutcome(outcome)?.let { message ->
                error.text = message
                error.visibility = View.VISIBLE
                etOtp.text?.clear()
            }
        }
        nextBtn.setOnClickListener {
            val session = signIn ?: return@setOnClickListener
            val pin = session.pin ?: return@setOnClickListener
            val otp = etOtp.text?.toString().orEmpty()
            if (otp.length !in 4..6) return@setOnClickListener
            progress.visibility = View.VISIBLE
            NanoLoanSDK.verifySignInCode(session.mobileNumber, pin, otp) { handle(it) }
        }
        view.findViewById<View>(R.id.resend_sms_btn).setOnClickListener {
            val session = signIn ?: return@setOnClickListener
            val pin = session.pin ?: return@setOnClickListener
            progress.visibility = View.VISIBLE
            NanoLoanSDK.signInCustomer(session.mobileNumber, pin) { handle(it) }
        }
    }

    private fun buildPinBoxes(container: LinearLayout): List<TextView> {
        val density = resources.displayMetrics.density
        val size = (34 * density).toInt()
        val spacing = (6 * density).toInt()
        return (0 until PIN_LENGTH).map { index ->
            val box = CustomFontTextView(container.context)
            box.setBackgroundResource(R.drawable.nanoloan_pin_box_bg)
            box.gravity = android.view.Gravity.CENTER
            box.textSize = 16f
            box.setTextColor(resources.getColor(R.color.app_blue, null))
            val params = LinearLayout.LayoutParams(size, size)
            if (index > 0) params.marginStart = spacing
            container.addView(box, params)
            box
        }
    }

    private fun submitOtp(view: View, otp: String) {
        val offer = journeyData.offer ?: run {
            journeyHost.finishJourney()
            return
        }
        val progress = view.findViewById<View>(R.id.progress_bar)
        progress.visibility = View.VISIBLE
        NanoLoanSDK.acceptOffer(offer.offerGuid) { accepted ->
            if (!isAdded) return@acceptOffer
            when (accepted) {
                is NanoLoanResult.Failure -> progress.visibility = View.GONE
                is NanoLoanResult.Success ->
                    NanoLoanSDK.verifyAcceptanceOtp(offer.offerGuid, otp) { verified ->
                        if (!isAdded) return@verifyAcceptanceOtp
                        progress.visibility = View.GONE
                        if (verified is NanoLoanResult.Success) {
                            journeyHost.goToFinalCheck()
                        }
                    }
            }
        }
    }

    companion object {
        const val STEP_NAME = "acceptance_otp"
        const val SIGN_IN_STEP_NAME = "sign_in_otp"
        private const val ARG_SIGN_IN = "sign_in"

        /** The screen in its sign-in role: the wallet's code for a new device. */
        fun forSignIn(): NanoLoanOtpFragment =
            NanoLoanOtpFragment().apply { arguments = androidx.core.os.bundleOf(ARG_SIGN_IN to true) }
        private const val PIN_LENGTH = 6
        private const val DEMO_SKIP_OTP = "000000"
    }
}
