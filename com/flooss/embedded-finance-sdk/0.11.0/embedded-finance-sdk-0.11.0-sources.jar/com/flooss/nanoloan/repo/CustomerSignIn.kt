package com.flooss.nanoloan.repo

import com.flooss.nanoloan.model.ActiveLoanInfo
import com.flooss.nanoloan.model.LoanOffer
import com.flooss.nanoloan.model.LoanStatus
import com.flooss.nanoloan.result.NanoLoanError
import java.math.BigDecimal

/** Where one attempt of the SDK's own sign-in (mobile + Flooss PIN, then OTP if asked) landed. */
internal sealed class SignInOutcome {
    /** Signed in to the wallet and to Salaf. */
    object Signed : SignInOutcome()

    /** New device: the wallet sent an SMS code to [maskedPhone]. */
    data class OtpRequired(val maskedPhone: String) : SignInOutcome()

    /**
     * Wrong PIN. [attemptsLeft] when the wallet counted the failures; [nearLock] when it
     * asked for a captcha (31012), which comes just before it locks the account.
     */
    data class WrongPin(val attemptsLeft: Int?, val nearLock: Boolean) : SignInOutcome()

    /** The wallet refused the SMS code. */
    object WrongCode : SignInOutcome()

    /** The wallet has no customer with this mobile number. */
    object NotACustomer : SignInOutcome()

    /** The wallet has locked or blocked the customer. */
    object Locked : SignInOutcome()

    /** Anything else (network, server); the customer can try again. */
    data class Failed(val error: NanoLoanError) : SignInOutcome()

    companion object {
        // floos-backend util/Constants.java, as CustomerServiceImpl.validateCustomer and
        // ValidateCredentialsRetriesLimits raise them on `POST api/v1/customer/validate`.
        const val USER_NOT_VALIDATED = 30001
        const val USER_BLOCKED = 30002
        const val PROFILE_NOT_EXISTS = 30003
        const val INCORRECT_PIN = 30004
        const val USER_BLACKLISTED = 30013
        const val USER_BLACKLISTED_FAILED_TRANSACTIONS = 30122
        const val SHOW_CAPTCHA = 31012
        const val SCREENA_REJECTED = 90040

        private val LOCKED_CODES = setOf(USER_BLOCKED, USER_BLACKLISTED, USER_BLACKLISTED_FAILED_TRANSACTIONS, SCREENA_REJECTED)
        private val WRONG_PIN_CODES = setOf(USER_NOT_VALIDATED, INCORRECT_PIN)

        /** `INVALID_ATTEMPTS_ALLOWED`: the wallet locks the account at this many wrong PINs. */
        const val PIN_ATTEMPTS_ALLOWED = 6

        fun attemptsLeft(failedCount: Int): Int? =
            if (failedCount > 0) (PIN_ATTEMPTS_ALLOWED - failedCount).coerceAtLeast(0) else null

        /**
         * A wallet failure, read by its error code. The SDK cannot show the wallet's
         * captcha, so a captcha demand reads as a wrong PIN close to the lock.
         */
        fun fromWalletError(error: NanoLoanError): SignInOutcome = when {
            error.errorCode == PROFILE_NOT_EXISTS -> NotACustomer
            error is NanoLoanError.UserBlocked || error.errorCode in LOCKED_CODES -> Locked
            error is NanoLoanError.Captcha || error.errorCode == SHOW_CAPTCHA -> WrongPin(null, nearLock = true)
            error is NanoLoanError.WrongPinOtp || error.errorCode in WRONG_PIN_CODES -> WrongPin(null, nearLock = false)
            else -> Failed(error)
        }
    }
}

/** What the signed-in customer already has with Flooss, which decides whether the journey goes on. */
internal sealed class CustomerLoanState {
    object NoLoans : CustomerLoanState()

    /** An offer is waiting for the customer: the journey resumes at its offer step. */
    data class OfferReady(val offer: LoanOffer) : CustomerLoanState()

    /** An application Flooss is still working on. */
    data class InReview(val applicationId: Long?) : CustomerLoanState()

    data class Overdue(val outstandingAmount: BigDecimal?) : CustomerLoanState()

    /** A running loan with a balance; Salaf's eligibility check decides whether another is possible. */
    data class ActiveLoan(
        val outstandingAmount: BigDecimal,
        val nextInstalmentAmount: BigDecimal?,
        val nextInstalmentDate: String?
    ) : CustomerLoanState()
}

/**
 * Reads `GET api/v1/fo/loans/active` (Salaf FrontOfficeLoanEndpoint.getActiveLoanDetails,
 * the call the Flooss app's loans home makes) into the route the journey takes. It only
 * groups Salaf's statuses the way the Flooss app's HomeActivity does; it makes no credit
 * decision. Salaf's eligibility check stays the authority on whether a customer with a
 * running loan may borrow again.
 */
internal object CustomerLoanRouting {

    enum class Kind { NO_LOANS, OFFER_READY, IN_REVIEW, OVERDUE, ACTIVE }

    /** An offer the customer can accept now (Salaf's OFFER, which OFFER_SENT reaches the front office as, and OFFER_VIEWED). */
    val OFFER_READY: Set<LoanStatus> = setOf(LoanStatus.OFFER, LoanStatus.OFFER_SENT, LoanStatus.OFFER_VIEWED)

    /** An application Salaf is still working on: review, pre-approval, salary verification. */
    val IN_REVIEW: Set<LoanStatus> = setOf(
        LoanStatus.APPLICATION_CREATED,
        LoanStatus.IN_RECALCULATION,
        LoanStatus.IN_APPROVAL_PROCESS,
        LoanStatus.IN_MANUAL_VERIFY,
        LoanStatus.POTENTIAL_APPLICATION,
        LoanStatus.IN_POTENTIAL_PRE_APPROVAL_PROCESS,
        LoanStatus.WAITING_FOR_SALARY,
        LoanStatus.SIO_SALARY_VERIFICATION_PENDING,
        LoanStatus.SIO_SALARY_FETCHED,
        LoanStatus.SIO_SALARY_NOT_FETCHED
    )

    /** Every OVERDUE status (HomeActivity's isLoanOverdue set) and DELINQUENT. */
    fun isOverdue(status: LoanStatus): Boolean = status.name.startsWith("OVERDUE") || status == LoanStatus.DELINQUENT

    /**
     * POTENTIAL_APPLICATION_SENT / _VIEWED (a pre-approved offer Flooss proposed) and any
     * status without a balance read as no loan; any other status with a balance is a running loan.
     */
    fun classify(info: ActiveLoanInfo): Kind {
        val status = info.status
        if (!info.hasActiveLoan || status == null) return Kind.NO_LOANS
        return when {
            status in OFFER_READY -> Kind.OFFER_READY
            status in IN_REVIEW -> Kind.IN_REVIEW
            isOverdue(status) -> Kind.OVERDUE
            (info.outstandingBalance ?: BigDecimal.ZERO).signum() > 0 -> Kind.ACTIVE
            else -> Kind.NO_LOANS
        }
    }
}
