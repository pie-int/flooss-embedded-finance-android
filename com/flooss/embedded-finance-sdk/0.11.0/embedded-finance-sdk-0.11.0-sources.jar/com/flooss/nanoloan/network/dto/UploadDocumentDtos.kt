package com.flooss.nanoloan.network.dto

/**
 * Wire shape of `POST api/v1/salary/documents/{folder}/upload`
 * (`WebServiceConstants.UPLOAD_LOAN_APPLY_PDF_DOCUMENTS`,
 * `SalafApi.hitUploadPdfDocumentApi` -> `Response<UploadDocumentResList>`). Trimmed
 * mirror of the app's `UploadDocumentResList`/`UploadDocumentRes`
 * (`data/model/api/response/UploadDocumentRes.kt`) minus the client-side-only fields
 * (`src`, `statusUploaded`).
 */
data class UploadDocumentListResponseDto(
    val data: List<UploadDocumentResponseDto> = emptyList()
)

data class UploadDocumentResponseDto(
    val id: String? = null,
    val bucketName: String? = null,
    val contentLength: Long? = null,
    val contentType: String? = null,
    val displayName: String? = null,
    val signature: String? = null,
    val url: String? = null,
    val folder: String? = null
)
