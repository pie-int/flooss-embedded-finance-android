package com.flooss.nanoloan.network.dto

/** Wire shape of `GET api/v1/fo/client/check-eligibility` — mirrors `SoouqBlacklistRes`. */
data class EligibilityResponseDto(
    val restricted: Boolean,
    val restrictedReason: String?,
    val remainingDays: Int,
    val remainingHours: Int,
    val remainingMinutes: Int,
    // UAT omits it for an unrestricted customer; Gson would leave a non-null String null.
    val restrictedUntil: String?
)
