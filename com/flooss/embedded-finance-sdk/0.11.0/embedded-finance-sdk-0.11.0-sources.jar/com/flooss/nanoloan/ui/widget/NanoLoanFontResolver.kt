package com.flooss.nanoloan.ui.widget

import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.config.NanoLoanLocale

/**
 * SDK-side replacement for the app's `loadLocale()` SharedPreferences check used by the
 * ported custom-font views: the SDK's configured locale is the single source of truth.
 */
internal object NanoLoanFontResolver {
    fun isArabic(): Boolean = try {
        NanoLoanSDK.currentConfiguration().locale == NanoLoanLocale.ARABIC
    } catch (e: IllegalArgumentException) {
        false
    } catch (e: IllegalStateException) {
        false
    }
}
