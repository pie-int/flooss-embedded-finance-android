package com.flooss.nanoloan.model

/**
 * Resolved bank details for a disbursement IBAN
 * (`GET api/v1/fo/loans/disbursement/bank-detail/{iban}`) — public projection of the
 * app's `BankDetailResponse`.
 */
data class BankIbanDetail(
    val bankName: String?,
    val bic: String?,
    val iban: String
)

/**
 * Employment details for screen 2/12, in the shape the lending backend requires. The three
 * ids come from [EmploymentOptions] (`NanoLoanSDK.loadEmploymentOptions`).
 */
data class EmploymentDetails(
    val companyName: String,
    val jobTitle: String,
    /** yyyy-MM-dd. Not part of the employment-details save; the loan application sends it. */
    val startDate: String,
    val educationLevelId: Long,
    val workExperienceId: Long,
    val yearsInCurrentJobId: Long
)

/** One choice from a backend profile-attribute list, e.g. "University Diploma". */
data class EmploymentOption(val id: Long, val label: String)

/**
 * The lists the employment step chooses from: `GET fo/profile/attributes/{type}` for the
 * three ids, and `GET fo/companies/private` for the employer suggestions.
 */
data class EmploymentOptions(
    val educationLevels: List<EmploymentOption>,
    val workExperience: List<EmploymentOption>,
    val yearsInCurrentJob: List<EmploymentOption>,
    val employers: List<String> = emptyList()
)

/** What Flooss already holds for the signed-in customer (`GET fo/client-profile`). */
data class CustomerProfile(
    val fullName: String?,
    val monthlySalary: java.math.BigDecimal?,
    val employerName: String?,
    val occupation: String?
)

/** A document the backend stored; [guid] is the upload response's id. */
data class UploadedDocument(val guid: String, val displayName: String? = null)

/** One salary bank statement the customer picked; the backend takes one to three PDFs. */
class SalaryDocument(val fileName: String, val bytes: ByteArray, val mimeType: String = "application/pdf")
