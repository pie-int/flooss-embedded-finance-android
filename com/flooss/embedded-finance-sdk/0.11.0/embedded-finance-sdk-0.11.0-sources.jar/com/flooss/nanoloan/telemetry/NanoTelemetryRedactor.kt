package com.flooss.nanoloan.telemetry

import java.security.MessageDigest
import java.util.Locale

/**
 * Contract §1.1 enforcement point. **Everything** that could carry a customer identifier
 * passes through here before it is buffered — not before it is sent, before it is even
 * held in memory as a telemetry event. This is deliberately a whitelist-shaped, paranoid
 * scrubber: it is cheaper to over-redact a debug message than to leak a CPR.
 *
 * Refused outright (never transformed, the whole value is dropped): request and response
 * bodies. Scrubbed in place: CPR, PIN, OTP, PAN, CVV, card expiry, IBAN, names, emails,
 * phone numbers, bearer/JWT/refresh tokens.
 *
 * ## `cprHash` and the tenant salt
 * The contract defines `cprHash = first 12 hex chars of SHA-256(cpr + tenantSalt)` but
 * does not say where `tenantSalt` comes from. This SDK derives it as
 * `SHA-256(tenant SDK key)` in hex — **not** the API key itself. Rationale:
 *  - it is per-tenant and stable, so the same customer correlates across sessions and
 *    app launches within one tenant, and never correlates across tenants;
 *  - the raw bearer credential is never an input a hash could be brute-forced back to,
 *    and is never held alongside the digest;
 *  - it needs no extra provisioning step — the host already supplies the key;
 *  - the back-office never needs to re-derive it (contract §1.1 treats `cprHash` as an
 *    opaque correlator), so a one-way, server-unknowable salt costs nothing.
 * The trade-off is accepted and documented: rotating a tenant's SDK key re-keys that
 * tenant's `cprHash` space, so historical sessions stop correlating with new ones.
 */
internal object NanoTelemetryRedactor {

    const val REDACTED = "[redacted]"
    private const val MAX_MESSAGE_LENGTH = 300

    // ── Patterns ─────────────────────────────────────────────────────────────────────
    // Ordered longest-token-first where two could overlap (PAN before CPR before phone),
    // because a 16-digit PAN also contains a 9-digit run.

    private val BEARER = Regex("""(?i)\b(bearer|basic)\s+[A-Za-z0-9._~+/=-]+""")
    private val JWT = Regex("""\beyJ[A-Za-z0-9._-]{10,}""")
    private val EMAIL = Regex("""[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}""")
    /** Any ISO 13616 IBAN, incl. Bahrain's BHkk BBBB CCCCCCCCCCCCCC (22 chars). */
    private val IBAN = Regex("""(?i)\b[A-Z]{2}\d{2}[ -]?(?:[A-Z0-9][ -]?){11,30}\b""")
    /** 13–19 digit card number, optionally grouped by space or dash. */
    private val PAN = Regex("""\b(?:\d[ -]?){12,18}\d\b""")
    /** International phone, e.g. +97333123456 / 00973 3312 3456. */
    private val PHONE = Regex("""(?:\+|\b00)\d[\d ()-]{6,17}\d""")
    /** Bahraini CPR / national ID: exactly nine digits, not part of a longer run. */
    private val CPR = Regex("""(?<![\d-])\d{9}(?![\d-])""")
    /** Card expiry MM/YY or MM/YYYY. */
    private val EXPIRY = Regex("""\b(0[1-9]|1[0-2])[/-](\d{2}|20\d{2})\b""")
    /**
     * Opaque high-entropy blob — refresh tokens, base64 keys. Deliberately narrow: it
     * must contain BOTH a digit and a letter, be at least 32 characters, and contain no
     * `/`, so it cannot swallow an API path such as
     * `/api/v1/fo/client-profile/employment-details`.
     */
    private val LONG_BLOB = Regex(
        """\b(?=[A-Za-z0-9+_=-]*\d)(?=[A-Za-z0-9+_=-]*[A-Za-z])[A-Za-z0-9+_=-]{32,}\b"""
    )
    /** Client-generated correlators (eventId/batchId/sessionId) — not PII, must not trip the gate. */
    private val UUID_SHAPED = Regex("""\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b""")
    private val ISO_TIMESTAMP = Regex("""\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z\b""")
    /** `pin=1234`, `"otp": "998877"`, `cvv:123`, `clientSecret = f4c0…`. */
    private val SENSITIVE_KV = Regex(
        """(?i)\b(cpr|nationalid|national_id|pin|otp|passcode|password|pan|cardnumber|card_number|cvv|cvc|expiry|exp|iban|accountnumber|account_number|token|access_token|refresh_token|secret|clientsecret|client_secret|authorization|apikey|api_key|firstname|lastname|fullname|full_name|name|email|phone|mobile|msisdn)\s*["']?\s*[:=]\s*["']?([^,;}\s"']+)"""
    )
    /** Anything that smells like a serialized body — refused whole, never partially kept. */
    private val BODY_SHAPED = Regex("""^\s*[\[{<]""")

    // ── Public API ───────────────────────────────────────────────────────────────────

    /**
     * Contract §1.1 `cprHash`. Returns null for a blank CPR or a blank key — the SDK then
     * sends `"cprHash": null` rather than a hash of nothing, which would be a constant
     * that falsely correlates every anonymous session together.
     */
    fun cprHash(cpr: String?, apiKey: String?): String? {
        val raw = cpr?.trim().orEmpty()
        val key = apiKey?.trim().orEmpty()
        if (raw.isEmpty() || key.isEmpty()) return null
        val salt = sha256Hex(key)
        return sha256Hex(raw + salt).take(12)
    }

    /**
     * Contract §3 `attrs.path` — "template, never with query values". Strips the query
     * string outright and replaces every identifier-shaped segment with a placeholder, so
     * `/api/v1/fo/loans/disbursement/bank-detail/BH67BMAG00001299123456` (an IBAN in a
     * URL path — the real Salaf API does this) becomes `/…/bank-detail/{iban}`.
     */
    fun redactPath(rawPath: String?): String {
        val path = rawPath.orEmpty().substringBefore('?').substringBefore('#')
        if (path.isEmpty()) return "/"
        return path.split('/').joinToString("/") { segment ->
            when {
                segment.isEmpty() -> segment
                IBAN.matches(segment) -> "{iban}"
                segment.all { it.isDigit() } -> "{id}"
                isUuid(segment) -> "{id}"
                // Mixed alphanumeric run long enough to be a GUID/account/token, not a word.
                segment.length >= 16 && segment.any { it.isDigit() } && segment.all { it.isLetterOrDigit() || it == '-' || it == '_' } -> "{id}"
                else -> segment
            }
        }
    }

    /**
     * Scrubs a free-text log message. Returns null when the text is refused entirely
     * (a serialized request/response body — contract §1.1 forbids those outright, and a
     * partially-scrubbed body is not a safe thing to guess at).
     */
    fun redactMessage(raw: String?): String? {
        val text = raw?.trim() ?: return null
        if (text.isEmpty()) return null
        if (BODY_SHAPED.containsMatchIn(text)) return null

        var out = text
        out = BEARER.replace(out, REDACTED)
        out = JWT.replace(out, REDACTED)
        out = SENSITIVE_KV.replace(out) { m -> "${m.groupValues[1]}=$REDACTED" }
        out = EMAIL.replace(out, REDACTED)
        out = IBAN.replace(out, REDACTED)
        out = PAN.replace(out, REDACTED)
        out = PHONE.replace(out, REDACTED)
        out = EXPIRY.replace(out, REDACTED)
        out = CPR.replace(out, REDACTED)
        out = LONG_BLOB.replace(out, REDACTED)
        // Adjacent scrubs collapse into one placeholder so the message stays readable.
        out = out.replace(Regex("""(?:\[redacted\][ \t]*){2,}"""), "$REDACTED ").trim()

        if (out.isEmpty()) return null
        return if (out.length > MAX_MESSAGE_LENGTH) out.take(MAX_MESSAGE_LENGTH) + "…" else out
    }

    /**
     * Last line of defence for an `attrs` value assembled anywhere in the SDK. Primitives
     * that are not strings pass through; strings go through [redactMessage] and are
     * dropped entirely if refused.
     */
    fun redactAttrValue(value: Any?): Any? = when (value) {
        null -> null
        is String -> redactMessage(value)
        is Number, is Boolean -> value
        else -> redactMessage(value.toString())
    }

    /**
     * Applies [redactAttrValue] across a map, dropping only keys whose value was REFUSED.
     * A key whose value is already null is kept as an explicit null: contract §3 documents
     * `txnId` and `errorCode` as `"…|null"`, i.e. present-and-null, not absent.
     */
    fun redactAttrs(attrs: Map<String, Any?>): Map<String, Any?> =
        attrs.mapNotNull { (k, v) ->
            when {
                v == null -> k to null
                // `path` is a URL template, not free text: [redactPath] keeps the useful
                // {id}/{iban} shape that the generic scrubber would flatten to
                // "[redacted]". Handled here rather than only at the call site so a
                // future caller that forgets to pre-template still gets a usable,
                // PII-free path.
                k == PATH_ATTR && v is String -> k to redactPath(v)
                else -> redactAttrValue(v)?.let { k to it }
            }
        }.toMap()

    /** Contract §3 `api_call.attrs.path`. */
    const val PATH_ATTR = "path"

    /**
     * True when [text] still contains something that looks like a customer identifier.
     * Used by the unit tests as an independent assertion, and by the client as a
     * belt-and-braces gate before a batch is buffered.
     */
    fun containsLikelyPii(text: String?): Boolean {
        // Strip the SDK's own correlators first: a UUID is two letters, two digits and a
        // long alphanumeric run, i.e. structurally indistinguishable from an IBAN.
        val t = (text ?: return false)
            .replace(UUID_SHAPED, "")
            .replace(ISO_TIMESTAMP, "")
        return EMAIL.containsMatchIn(t) || IBAN.containsMatchIn(t) || PAN.containsMatchIn(t) ||
            CPR.containsMatchIn(t) || JWT.containsMatchIn(t) || BEARER.containsMatchIn(t) ||
            PHONE.containsMatchIn(t)
    }

    // ── v2 §2 — externalUserRef ──────────────────────────────────────────

    /** v2 spec §2 — "Max 64 chars", mirrored here so the SDK and the server agree. */
    const val MAX_EXTERNAL_USER_REF_LENGTH = 64

    /**
     * Why a host-supplied `externalUserRef` was refused. Carried back to the caller so the
     * SDK can name the offending shape in a warning WITHOUT ever logging the value.
     */
    enum class ExternalUserRefRejection(val reason: String) {
        TOO_LONG("longer than 64 characters"),
        EMAIL("email-shaped"),
        PHONE("phone-shaped"),
        NUMERIC_ID("a bare 9+ digit number (CPR- or PAN-shaped)"),
        IBAN_SHAPED("IBAN-shaped (passes the mod-97 check)")
    }

    data class ExternalUserRefResult(
        val value: String?,
        val rejection: ExternalUserRefRejection?
    )

    /**
     * Back-office v2 spec §2. The reference is the host's OWN opaque customer id, and the
     * server answers 422 for a PII-shaped one. The SDK refuses it first so a partner finds
     * out at integration time rather than in production, and so the value never reaches
     * the wire at all.
     *
     * ## Why these five rules and not [containsLikelyPii]
     * The generic gate is deliberately paranoid because it guards free text. Applied to
     * this field it would refuse the very values the spec calls legitimate: the loose
     * [IBAN] pattern matches a plain hex digest, and "a hashed account number" is an
     * EXPLICITLY allowed reference. So:
     *
     *  - **email / phone** match anywhere in the value — an email inside a reference is
     *    PII however it is wrapped.
     *  - **CPR / PAN** match only when the WHOLE value is a bare run of 9 or more digits.
     *    That is what a pasted CPR (9) or card number (13–19) actually looks like, and
     *    anchoring stops a 32-char hex digest being refused for happening to contain nine
     *    consecutive digits — which roughly one digest in ten does.
     *  - **IBAN** matches only when the whole value is IBAN-shaped AND passes mod-97. A
     *    real IBAN always does; an arbitrary digest does so once in 97.
     *
     * Identical rules to the iOS twin, so the same host reference is accepted or refused
     * the same way on both platforms. A blank reference is not an error — it is absent.
     */
    fun sanitizeExternalUserRef(raw: String?): ExternalUserRefResult {
        val trimmed = raw?.trim().orEmpty()
        if (trimmed.isEmpty()) return ExternalUserRefResult(null, null)
        if (trimmed.length > MAX_EXTERNAL_USER_REF_LENGTH) {
            return ExternalUserRefResult(null, ExternalUserRefRejection.TOO_LONG)
        }
        if (EMAIL.containsMatchIn(trimmed)) {
            return ExternalUserRefResult(null, ExternalUserRefRejection.EMAIL)
        }
        if (PHONE.containsMatchIn(trimmed)) {
            return ExternalUserRefResult(null, ExternalUserRefRejection.PHONE)
        }
        if (isBareNumericId(trimmed)) {
            return ExternalUserRefResult(null, ExternalUserRefRejection.NUMERIC_ID)
        }
        if (isRealIban(trimmed)) {
            return ExternalUserRefResult(null, ExternalUserRefRejection.IBAN_SHAPED)
        }
        return ExternalUserRefResult(trimmed, null)
    }

    /** Whole value is nothing but 9 or more digits: a CPR (9) or a PAN (13–19). */
    private fun isBareNumericId(s: String): Boolean {
        val digits = s.count { it.isDigit() }
        if (digits < 9) return false
        return s.all { it.isDigit() || it == ' ' || it == '-' }
    }

    /** Whole value is IBAN-shaped AND mod-97 valid (ISO 13616 / ISO 7064 MOD 97-10). */
    private fun isRealIban(s: String): Boolean {
        val compact = s.replace(" ", "").replace("-", "").uppercase(Locale.US)
        if (compact.length < 15 || compact.length > 34) return false
        if (!compact[0].isLetter() || !compact[1].isLetter()) return false
        if (!compact[2].isDigit() || !compact[3].isDigit()) return false
        if (!compact.all { it.isLetterOrDigit() }) return false
        val rearranged = compact.substring(4) + compact.substring(0, 4)
        var remainder = 0
        for (c in rearranged) {
            remainder = if (c.isDigit()) {
                (remainder * 10 + (c - '0')) % 97
            } else {
                (remainder * 100 + (c - 'A' + 10)) % 97
            }
        }
        return remainder == 1
    }

    // ── Internals ────────────────────────────────────────────────────────────────────

    private fun isUuid(s: String): Boolean =
        s.length == 36 && s[8] == '-' && s[13] == '-' && s[18] == '-' && s[23] == '-'

    private fun sha256Hex(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder(digest.size * 2)
        for (b in digest) sb.append(String.format(Locale.US, "%02x", b))
        return sb.toString()
    }
}
