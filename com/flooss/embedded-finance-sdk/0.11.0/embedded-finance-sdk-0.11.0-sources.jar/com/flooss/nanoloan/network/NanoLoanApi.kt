package com.flooss.nanoloan.network

import com.flooss.nanoloan.network.dto.AcceptOfferRequestDto
import com.flooss.nanoloan.network.dto.AuthTokenDto
import com.flooss.nanoloan.network.dto.BankDetailResponseDto
import com.flooss.nanoloan.network.dto.BanksListResponseDto
import com.flooss.nanoloan.network.dto.EmploymentDetailRequestDto
import com.flooss.nanoloan.network.dto.CreateLoanRequestDto
import com.flooss.nanoloan.network.dto.DeclineOfferRequestDto
import com.flooss.nanoloan.network.dto.EligibilityResponseDto
import com.flooss.nanoloan.network.dto.EmailVerificationRequestDto
import com.flooss.nanoloan.network.dto.EmailVerificationResponseDto
import com.flooss.nanoloan.network.dto.InstallmentsResponseDto
import com.flooss.nanoloan.network.dto.LoanResponseDto
import com.flooss.nanoloan.network.dto.PhoneVerificationRequestDto
import com.flooss.nanoloan.network.dto.ProductsResponseDto
import com.flooss.nanoloan.network.dto.TarabutSyncResponseDto
import com.flooss.nanoloan.network.dto.TarabutTokenRequestDto
import com.flooss.nanoloan.network.dto.TarabutTokenResponseDto
import com.flooss.nanoloan.network.dto.UploadDocumentListResponseDto
import com.flooss.nanoloan.network.dto.VerificationActionDataDto
import okhttp3.MultipartBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * REAL network surface — ported endpoint paths (relative to
 * [com.flooss.nanoloan.config.NanoLoanConfiguration.loanBaseUrl]) match the app's
 * `constants/WebServiceConstants.kt` literals exactly, and the header name (`Authorization`)
 * matches `data/network/Headers.kt#TOKEN`. Only in [NanoLoanEnvironment.MOCK] does the
 * repository skip this interface entirely in favor of
 * [com.flooss.nanoloan.repo.MockNanoLoanDataSource] — see that class for the mocked path.
 *
 * Endpoint provenance (design doc §9.2, Appendix A/B):
 * - eligibility: `WebServiceConstants.FETCH_SOOUQ_BLACKLIST_STATUS` = "api/v1/fo/client/check-eligibility" (`LoanApi.fetchSoouqBlackListStatus`)
 * - submit application: `WebServiceConstants.CREATE_LOAN` = "api/v1/fo/loans" (`LoanApi.create`)
 * - active offer: `WebServiceConstants.GET_ACTIVE_OFFER` = "api/v1/fo/offers/active" (`LoanApi.getActiveOffer`)
 * - accept offer: `WebServiceConstants.ACCEPT_OFFER_NORMAL` = "api/v1/fo/loans/normal/{id}/offers/{offerGuid}/accept" (`LoanApi.acceptOfferNormal`)
 * - decline offer: `WebServiceConstants.REJECT_LOAN_OFFER` = "api/v1/fo/loans/{id}/offers/{offerGuid}/decline" (`LoanApi.rejectOffer`)
 * - products: `WebServiceConstants.GET_PRODUCT` = "api/v2/fo/products" (`SalafApi.hitGetProductApi`)
 * - active loan: `WebServiceConstants.GET_ACTIVE_LOAN` = "api/v1/fo/loans/active" (`LoanApi.getActiveLoan`)
 * - tarabut banks: `WebServiceConstants.GET_TARABUT_BANKS` = "api/v1/fo/tarabut/providers" (`LoanApi.getAllBanksList`)
 * - tarabut intent: `WebServiceConstants.GET_TARABUT_TOKEN` = "api/v1/fo/tarabut/intent" (`LoanApi.getTarabutToken`)
 * - tarabut sync: `WebServiceConstants.TARABUT_SYNC` = "api/v1/fo/tarabut/accounts/sync" (`LoanApi.tarabutSync`)
 * - salary docs upload: `WebServiceConstants.UPLOAD_LOAN_APPLY_PDF_DOCUMENTS` = "api/v1/salary/documents/{folder}/upload" (`SalafApi.hitUploadPdfDocumentApi`)
 * - installments: `WebServiceConstants.GET_ACTIVE_OFFER_INSTALLMENT_V2` = "api/v2/fo/loans/installments" (`LoanApi.getActiveOfferInstallments`)
 * - loan agreement: `WebServiceConstants.GET_LOAN_AGREEMENT` = "api/v1/fo/loans/loan-agreement" (`LoanApi.hitGetLoanAgreement`)
 * - email OTP: `WebServiceConstants.EMAIL_VERIFICATION` = "api/v1/security/verifyEmail/sendEmailOtp" (`LoanApi.verifyEmail`)
 * - SMS OTP: `WebServiceConstants.SEND_SALAF_SMS` = "api/v1/security/verifyPhone/sendSms" (`LoanApi.sendSms`)
 * - verify accept OTP: `WebServiceConstants.ACCEPT_OFFER_OTP_VERIFY` = "api/v1/fo/loans/normal/{id}/offers/{offerGuid}/verify-otp" (`LoanApi.acceptOfferOtpVerify`)
 */
internal interface NanoLoanApi {

    /**
     * Salaf OAuth2 password grant (design doc §7.2 Model B) — faithful port of the app's
     * `SalafAuthTokenApi.hitSalafLoginApi` (`WebServiceConstants.SALAF_AUTHENTICATE` =
     * BASE_URL_SALAF + "api/v1/oauth/token"): same form fields, same values
     * (grant_type=password, username=CPR, password=PIN **sent plain — the app's Salaf
     * branch does NOT AES-encrypt this grant's password; only the non-Salaf
     * `AuthTokenApi.hitLoginApi` branch calls `AesUtil.encrypt`**, client_id/scope from
     * config, client_secret from the SecretProvider, device_type="ANDROID") and the same
     * `X-Client-Location` header the app sends as "".
     */
    @FormUrlEncoded
    @POST("api/v1/oauth/token")
    suspend fun login(
        @Field("grant_type") grantType: String,
        @Field("username") username: String,
        @Field("password") password: String,
        @Field("client_id") clientId: String,
        @Field("client_secret") clientSecret: String,
        @Field("scope") scope: String,
        @Field("device_token") deviceToken: String,
        @Field("device_type") deviceType: String,
        @Header("X-Client-Location") address: String?
    ): Response<AuthTokenDto>

    // `WebServiceConstants.SAVE_USER_EMPLOYMENT_DETAIL` = "api/v1/fo/client-profile/employment-details"
    // (`UserProfileApi.saveEmploymentDetailsApi`) — body is the backend's ClientProfileEmploymentDetailsData.
    @GET("api/v1/fo/profile/attributes/{type}")
    suspend fun getProfileAttributes(
        @Header("Authorization") token: String,
        @retrofit2.http.Path("type") type: String
    ): Response<com.flooss.nanoloan.network.dto.ProfileAttributesDto>

    @POST("api/v1/fo/client-profile/employment-details")
    suspend fun saveEmploymentDetails(
        @Header("Authorization") token: String,
        @Body request: EmploymentDetailRequestDto
    ): Response<ResponseBody>

    // `WebServiceConstants.LOAN_BANK_DETAIL` = "api/v1/fo/loans/disbursement/bank-detail/{iban}"
    // (`LoanApi.hitGetBankDetails`).
    @GET("api/v1/fo/loans/disbursement/bank-detail/{iban}")
    suspend fun getBankDetailForIban(
        @Header("Authorization") token: String,
        @Path("iban") iban: String
    ): Response<BankDetailResponseDto>

    // `WebServiceConstants.DISBURSEMENT_METHOD_IBAN_OR_STC` =
    // "api/v1/fo/applications/disburse-detail/{accountNumber}"
    // (`LoanApi.hitDisbursementMethodIBANOrSTCApi` — @PUT with a disbursementMethod query).
    @PUT("api/v1/fo/applications/disburse-detail/{accountNumber}")
    suspend fun setDisbursementMethod(
        @Header("Authorization") token: String,
        @Path("accountNumber") accountNumber: String,
        @Query("disbursementMethod") disbursementMethod: String
    ): Response<String>

    @GET("api/v1/fo/client/check-eligibility")
    suspend fun checkEligibility(
        @Header("Authorization") token: String
    ): Response<EligibilityResponseDto>

    @GET("api/v2/fo/products")
    suspend fun getProducts(
        @Header("Authorization") token: String
    ): Response<ProductsResponseDto>

    @GET("api/v1/fo/loans/active")
    suspend fun getActiveLoan(
        @Header("Authorization") token: String
    ): Response<LoanResponseDto>

    @GET("api/v1/fo/tarabut/providers")
    suspend fun getTarabutProviders(
        @Header("Authorization") token: String
    ): Response<BanksListResponseDto>

    @POST("api/v1/fo/tarabut/intent")
    suspend fun createTarabutIntent(
        @Header("Authorization") token: String,
        @Body request: TarabutTokenRequestDto
    ): Response<TarabutTokenResponseDto>

    @POST("api/v1/fo/tarabut/accounts/sync")
    suspend fun tarabutSync(
        @Header("Authorization") token: String
    ): Response<TarabutSyncResponseDto>

    // Real endpoint takes three multipart PDF parts (file1/file2/file3) — see
    // SalafApi.hitUploadPdfDocumentApi; {folder} is an UploadUtil enum name
    // (EMPLOYMENT_BANK_STATEMENT for the salary-verification path).
    // Every part is optional on the backend and an empty one is skipped silently, so only
    // the files the customer picked are sent.
    @Multipart
    @POST("api/v1/salary/documents/{folder}/upload")
    suspend fun uploadSalaryDocuments(
        @Header("Authorization") token: String,
        @Path("folder") folder: String,
        @Part files: List<MultipartBody.Part>
    ): Response<UploadDocumentListResponseDto>

    // The wallet lives on another host, so these take absolute URLs built from
    // NanoLoanEnvironment.walletBaseUrl; they still go through the same client and telemetry.
    @GET
    suspend fun walletPublicKey(@retrofit2.http.Url url: String): Response<com.flooss.nanoloan.network.dto.WalletPublicKeyDto>

    @POST
    suspend fun walletValidate(
        @retrofit2.http.Url url: String,
        @Header("Authorization") basicAuth: String,
        @Body request: com.flooss.nanoloan.network.dto.WalletValidateRequestDto
    ): Response<com.flooss.nanoloan.network.dto.WalletValidateResponseDto>

    @POST
    suspend fun walletVerifyOtp(
        @retrofit2.http.Url url: String,
        @Header("Authorization") basicAuth: String,
        @Header("udid") udid: String,
        @Header("origin") origin: String,
        @Body request: com.flooss.nanoloan.network.dto.WalletVerifyOtpRequestDto
    ): Response<ResponseBody>

    @FormUrlEncoded
    @POST
    suspend fun walletToken(
        @retrofit2.http.Url url: String,
        @Header("Authorization") basicAuth: String,
        @Field("grant_type") grantType: String,
        @Field("username") mobileNumber: String,
        @Field("password") encryptedPin: String,
        @Field("udid") udid: String,
        @Field("mobilemake") mobileMake: String,
        @Field("mobilemodel") mobileModel: String
    ): Response<com.flooss.nanoloan.network.dto.WalletTokenDto>

    // The wallet app's UserApi.hitCustomerInfoApi (`WebServiceConstants.CUSTOMER_INFO`). The
    // wallet answers for the signed-in customer (floos-backend CustomerController.getCustomerInfo
    // overrides any customerId with the token's), so no id goes in the URL.
    @GET
    suspend fun walletCustomerInfo(
        @retrofit2.http.Url url: String,
        @Header("Authorization") bearerToken: String,
        @Header("udid") udid: String
    ): Response<com.flooss.nanoloan.network.dto.WalletCustomerInfoDto>

    @GET("api/v1/fo/client-profile")
    suspend fun getClientProfile(
        @Header("Authorization") token: String
    ): Response<com.flooss.nanoloan.network.dto.ClientProfileDto>

    @GET("api/v1/fo/companies/private")
    suspend fun getPrivateCompanies(
        @Header("Authorization") token: String
    ): Response<com.flooss.nanoloan.network.dto.PrivateCompaniesDto>

    @GET("api/v2/fo/loans/installments")
    suspend fun getOfferInstallments(
        @Header("Authorization") token: String
    ): Response<InstallmentsResponseDto>

    // Returns the agreement document bytes (the app reads it as ResponseBody).
    @GET("api/v1/fo/loans/loan-agreement")
    suspend fun getLoanAgreement(
        @Header("Authorization") token: String,
        @Query("loanAppId") loanAppId: Long
    ): Response<ResponseBody>

    @POST("api/v1/security/verifyEmail/sendEmailOtp")
    suspend fun sendEmailOtp(
        @Header("Authorization") token: String,
        @Body request: EmailVerificationRequestDto
    ): Response<EmailVerificationResponseDto>

    // Note: the app's as-is LoanApi.sendSms sends no Authorization header (the phone
    // comes in the body) — mirrored here.
    @POST("api/v1/security/verifyPhone/sendSms")
    suspend fun sendSms(
        @Body request: PhoneVerificationRequestDto
    ): Response<VerificationActionDataDto>

    // The app's acceptOfferOtpVerify posts the same LoanOfferNormalAcceptRequest body
    // (with phoneVerificationCode/phoneVerificationActionUUID set) and reads a String.
    @POST("api/v1/fo/loans/normal/{id}/offers/{offerGuid}/verify-otp")
    suspend fun verifyAcceptOtp(
        @Header("Authorization") token: String,
        @Path("id") id: Long,
        @Path("offerGuid") offerGuid: String,
        @Body request: AcceptOfferRequestDto
    ): Response<String>

    @POST("api/v1/fo/loans")
    suspend fun createLoan(
        @Header("Authorization") token: String,
        @Body request: CreateLoanRequestDto,
        @Header("X-Client-Location") clientLocation: String? = null,
        @Header("X-Device-Latitude") latitude: String? = null,
        @Header("X-Device-Longitude") longitude: String? = null
    ): Response<LoanResponseDto>

    @GET("api/v1/fo/offers/active")
    suspend fun getActiveOffer(
        @Header("Authorization") token: String
    ): Response<LoanResponseDto>

    @POST("api/v1/fo/loans/normal/{id}/offers/{offerGuid}/accept")
    suspend fun acceptOfferNormal(
        @Header("Authorization") token: String,
        @Path("id") id: Long,
        @Path("offerGuid") offerGuid: String,
        @Body request: AcceptOfferRequestDto,
        @Header("X-Client-Location") clientLocation: String? = null
    ): Response<LoanResponseDto>

    // Note: the app's as-is `LoanApi.rejectOffer` binds `offerGuid` via @Query even
    // though `REJECT_LOAN_OFFER`'s URL template has a `{offerGuid}` path placeholder —
    // a latent binding bug in the real app (Retrofit requires every `{name}` placeholder
    // be resolved by a matching @Path). Re-declared correctly here with `offerGuid` as
    // @Path, matching the URL template it's actually built from.
    @POST("api/v1/fo/loans/{id}/offers/{offerGuid}/decline")
    suspend fun declineOffer(
        @Header("Authorization") token: String,
        @Path("id") id: Long,
        @Path("offerGuid") offerGuid: String,
        @Body request: DeclineOfferRequestDto?
    ): Response<LoanResponseDto>
}
