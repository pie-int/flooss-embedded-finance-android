package com.flooss.nanoloan.config

import android.content.res.Resources
import com.flooss.nanoloan.logging.NanoLogLevel
import com.flooss.nanoloan.logging.NanoLogSink
import com.flooss.nanoloan.telemetry.NanoTelemetryConfiguration

/**
 * SDK-wide configuration, supplied once to [com.flooss.nanoloan.NanoLoanSDK.initialize]
 * (design doc §6.1). Trimmed to the fields this POC's core journey (eligibility -> apply
 * -> offer -> accept/decline) actually uses — pinning/tokenization/night-mode/device-info
 * fields from the doc's full §6.1 shape are deferred, see [NanoLoanSDK] backlog comment.
 *
 * [oauthClientSecret] is a [SecretProvider] lambda, never a string literal — this is the
 * direct fix for the design doc's §2.3/§8.1 finding that the real app hardcodes this
 * secret in `AuthInterceptor.kt` (`clientSecret = "f4c0081c-..."`). This SDK module never
 * declares that value anywhere; the host must supply it at runtime (e.g. from its own
 * remote config / secure storage).
 */
data class NanoLoanConfiguration(
    val environment: NanoLoanEnvironment,
    val oauthClientId: String = "front-office-frontend",
    val oauthScope: String = "front_office",
    val oauthClientSecret: SecretProvider,
    val theme: NanoLoanTheme,
    val locale: NanoLoanLocale = NanoLoanLocale.ENGLISH,
    val logLevel: NanoLogLevel = NanoLogLevel.WARNING,
    val logSinks: List<NanoLogSink> = emptyList(),
    /**
     * Per-step ownership (design doc §3.5 Options A/B, §9.5): a step mapped to
     * [NanoStepOwner.HOST] makes the SDK pause at that step, emit
     * [com.flooss.nanoloan.listener.NanoLoanEvent.InputRequired] and wait for
     * [com.flooss.nanoloan.NanoLoanSDK.submitStepInput]. Unmapped steps default to
     * [NanoStepOwner.SDK] (Option A — SDK-presented screen).
     */
    val stepOwnership: Map<NanoLoanStep, NanoStepOwner> = emptyMap(),
    /**
     * §2.1 — the discrete instalment counts the amount screen offers, replacing the
     * ported 2-36 month slider. Product's default is 1/2/3/4 months. Values above
     * [maxTenorMonths] still render, disabled, with the reason on screen: a customer who
     * cannot have six months should see that six months exists and why it is closed to
     * them, not a silently shortened list.
     *
     * Empty or all-above-cap lists fall back to the default so the screen can never
     * render with nothing selectable.
     */
    val tenorOptions: List<Int> = listOf(1, 2, 3, 4),
    /**
     * §2.1 — the approved ceiling on the tenor. This is the HOST's number (it comes out
     * of the pre-approval the host already ran); the SDK does not compute it and does not
     * second-guess it.
     */
    val maxTenorMonths: Int = 4,
    /**
     * §2.3 — the additional-KYC step's fields, as descriptors so a host can extend the
     * step without waiting for an SDK release. Null keeps the SDK's own default set
     * (nationality, marital status, dependants, address, email); an EMPTY list is
     * meaningful and different — it means the host has nothing to ask, and the step is
     * skipped entirely.
     */
    val kycFields: List<com.flooss.nanoloan.model.KycField>? = null,
    /**
     * The partner key Flooss issues for the chosen [environment] (`nlk_test_…` for UAT and
     * MOCK, `nlk_live_…` for PROD). It identifies the partner to the SDK Operations
     * Back-Office, which records every journey session under it. Null sends nothing.
     * A key from the other band is refused by the back-office, so the SDK does not send it.
     */
    val partnerKey: SecretProvider? = null,
    /**
     * Adds approved amount, tenor, APR and instalment to the offer events the back-office
     * receives. Off by default: commercial data is the partner's decision to share.
     */
    val shareBusinessMetrics: Boolean = false,
    /**
     * Back-office v2 spec §2 — the host's OWN opaque customer reference, sent once per
     * session so a partner's support desk can find a session from the id it already
     * holds. Its internal customer id, a UUID, a hashed account number: anything
     * meaningless outside the host's own systems.
     *
     * **Must not be a customer identifier.** Max 64 characters, and the SDK REFUSES to
     * transmit a value that is email- or phone-shaped, a bare 9+ digit number (CPR or
     * PAN) or a valid IBAN — it logs a warning naming the shape, never the value, and
     * sends the session without the field. The back-office answers 422 for the same
     * shapes; failing here means a partner finds out while integrating.
     */
    val externalUserRef: String? = null
) {
    /** MOCK is equivalent to `environment == NanoLoanEnvironment.MOCK` — kept as a convenience read. */
    val isMockMode: Boolean get() = environment == NanoLoanEnvironment.MOCK

    internal val loanBaseUrl: String get() = environment.loanBaseUrl.orEmpty()

    internal val telemetry: NanoTelemetryConfiguration
        get() {
            val key = partnerKey ?: return NanoTelemetryConfiguration.disabled
            val keyValue = runCatching { key.get() }.getOrNull().orEmpty()
            val wantLive = environment == NanoLoanEnvironment.PROD
            if (keyValue.startsWith(if (wantLive) "nlk_live_" else "nlk_test_").not()) {
                return NanoTelemetryConfiguration.disabled
            }
            return NanoTelemetryConfiguration(
                enabled = true,
                endpoint = environment.backOfficeUrl,
                apiKey = key,
                businessMetrics = shareBusinessMetrics
            )
        }

    /** False when [partnerKey] is set but belongs to the other band than [environment]. */
    val partnerKeyMatchesEnvironment: Boolean
        get() = partnerKey == null || telemetry.enabled

    fun ownerOf(step: NanoLoanStep): NanoStepOwner = stepOwnership[step] ?: NanoStepOwner.SDK

    /**
     * [kycFields], or the SDK's default set when the host supplied none. An empty list
     * supplied by the host stays empty — that is a decision, not a missing value.
     */
    fun resolvedKycFields(resources: Resources): List<com.flooss.nanoloan.model.KycField> {
        kycFields?.let { return it }
        return listOf(
            com.flooss.nanoloan.model.KycField(
                "nationality",
                resources.getString(com.flooss.nanoloan.R.string.nanoloan_kyc_nationality)
            ),
            com.flooss.nanoloan.model.KycField(
                "maritalStatus",
                resources.getString(com.flooss.nanoloan.R.string.nanoloan_kyc_marital_status)
            ),
            com.flooss.nanoloan.model.KycField(
                "dependants",
                resources.getString(com.flooss.nanoloan.R.string.nanoloan_kyc_dependants),
                com.flooss.nanoloan.model.KycKeyboard.NUMBER
            ),
            com.flooss.nanoloan.model.KycField(
                "residentialAddress",
                resources.getString(com.flooss.nanoloan.R.string.nanoloan_kyc_address)
            ),
            com.flooss.nanoloan.model.KycField(
                "email",
                resources.getString(com.flooss.nanoloan.R.string.nanoloan_kyc_email),
                com.flooss.nanoloan.model.KycKeyboard.EMAIL
            )
        )
    }

    /** [tenorOptions] sorted, de-duplicated and never empty. */
    val resolvedTenorOptions: List<Int>
        get() = tenorOptions.filter { it > 0 }.distinct().sorted()
            .ifEmpty { listOf(1, 2, 3, 4) }

    /** The longest option the cap allows, or the shortest option when the cap excludes all. */
    val defaultTenorMonths: Int
        get() = resolvedTenorOptions.lastOrNull { it <= maxTenorMonths }
            ?: resolvedTenorOptions.first()
}

/** Never give this a hardcoded default — see [NanoLoanConfiguration.oauthClientSecret] doc. */
fun interface SecretProvider {
    fun get(): String
}
