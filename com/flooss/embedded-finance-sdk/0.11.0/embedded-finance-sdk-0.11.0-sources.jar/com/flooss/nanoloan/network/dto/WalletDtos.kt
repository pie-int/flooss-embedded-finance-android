package com.flooss.nanoloan.network.dto

/** `GET {wallet}api/v1/public/rsa-public-key` — Base64 of the PEM the wallet encrypts PINs with. */
internal data class WalletPublicKeyDto(val data: String? = null)

/** `POST {wallet}api/v1/customer/validate` — the wallet app's VerifyReq. */
internal data class WalletValidateRequestDto(
    val username: String,
    val pin: String,
    val udid: String,
    val isBioLogin: Boolean = false,
    val firstLogin: Boolean = false
)

/**
 * A wrong PIN is a 200 with `valid=false`, `errorCode` 30004 (or 30001 on a first login) and
 * the wallet's localised message (floos-backend CustomerServiceImpl.updateAndValidatePinWrongAttemptsCount).
 */
internal data class WalletValidateResponseDto(
    val data: WalletValidateDataDto? = null,
    val message: String? = null,
    val errorCode: Int? = null
)

internal data class WalletValidateDataDto(
    val valid: Boolean? = null,
    val trustedDevice: Boolean? = null,
    val actionUuid: String? = null,
    val phoneNumber: String? = null,
    val failedCount: Int? = null
)

/** `POST {wallet}api/v1/system/verify-otp` — the wallet app's SmsVerifyReq; otp is RSA-encrypted. */
internal data class WalletVerifyOtpRequestDto(val actionUuid: String, val otp: String, val phoneNumber: String)

/** `POST {wallet}oauth/token` — the wallet app's AuthTokenResp, trimmed. */
internal data class WalletTokenDto(
    val access_token: String? = null,
    val expires_in: Long? = null,
    val customerId: Long? = null
)

/**
 * `GET {wallet}api/v1/customer/info` — the wallet app's CustomerInfoRes, trimmed to the
 * identifications, which carry the customer's CPR (`identificationType` "CPR").
 */
internal data class WalletCustomerInfoDto(val data: WalletCustomerInfoDataDto? = null)

internal data class WalletCustomerInfoDataDto(val identifications: List<WalletIdentificationDto>? = null)

internal data class WalletIdentificationDto(
    val identificationType: String? = null,
    val identificationValue: String? = null
) {
    override fun toString(): String = "WalletIdentificationDto(identificationType=$identificationType, identificationValue=•••)"
}
