package com.flooss.nanoloan.journey

import com.flooss.nanoloan.model.JourneyRequest
import com.flooss.nanoloan.model.JourneyStatus
import com.flooss.nanoloan.result.NanoLoanError
import java.math.BigDecimal

/** What running one step produced. */
internal sealed class StepOutcome {
    object Completed : StepOutcome()

    /** The customer went back into an earlier step of type [toType]; its screen is already showing. */
    data class Back(val toType: String) : StepOutcome()

    data class Ended(val status: JourneyStatus) : StepOutcome()

    /**
     * Done, and the journey continues at the plan's next step of type [toType]: a customer
     * with an offer already waiting resumes there. With no such step ahead, the next step runs.
     */
    data class SkipTo(val toType: String) : StepOutcome()

    data class Failed(val error: NanoLoanError) : StepOutcome()
}

/** What the steps learned along the way; the journey's result is built from it. */
internal class JourneyContext(val plan: JourneyPlan, val request: JourneyRequest) {
    /** Requested amount: the plan's, else the host's. */
    val requestedAmount: BigDecimal? get() = plan.amount ?: request.amount

    /** The most this customer can get, when eligibility says so. */
    var customerMax: BigDecimal? = null
    var split: FinancingSplit? = null
    var financedAmount: BigDecimal? = null
    var applicationId: Long? = null
    var salafStatus: String? = null
    var merchantTransactionRef: String? = null

    /** The existing loan's balance, kept for [JourneyStatus.EXISTING_LOAN] and [JourneyStatus.LOAN_OVERDUE] only. */
    var outstandingAmount: BigDecimal? = null

    /** The waiting offer the journey resumes at, when sign-in found one. */
    var resumedOffer: com.flooss.nanoloan.model.LoanOffer? = null

    /** The eligibility answer sign-in already got (a customer with a running loan), so the eligibility step does not ask again. */
    var preApproval: com.flooss.nanoloan.model.PreApprovalResult? = null

    fun patchResult(errorCode: String? = null) = JourneyPatchResult(
        financedAmount = financedAmount,
        remainderAmount = split?.remainder,
        applicationId = applicationId,
        merchantTransactionRef = merchantTransactionRef,
        salafStatus = salafStatus,
        errorCode = errorCode
    )
}

internal interface JourneyStepRunner {
    /** @param resume the customer came back to this step; its screen is already showing. */
    suspend fun run(step: PlanStep, context: JourneyContext, resume: Boolean): StepOutcome
}

internal sealed class EngineOutcome {
    data class Ended(val status: JourneyStatus) : EngineOutcome()
    data class Failed(val error: NanoLoanError) : EngineOutcome()
}

/**
 * Runs an ALLOWED plan's steps in order and reports each to the back office: a
 * STEP_COMPLETED per finished step, then one COMPLETED, FAILED or ABANDONED.
 */
internal class NanoJourneyEngine(
    private val plan: JourneyPlan,
    private val reporter: JourneyReporter,
    private val runner: JourneyStepRunner
) {
    suspend fun run(context: JourneyContext): EngineOutcome {
        val steps = plan.steps
        var index = 0
        var resume = false
        while (index < steps.size) {
            val step = steps[index].resolved(context.financedAmount)
            when (val outcome = runner.run(step, context, resume)) {
                is StepOutcome.Completed -> {
                    reporter.report(step.type, JourneyPatchStatus.STEP_COMPLETED)
                    index++
                    resume = false
                }
                is StepOutcome.SkipTo -> {
                    reporter.report(step.type, JourneyPatchStatus.STEP_COMPLETED)
                    val target = (index + 1 until steps.size).firstOrNull { steps[it].type == outcome.toType }
                    index = target ?: (index + 1)
                    resume = false
                }
                is StepOutcome.Back -> {
                    val target = (index - 1 downTo 0).firstOrNull { steps[it].type == outcome.toType }
                    if (target == null) {
                        finish(step.type, JourneyStatus.ABANDONED, context)
                        return EngineOutcome.Ended(JourneyStatus.ABANDONED)
                    }
                    index = target
                    resume = true
                }
                is StepOutcome.Ended -> {
                    finish(step.type, outcome.status, context)
                    return EngineOutcome.Ended(outcome.status)
                }
                is StepOutcome.Failed -> {
                    reporter.report(
                        step.type,
                        JourneyPatchStatus.FAILED,
                        context.patchResult(errorCode = errorCode(outcome.error))
                    )
                    return EngineOutcome.Failed(outcome.error)
                }
            }
        }
        finish(steps.lastOrNull()?.type ?: JourneySteps.DONE, JourneyStatus.COMPLETED, context)
        return EngineOutcome.Ended(JourneyStatus.COMPLETED)
    }

    private fun finish(step: String, status: JourneyStatus, context: JourneyContext) {
        if (status in SIGN_IN_OUTCOMES) {
            // What sign-in found about the customer: only the code (and the application under
            // review) goes to the back office, never the mobile, CPR or an existing loan's amounts.
            val applicationId = context.applicationId.takeIf { status == JourneyStatus.APPLICATION_IN_REVIEW }
            reporter.report(step, JourneyPatchStatus.FAILED, JourneyPatchResult(applicationId = applicationId, errorCode = status.name))
            return
        }
        val (patchStatus, code) = when (status) {
            JourneyStatus.COMPLETED -> JourneyPatchStatus.COMPLETED to null
            JourneyStatus.ABANDONED -> JourneyPatchStatus.ABANDONED to null
            JourneyStatus.OFFER_DECLINED -> JourneyPatchStatus.ABANDONED to status.name
            JourneyStatus.HOST_OFFER_SELECTED -> JourneyPatchStatus.ABANDONED to status.name
            else -> JourneyPatchStatus.FAILED to status.name
        }
        reporter.report(step, patchStatus, context.patchResult(errorCode = code))
    }

    companion object {
        /** How sign-in can end a journey before it starts; each is a FAILED sign_in with its name as the errorCode. */
        val SIGN_IN_OUTCOMES: Set<JourneyStatus> = setOf(
            JourneyStatus.NOT_A_FLOOSS_CUSTOMER,
            JourneyStatus.ACCOUNT_LOCKED,
            JourneyStatus.APPLICATION_IN_REVIEW,
            JourneyStatus.EXISTING_LOAN,
            JourneyStatus.LOAN_OVERDUE
        )

        fun errorCode(error: NanoLoanError): String = when (error) {
            is NanoLoanError.JourneyNotEnabled -> error.reason
            else -> error.errorCode.takeIf { it != 0 }?.toString() ?: error::class.java.simpleName
        }
    }
}
