package com.flooss.nanoloan.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R

/**
 * Step 4 — accept confirmation. ADAPTED, not a verbatim :app port (the real app jumps
 * straight into disbursement-channel selection after accepting, which is out of this
 * POC's scope); built from the real offer screen's visual building blocks — see
 * nanoloan_fragment_confirmation.xml.
 */
internal class NanoLoanConfirmationFragment : NanoLoanJourneyFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_confirmation, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme

        setUpHeader(
            headerRoot = view.findViewById(R.id.header),
            title = getString(R.string.nanoloan_title_approved),
            dotCount = 3,
            dotIndex = 3,
            screenNumber = "12/12",
            stepName = STEP_NAME
        ) {
            journeyHost.finishJourney()
        }

        val bhd = getString(R.string.bhd_app_text)
        val offer = journeyData.offer
        view.findViewById<TextView>(R.id.confirmed_amount).text =
            offer?.loanAmount?.let { NanoLoanMath.formatDouble(it.toDouble()) + " $bhd" }
                ?: "${journeyData.loanAmount} $bhd"
        view.findViewById<TextView>(R.id.confirmed_installment).text =
            offer?.installmentAmount?.let { NanoLoanMath.formatDouble(it.toDouble()) + " $bhd" } ?: " "

        val doneBtn = view.findViewById<View>(R.id.done_btn)
        NanoLoanThemeApplier.applyPrimaryButton(doneBtn, theme)
        doneBtn.setOnClickListener { journeyHost.finishJourney() }
    }

    companion object {
        const val STEP_NAME = "accept_confirmation"
    }
}
