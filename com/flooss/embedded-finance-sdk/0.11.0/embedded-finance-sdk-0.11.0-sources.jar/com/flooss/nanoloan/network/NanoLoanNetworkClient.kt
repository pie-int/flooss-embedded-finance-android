package com.flooss.nanoloan.network

import com.flooss.nanoloan.config.NanoLoanConfiguration
import com.flooss.nanoloan.logging.NanoLoanLogger
import com.flooss.nanoloan.logging.NanoLogLevel
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Builds the REAL Retrofit/OkHttp stack from [NanoLoanConfiguration.loanBaseUrl] (design
 * doc §10 — one `NanoNetworkClient` owning base URL + interceptors). Only used when
 * [NanoLoanConfiguration.isMockMode] is false; [com.flooss.nanoloan.repo.NanoLoanRepository]
 * skips this entirely in mock mode.
 *
 * Deferred from the design doc's target shape (§8.3, §10): certificate/public-key
 * pinning (`NanoPinningPolicy`), request signing, tokenization hooks, refresh-serialization
 * against concurrent 401s. This POC ships a plain OkHttpClient with only a logging
 * interceptor gated by [NanoLoanConfiguration.logLevel] — never at BODY level without the
 * PII-redaction utility the design doc (§8.5) calls for, which is also not implemented in
 * this pass (backlog).
 */
internal object NanoLoanNetworkClient {

    /**
     * @param onApiCall reports every REAL wire call (method + encoded path + actual HTTP
     * status; -1 when the request failed before any response, e.g. DNS/transport error)
     * plus the wall-clock duration measured around `chain.proceed()`, so the facade can
     * emit [com.flooss.nanoloan.listener.NanoLoanEvent.ApiCallExecuted] — the live twin of
     * the MOCK path's ApiCallSimulated sequence — and telemetry can carry a REAL
     * `durationMs` (contract §3).
     */
    fun create(
        configuration: NanoLoanConfiguration,
        logger: NanoLoanLogger,
        onApiCall: (method: String, path: String, httpStatus: Int, durationMs: Int) -> Unit =
            { _, _, _, _ -> }
    ): NanoLoanApi {
        val loggingInterceptor = HttpLoggingInterceptor { message ->
            logger.d("NanoLoanNetwork", message)
        }.apply {
            // Ships disabled by default; only BASIC (no bodies, no PII) even at DEBUG,
            // matching the design doc's "never BODY without redaction" rule (§8.5, §10).
            level = if (configuration.logLevel == NanoLogLevel.DEBUG) {
                HttpLoggingInterceptor.Level.BASIC
            } else {
                HttpLoggingInterceptor.Level.NONE
            }
        }

        // API-sequence + timing reporter — never touches bodies (no PII), only
        // method/path/status and the elapsed time around chain.proceed().
        //
        // Placed as an APPLICATION interceptor, so one report covers the whole logical
        // call including OkHttp's own retries and redirects — which is what "how long did
        // this endpoint take" means to the operator reading the console, and what
        // contract §3 `durationMs` is for. A network interceptor would fire once per
        // physical attempt and under-report a retried call.
        //
        // elapsedRealtime-equivalent monotonic source: System.nanoTime() is unaffected by
        // wall-clock/NTP jumps, unlike currentTimeMillis().
        val sequenceInterceptor = okhttp3.Interceptor { chain ->
            val request = chain.request()
            val method = request.method
            val path = request.url.encodedPath +
                (request.url.encodedQuery?.let { "?$it" } ?: "")
            val startedAtNanos = System.nanoTime()
            fun elapsedMs(): Int =
                ((System.nanoTime() - startedAtNanos) / 1_000_000L).coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()
            try {
                val response = chain.proceed(request)
                onApiCall(method, path, response.code, elapsedMs())
                response
            } catch (e: java.io.IOException) {
                onApiCall(method, path, -1, elapsedMs())
                throw e
            } catch (e: RuntimeException) {
                // e.g. SecurityException when the host app lacks INTERNET permission.
                // Re-wrapped as IOException so OkHttp's dispatcher thread does not
                // rethrow-and-crash the process; surfaces as a typed NoInternet error.
                onApiCall(method, path, -1, elapsedMs())
                throw java.io.IOException("Transport failure: $e", e)
            }
        }

        val okHttpClient = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .addInterceptor(sequenceInterceptor)
            .addInterceptor(loggingInterceptor)
            .build()

        val baseUrl = if (configuration.loanBaseUrl.endsWith("/")) {
            configuration.loanBaseUrl
        } else {
            "${configuration.loanBaseUrl}/"
        }

        val retrofit = Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        return retrofit.create(NanoLoanApi::class.java)
    }
}
