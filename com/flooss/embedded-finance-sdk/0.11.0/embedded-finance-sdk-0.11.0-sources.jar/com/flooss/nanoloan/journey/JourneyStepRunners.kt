package com.flooss.nanoloan.journey

import com.flooss.nanoloan.model.JourneyStatus
import com.flooss.nanoloan.model.PreApprovalResult
import com.flooss.nanoloan.repo.CustomerLoanState
import com.flooss.nanoloan.result.NanoLoanResult
import java.math.BigDecimal

/** What a customer-status screen shows after sign-in. */
internal sealed class CustomerStatusScreen {
    data class InReview(val applicationId: Long?) : CustomerStatusScreen()
    data class Overdue(val outstandingAmount: BigDecimal?) : CustomerStatusScreen()

    /** A running loan; [eligible] is Salaf's answer on another one. */
    data class ActiveLoan(
        val outstandingAmount: BigDecimal,
        val nextInstalmentAmount: BigDecimal?,
        val nextInstalmentDate: String?,
        val eligible: Boolean
    ) : CustomerStatusScreen()
}

/** The screens: shows [step] (unless [resume]) and returns once the customer leaves it. */
internal interface JourneyScreens {
    suspend fun run(step: PlanStep, context: JourneyContext, resume: Boolean): StepOutcome

    /**
     * The SDK's sign-in screens (mobile, Flooss PIN, SMS code). [StepOutcome.Completed] once
     * the customer is signed in; otherwise how the customer left (not a Flooss customer,
     * locked, or closed).
     */
    suspend fun signIn(step: PlanStep, context: JourneyContext): StepOutcome =
        StepOutcome.Ended(JourneyStatus.ABANDONED)

    /** One customer-status screen. [StepOutcome.Completed] when the customer continues. */
    suspend fun customerStatus(step: PlanStep, context: JourneyContext, screen: CustomerStatusScreen): StepOutcome =
        StepOutcome.Ended(JourneyStatus.ABANDONED)
}

/**
 * Runs the headless steps here and hands every other step to [screens].
 *
 * - `sign_in`: unless a session already exists (a host token, or the deprecated credential
 *   handoff), the SDK's sign-in screens. Then what the customer already has with Flooss
 *   decides the route: nothing, go on; an offer waiting, resume at `offer`; an application
 *   in review or an overdue loan, end there; a running loan, Salaf's eligibility check
 *   decides. The SDK only routes on Salaf's answers.
 * - `eligibility`: the soft pre-approval, as `checkLoanEligibility` (once per journey).
 * - `financing_split`: works out the split, then lets the customer confirm it on screen.
 */
internal class DefaultJourneyStepRunner(
    private val screens: JourneyScreens,
    private val isSignedIn: () -> Boolean,
    private val checkEligibility: suspend () -> NanoLoanResult<PreApprovalResult>,
    private val customerLoanState: suspend () -> NanoLoanResult<CustomerLoanState> =
        { NanoLoanResult.Success(CustomerLoanState.NoLoans) }
) : JourneyStepRunner {

    override suspend fun run(step: PlanStep, context: JourneyContext, resume: Boolean): StepOutcome =
        when (step.type) {
            JourneySteps.SIGN_IN -> signIn(step, context)
            JourneySteps.ELIGIBILITY -> {
                val cached = context.preApproval
                val result = if (cached != null) NanoLoanResult.Success(cached) else checkEligibility()
                when (result) {
                    is NanoLoanResult.Success ->
                        if (result.value.approved) {
                            context.customerMax = result.value.indicativeMaxAmount
                            StepOutcome.Completed
                        } else {
                            StepOutcome.Ended(JourneyStatus.NOT_APPROVED)
                        }
                    is NanoLoanResult.Failure -> StepOutcome.Failed(result.error)
                }
            }
            JourneySteps.FINANCING_SPLIT -> financingSplit(step, context, resume)
            else -> screens.run(step, context, resume)
        }

    private suspend fun signIn(step: PlanStep, context: JourneyContext): StepOutcome {
        if (!isSignedIn()) {
            val signedIn = screens.signIn(step, context)
            if (signedIn != StepOutcome.Completed) return signedIn
        }
        val state = when (val result = customerLoanState()) {
            is NanoLoanResult.Failure -> return StepOutcome.Failed(result.error)
            is NanoLoanResult.Success -> result.value
        }
        return when (state) {
            CustomerLoanState.NoLoans -> StepOutcome.Completed
            is CustomerLoanState.OfferReady -> {
                context.resumedOffer = state.offer
                context.applicationId = state.offer.id
                StepOutcome.SkipTo(JourneySteps.OFFER)
            }
            is CustomerLoanState.InReview -> {
                context.applicationId = state.applicationId
                screens.customerStatus(step, context, CustomerStatusScreen.InReview(state.applicationId))
                StepOutcome.Ended(JourneyStatus.APPLICATION_IN_REVIEW)
            }
            is CustomerLoanState.Overdue -> {
                context.outstandingAmount = state.outstandingAmount
                screens.customerStatus(step, context, CustomerStatusScreen.Overdue(state.outstandingAmount))
                StepOutcome.Ended(JourneyStatus.LOAN_OVERDUE)
            }
            is CustomerLoanState.ActiveLoan -> activeLoan(step, context, state)
        }
    }

    private suspend fun activeLoan(step: PlanStep, context: JourneyContext, loan: CustomerLoanState.ActiveLoan): StepOutcome {
        val preApproval = when (val result = checkEligibility()) {
            is NanoLoanResult.Failure -> return StepOutcome.Failed(result.error)
            is NanoLoanResult.Success -> result.value
        }
        val screen = CustomerStatusScreen.ActiveLoan(
            loan.outstandingAmount, loan.nextInstalmentAmount, loan.nextInstalmentDate, eligible = preApproval.approved
        )
        if (!preApproval.approved) {
            context.outstandingAmount = loan.outstandingAmount
            screens.customerStatus(step, context, screen)
            return StepOutcome.Ended(JourneyStatus.EXISTING_LOAN)
        }
        context.preApproval = preApproval
        return screens.customerStatus(step, context, screen)
    }

    private suspend fun financingSplit(step: PlanStep, context: JourneyContext, resume: Boolean): StepOutcome {
        if (!resume) {
            val requested = step.decimal("amount") ?: context.requestedAmount
                ?: return StepOutcome.Completed
            val limits = context.plan.limits
            val split = FinancingSplit.compute(
                requested = requested,
                min = step.decimal("min") ?: limits.min,
                max = step.decimal("max") ?: limits.max,
                partialFinancing = step.bool("partialFinancing") ?: limits.partialFinancing,
                customerMax = context.customerMax
            ) ?: return StepOutcome.Ended(JourneyStatus.NOT_APPROVED)
            context.split = split
            context.financedAmount = split.financed
        }
        return screens.run(step, context, resume)
    }
}
