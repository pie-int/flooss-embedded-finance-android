package com.flooss.nanoloan.model

/**
 * SDK_V3_PRODUCT_GAPS §2.4 — the bureau/BCRB material the HOST passes into the second
 * phase of the decision, via [com.flooss.nanoloan.NanoLoanSDK.submitFinalCheck].
 *
 * Every field here is the host's. The SDK does not fetch bureau data, does not cache it
 * and does not judge its freshness: **final approval is subject to the latest BCRB
 * document the host supplies**, which is stated on the screen and is not modelled as an
 * SDK-owned rule.
 *
 * Money is integer fils (1 BHD = 1000 fils), like every other amount on this API.
 *
 * @param bcrbDocumentReference the host's reference for the BCRB document this decision
 *   is made against. Null means the host has not supplied one — a decision cannot be
 *   final without it.
 * @param bcrbDocumentDate the document's date, as the host holds it (ISO-8601 preferred).
 * @param bureauScore the bureau score the host obtained, if it discloses one.
 * @param existingMonthlyCommitmentsFils the customer's existing monthly obligations.
 * @param activeLoanCount how many facilities the bureau reports.
 */
data class BureauInput(
    val bcrbDocumentReference: String? = null,
    val bcrbDocumentDate: String? = null,
    val bureauScore: Int? = null,
    val existingMonthlyCommitmentsFils: Long? = null,
    val activeLoanCount: Int? = null
)

/**
 * §2.4 — the outcome of the second-phase decision.
 *
 * On approval the amount and terms are the ones actually approved, which need not match
 * what the soft pre-approval indicated. On decline [reasonCode] is a CODE, never the free
 * text a customer or an agent typed — a coded reason is what a decline-reason breakdown
 * can be built on.
 */
data class FinalCheckResult(
    val approved: Boolean,
    val approvedAmountFils: Long? = null,
    val tenorMonths: Int? = null,
    val monthlyInstalmentFils: Long? = null,
    val totalPayableFils: Long? = null,
    val reasonCode: String? = null,
    /** Display text for [reasonCode]; the code is what analytics use. */
    val reasonMessage: String? = null
) {
    companion object {
        /** The host supplied no BCRB document reference, so nothing can be made final. */
        const val REASON_BCRB_DOCUMENT_MISSING = "BCRB_DOCUMENT_MISSING"
    }
}
