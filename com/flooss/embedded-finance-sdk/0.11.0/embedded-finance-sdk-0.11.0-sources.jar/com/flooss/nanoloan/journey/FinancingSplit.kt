package com.flooss.nanoloan.journey

import java.math.BigDecimal

/** How much of [requested] Flooss finances; the customer pays [remainder] themselves. */
internal data class FinancingSplit(
    val requested: BigDecimal,
    val financed: BigDecimal,
    val remainder: BigDecimal
) {
    companion object {
        /**
         * [max] is the partner's ceiling for the step; [customerMax] the most this
         * customer can get, when eligibility says so. The lower of the two caps the
         * financed amount. Null when nothing can be financed: below [min], or more than
         * the cap is asked and [partialFinancing] is off.
         */
        fun compute(
            requested: BigDecimal,
            min: BigDecimal?,
            max: BigDecimal?,
            partialFinancing: Boolean,
            customerMax: BigDecimal?
        ): FinancingSplit? {
            if (requested.signum() <= 0) return null
            val cap = listOfNotNull(max, customerMax).minOrNull()
            val financed = if (cap != null && requested > cap) cap else requested
            if (financed < requested && !partialFinancing) return null
            if (min != null && financed < min) return null
            if (financed.signum() <= 0) return null
            return FinancingSplit(requested, financed, requested - financed)
        }
    }
}
