package com.flooss.nanoloan.telemetry

/**
 * Mechanical transcription of the back-office ingestion contract
 * (`nanoloan-backoffice/docs/TELEMETRY_CONTRACT.md`, `contractVersion: 1`).
 *
 * The §4 vocabularies are CLOSED: the server answers 422 for an unknown name, so
 * every emission site goes through the constants here and
 * [NanoTelemetryContract.isValidName] is asserted before an event is buffered. Nothing
 * in this file may be widened without bumping [CONTRACT_VERSION] on all three sides.
 */
internal object NanoTelemetryContract {

    const val CONTRACT_VERSION = 1

    /** Contract §2 — batch cap. [NanoTelemetryConfiguration.maxBatchSize] is clamped to this. */
    const val MAX_BATCH_SIZE = 500

    /** Contract §3 — `kind`. */
    object Kind {
        const val API_CALL = "api_call"
        const val STATE = "state"
        const val LIFECYCLE = "lifecycle"
        const val ERROR = "error"
        const val LOG = "log"

        val ALL = setOf(API_CALL, STATE, LIFECYCLE, ERROR, LOG)
    }

    /**
     * Contract §4 — `lifecycle` vocabulary, verbatim and complete.
     */
    object Lifecycle {
        const val SDK_INITIALIZED = "sdk_initialized"
        const val SESSION_AUTHENTICATED = "session_authenticated"
        const val SESSION_EXPIRED = "session_expired"
        const val JOURNEY_STARTED = "journey_started"
        const val JOURNEY_DISMISSED = "journey_dismissed"
        const val STEP_ENTERED = "step_entered"
        const val STEP_COMPLETED = "step_completed"
        const val STEP_SKIPPED = "step_skipped"
        const val STEP_OWNERSHIP = "step_ownership"
        const val INPUT_REQUIRED = "input_required"
        const val INPUT_SUBMITTED = "input_submitted"
        const val ELIGIBILITY_CHECKED = "eligibility_checked"
        const val PREAPPROVAL_SHOWN = "preapproval_shown"
        const val EMPLOYMENT_SAVED = "employment_saved"
        const val SALARY_VERIFIED = "salary_verified"
        const val OFFER_SHOWN = "offer_shown"
        const val OFFER_REVISED = "offer_revised"
        const val OFFER_ACCEPTED = "offer_accepted"
        const val OFFER_REJECTED = "offer_rejected"
        const val DISBURSEMENT_SET = "disbursement_set"
        const val OTP_REQUESTED = "otp_requested"
        const val OTP_VERIFIED = "otp_verified"
        const val AGREEMENTS_SIGNED = "agreements_signed"
        const val JOURNEY_COMPLETED = "journey_completed"

        // SDK_V3_PRODUCT_GAPS §4 — the v3 screens. The server's vocabulary is CLOSED, so
        // the back-office must learn these names before a v3 SDK points at it; until it
        // does, a batch carrying one of them is rejected whole (addendum §C).
        const val OFFER_COMPARISON_SHOWN = "offer_comparison_shown"
        const val OFFER_SELECTED = "offer_selected"
        const val KYC_DETAILS_SUBMITTED = "kyc_details_submitted"
        const val FINAL_CHECK_STARTED = "final_check_started"
        const val FINAL_DECISION = "final_decision"
        const val DOCUMENT_SIGNED = "document_signed"
        const val DIRECT_DEBIT_SETUP = "direct_debit_setup"
        const val MANDATE_AUTHORISED = "mandate_authorised"

        val ALL = setOf(
            SDK_INITIALIZED, SESSION_AUTHENTICATED, SESSION_EXPIRED, JOURNEY_STARTED,
            JOURNEY_DISMISSED, STEP_ENTERED, STEP_COMPLETED, STEP_SKIPPED, STEP_OWNERSHIP,
            INPUT_REQUIRED, INPUT_SUBMITTED, ELIGIBILITY_CHECKED, PREAPPROVAL_SHOWN,
            EMPLOYMENT_SAVED, SALARY_VERIFIED, OFFER_SHOWN, OFFER_REVISED, OFFER_ACCEPTED,
            OFFER_REJECTED, DISBURSEMENT_SET, OTP_REQUESTED, OTP_VERIFIED,
            AGREEMENTS_SIGNED, JOURNEY_COMPLETED,
            OFFER_COMPARISON_SHOWN, OFFER_SELECTED, KYC_DETAILS_SUBMITTED,
            FINAL_CHECK_STARTED, FINAL_DECISION, DOCUMENT_SIGNED,
            DIRECT_DEBIT_SETUP, MANDATE_AUTHORISED
        )
    }

    /**
     * Contract §4 — `state` vocabulary, verbatim and complete. Note this is NOT the same
     * set as [com.flooss.nanoloan.listener.NanoLoanState]: see
     * [NanoTelemetryMapper.stateName] for the lossy projection and the four internal
     * states the contract has no name for.
     */
    object State {
        const val IDLE = "Idle"
        const val CHECKING_ELIGIBILITY = "CheckingEligibility"
        const val ELIGIBLE = "Eligible"
        const val INELIGIBLE = "Ineligible"
        const val VERIFYING_SALARY = "VerifyingSalary"
        const val SALARY_VERIFIED = "SalaryVerified"
        const val SUBMITTING_APPLICATION = "SubmittingApplication"
        const val AWAITING_OFFER = "AwaitingOffer"
        const val OFFER_READY = "OfferReady"
        const val REQUESTING_ACCEPTANCE_OTP = "RequestingAcceptanceOtp"
        const val AWAITING_ACCEPTANCE_OTP = "AwaitingAcceptanceOtp"
        const val VERIFYING_ACCEPTANCE_OTP = "VerifyingAcceptanceOtp"
        const val ACCEPTED = "Accepted"
        const val REJECTED = "Rejected"
        const val FAILED = "Failed"

        val ALL = setOf(
            IDLE, CHECKING_ELIGIBILITY, ELIGIBLE, INELIGIBLE, VERIFYING_SALARY,
            SALARY_VERIFIED, SUBMITTING_APPLICATION, AWAITING_OFFER, OFFER_READY,
            REQUESTING_ACCEPTANCE_OTP, AWAITING_ACCEPTANCE_OTP, VERIFYING_ACCEPTANCE_OTP,
            ACCEPTED, REJECTED, FAILED
        )
    }

    /** Contract §3 — the `step` field's closed set (plus null). */
    object Step {
        const val APPLY = "apply"
        const val EMPLOYMENT = "employment"
        const val SALARY = "salary"
        const val CONFIRM = "confirm"
        const val OFFER = "offer"
        const val DISBURSEMENT = "disbursement"
        const val OTP = "otp"
        const val AGREEMENTS = "agreements"

        // Rev 1.4 §O: ingest validates `step` against the mobile AND web sets, so the web
        // set's sign-in and pre-check names serve the SDK's own sign-in screens unchanged.
        const val ACCOUNT = "account"
        const val ELIGIBILITY = "eligibility"

        val ALL = setOf(APPLY, EMPLOYMENT, SALARY, CONFIRM, OFFER, DISBURSEMENT, OTP, AGREEMENTS, ACCOUNT, ELIGIBILITY)
    }

    /** Contract §3 `kind: error` — the `attrs.type` closed set. */
    object ErrorType {
        const val NOT_AUTHENTICATED = "NotAuthenticated"
        const val USER_BLOCKED = "UserBlocked"
        const val CAPTCHA = "Captcha"
        const val VALIDATION = "Validation"
        const val NETWORK = "Network"
        const val API = "Api"

        val ALL = setOf(NOT_AUTHENTICATED, USER_BLOCKED, CAPTCHA, VALIDATION, NETWORK, API)
    }

    /**
     * Contract addendum §A (document revision 1.1) — the closed `name` vocabularies for
     * the three kinds §4 left open. Each kind has exactly ONE valid name; the
     * discriminating detail lives in `attrs`, not in `name`.
     *
     * These are deliberately NOT the same strings as [Kind]: the wire `name` for
     * `kind: "api_call"` is `http_call`, not `api_call`. Emitting the kind as the name
     * (what this SDK did before revision 1.1) is an unknown name and, per addendum §C,
     * a schema violation that rejects the ENTIRE batch with 422.
     */
    object EventName {
        /** `kind: "api_call"` */
        const val HTTP_CALL = "http_call"

        /** `kind: "error"` */
        const val SDK_ERROR = "sdk_error"

        /** `kind: "log"` */
        const val SDK_LOG = "sdk_log"
    }

    fun isValidName(kind: String, name: String): Boolean = when (kind) {
        Kind.LIFECYCLE -> name in Lifecycle.ALL
        Kind.STATE -> name in State.ALL
        Kind.API_CALL -> name == EventName.HTTP_CALL
        Kind.ERROR -> name == EventName.SDK_ERROR
        Kind.LOG -> name == EventName.SDK_LOG
        else -> false
    }

    fun isValidStep(step: String?): Boolean = step == null || step in Step.ALL
}
