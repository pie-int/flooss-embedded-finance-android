package com.flooss.nanoloan.telemetry

import java.util.ArrayDeque

/**
 * Bounded in-memory event queue (contract §1.5 — "buffer and POST batches; dropping a
 * batch must never break the customer journey").
 *
 * Invariants this class exists to guarantee:
 *  - it never grows past [capacity]; at capacity the OLDEST event is evicted, because on
 *    a long journey the newest events are the ones an operator is actually looking at;
 *  - every eviction increments [droppedCount], which is reported on the next batch so a
 *    gap in `seq` is explained rather than looking like data loss in transit;
 *  - it never blocks the caller — [offer] is a bounded, non-suspending, synchronized
 *    array-deque push, called from the journey's own thread.
 *
 * Failed batches are returned with [requeue], which puts them back at the FRONT so
 * ordering by `seq` survives a retry. A requeue that would exceed capacity drops the
 * oldest of the requeued events, not the newest live ones.
 */
internal class NanoTelemetryBuffer(private val capacity: Int) {

    private val lock = Any()
    private val queue = ArrayDeque<NanoTelemetryEvent>()
    private var dropped = 0L

    val size: Int get() = synchronized(lock) { queue.size }

    /** Total events evicted since construction. Never reset by [drain]. */
    val droppedCount: Long get() = synchronized(lock) { dropped }

    /** @return true if the event was stored without evicting anything. */
    fun offer(event: NanoTelemetryEvent): Boolean = synchronized(lock) {
        var evicted = false
        while (queue.size >= capacity) {
            queue.pollFirst()
            dropped++
            evicted = true
        }
        queue.addLast(event)
        !evicted
    }

    /** Removes and returns up to [max] oldest events, in `seq` order. */
    fun drain(max: Int): List<NanoTelemetryEvent> = synchronized(lock) {
        if (queue.isEmpty()) return emptyList()
        val n = minOf(max, queue.size)
        val out = ArrayList<NanoTelemetryEvent>(n)
        repeat(n) { queue.pollFirst()?.let(out::add) }
        out
    }

    /** Puts a failed batch back at the head, preserving order; overflow drops the oldest. */
    fun requeue(events: List<NanoTelemetryEvent>) = synchronized(lock) {
        for (event in events.asReversed()) {
            if (queue.size >= capacity) {
                dropped++
                continue
            }
            queue.addFirst(event)
        }
    }

    fun clear() = synchronized(lock) {
        queue.clear()
    }
}
