package com.flooss.nanoloan.network.dto

import java.math.BigDecimal

/** `GET api/v1/fo/client-profile` — only the fields the journey reads. */
internal data class ClientProfileDto(
    val personalDetails: ProfilePersonalDto? = null,
    val employmentDetails: ProfileEmploymentDto? = null
)

internal data class ProfilePersonalDto(val name: String? = null)

internal data class ProfileEmploymentDto(
    val employerName: String? = null,
    val occupation: String? = null,
    val monthlySalary: BigDecimal? = null,
    val educationLevel: Long? = null,
    val workExperience: Long? = null,
    val yearsInCurrentJob: Long? = null
)

/** `GET api/v1/fo/companies/private` — the employer list the app's autocomplete uses. */
internal data class PrivateCompaniesDto(val privateCompanies: List<PrivateCompanyDto>? = null)

internal data class PrivateCompanyDto(val employerName: String? = null)
