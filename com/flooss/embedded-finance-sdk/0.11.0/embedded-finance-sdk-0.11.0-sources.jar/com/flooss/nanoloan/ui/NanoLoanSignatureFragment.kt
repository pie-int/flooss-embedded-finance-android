package com.flooss.nanoloan.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ScrollView
import android.widget.TextView
import com.flooss.nanoloan.NanoLoanSDK
import com.flooss.nanoloan.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * SDK_V3_PRODUCT_GAPS §2.6 — digital signature, upgrading the previous tap-to-sign.
 *
 * Three gates, in order: the document is shown in full; the sign action stays disabled
 * until the customer has actually scrolled to its END; and signing takes an explicit
 * confirmation on top of that. The audit event carries the document type and the instant
 * of signature.
 *
 * The signature PROVIDER is an open business question. What is implemented here is the
 * ceremony and the audit record — there is no vendor binding, and none is faked.
 */
internal class NanoLoanSignatureFragment : NanoLoanJourneyFragment() {

    private var scrolledToEnd = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View = inflater.inflate(R.layout.nanoloan_fragment_signature, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val theme = NanoLoanSDK.currentConfiguration().theme

        setUpHeader(
            headerRoot = view.findViewById(R.id.header),
            title = getString(R.string.nanoloan_agreement_title),
            dotCount = 3,
            dotIndex = 3,
            screenNumber = "11/12",
            stepName = STEP_NAME
        ) {
            sign()
        }
        NanoLoanThemeApplier.applyChromeBackground(view.findViewById(R.id.rootLayout), theme)

        view.findViewById<TextView>(R.id.document_body).text =
            getString(R.string.nanoloan_agreement_body)

        val scroll = view.findViewById<ScrollView>(R.id.document_scroll)
        val hint = view.findViewById<TextView>(R.id.scroll_hint)
        val consent = view.findViewById<CheckBox>(R.id.signature_consent)
        val signBtn = view.findViewById<View>(R.id.sign_btn)

        fun refresh() {
            consent.isEnabled = scrolledToEnd
            if (!scrolledToEnd) consent.isChecked = false
            signBtn.isEnabled = scrolledToEnd && consent.isChecked
            hint.text = getString(
                if (scrolledToEnd) R.string.nanoloan_scrolled_to_end
                else R.string.nanoloan_scroll_to_end
            )
        }

        // Both heights are 0 until the first layout pass, and "0 + 0 >= 0" would open
        // the gate before the document has been rendered at all. Nothing counts as read
        // until the view has been measured.
        fun measured() = scroll.height > 0 && (scroll.getChildAt(0)?.height ?: 0) > 0

        fun checkScrolledToEnd() {
            if (scrolledToEnd || !measured()) return
            val child = scroll.getChildAt(0) ?: return
            if (scroll.scrollY + scroll.height >= child.height - SCROLL_END_TOLERANCE_PX) {
                scrolledToEnd = true
                refresh()
            }
        }

        scroll.viewTreeObserver.addOnScrollChangedListener {
            if (!isAdded) return@addOnScrollChangedListener
            checkScrolledToEnd()
        }
        // A document short enough to fit without scrolling has, by definition, been
        // shown in full — do not demand a scroll that cannot happen. Checked after
        // layout, when the heights are real.
        scroll.post { checkScrolledToEnd() }

        consent.setOnCheckedChangeListener { _, _ -> refresh() }
        // The whole row is the target, not just the box.
        view.findViewById<View>(R.id.signature_consent_row).setOnClickListener {
            if (consent.isEnabled) consent.isChecked = !consent.isChecked
        }
        signBtn.setOnClickListener { sign() }
        refresh()
    }

    private fun sign() {
        val signedAt = ISO_8601.format(Date())
        journeyData.agreementSignedAt = signedAt
        NanoLoanSDK.notifyDocumentSigned(DOCUMENT_TYPE, signedAt)
        journeyHost.goToDirectDebitMandate()
    }

    companion object {
        const val STEP_NAME = "digital_signature"

        /** The document this ceremony covers; the provider binding is deliberately absent. */
        private const val DOCUMENT_TYPE = "financing_agreement"

        /** A couple of dp of slack so a pixel-perfect bottom is not required. */
        private const val SCROLL_END_TOLERANCE_PX = 8

        private val ISO_8601 = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }
}
